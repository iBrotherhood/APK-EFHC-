# EFHC Offline Demo Simulator v0.1.1 — отчёт поставки

## Результат

Создан первый полный исходный пакет офлайн APK-симулятора EFHC на базе release-архива `EFHC_Bot_v172_43_RELEASE.zip`.

Симулятор использует настоящий текущий фронтенд EFHC и не создаёт отдельную копию экранов на Kotlin/Compose. Android-часть служит защищённым контейнером для локально собранного Next.js-интерфейса.

## Исходная база

- EFHC: v172.43 RELEASE
- SHA-256: `c505ed88b7f95c698380d581f1b418c7d2b9f7e4f4b6b6cd5670453fc4150bca`
- Simulator: v0.1.1
- applicationId: `org.federationofavatars.efhc.simulator`
- minSdk: 26
- targetSdk: 36
- runtime: `offline_simulator`

## Интерфейс

В пакет перенесён полный release-фронтенд:

- 32 рабочих экранных маршрута;
- 17 административных страниц;
- отдельные страницы ошибок 404 и 500;
- общий дизайн, компоненты, навигация, локализация и адаптивность EFHC.

Встроен `Demo Control Center`, содержащий прямой переход на все пользовательские, магазинные и административные маршруты.

## Локальная база данных

Используется постоянная IndexedDB `efhc-offline-simulator-v1`. Это реальное локальное табличное хранилище WebView, а не набор статических изображений.

Таблицы:

1. settings
2. users
3. panels
4. transactions
5. tasks
6. user_tasks
7. referrals
8. wallets
9. withdrawals
10. shop_items
11. shop_orders
12. hub_links
13. admin_events
14. skins
15. templates

Данные сохраняются между перезапусками APK и удаляются/восстанавливаются через полный сброс в Demo Control Center.

## Имитация backend

Все вызовы общего `apiRequest()` в режиме симулятора перенаправляются в локальный `demoApiRouter`.

Реализованы связанные сценарии:

- получение общего snapshot пользователя;
- активные и архивные панели;
- локальная активация и деактивация панелей;
- обмен kWh на EFHC с изменением баланса и журнала;
- каталог и статусы заданий;
- начисление наград за задания;
- просмотр рекламы и начисление EFHCb;
- статистика и списки рефералов;
- рейтинги;
- подключение, выбор и удаление демо-кошельков;
- история балансов;
- создание и отмена вывода;
- административная обработка выводов;
- локальный банк, mint и burn;
- административная корректировка баланса пользователя;
- магазин, товары, заказы и статусы;
- Hub и управление ссылками;
- шаблоны;
- отчёты, логи, health и observability;
- TON/Telegram auth fallback без реальной сети.

Пользовательская и административная части работают с одними локальными таблицами. Изменение в Admin отражается в пользовательском состоянии и наоборот.

## Демо-сценарии

- active — обычный заполненный аккаунт;
- vip — VIP, повышенная генерация и большие значения;
- new_user — пустой новый аккаунт;
- risk — проблемные и отклонённые операции;
- dense — длинные таблицы для проверки прокрутки, фильтров и мобильной вёрстки.

Режимы backend:

- normal;
- slow;
- error;
- empty.

Seed: `EFHC-DEMO-SEED-001`. Демо-данные разнообразны, но воспроизводимы после сброса.

## Офлайн-защита

- production API отключён на уровне общего API-клиента;
- в Android Manifest отсутствует разрешение INTERNET;
- отсутствуют разрешения камеры, микрофона, геолокации и контактов;
- WebView разрешает только локальный домен `appassets.androidplatform.net`;
- Content Security Policy ограничивает `connect-src` значением `'self'`;
- Telegram external script не включается в simulator build;
- Service Worker отключён в симуляторе;
- реальные TON-транзакции заменены локальным результатом;
- постоянная маркировка `DEMO · OFFLINE · LOCAL DATA`.

## GitHub CI

Workflow адаптирован под архив `EFHC_Visual_Demo.zip` и выполняет:

- проверку ZIP и SHA-256;
- проверку структуры и simulator contract;
- `npm ci`;
- TypeScript typecheck;
- тесты demo engine;
- статический Next.js export;
- синхронизацию assets с Android;
- Gradle unit tests;
- Android lint;
- Kotlin compile;
- debug APK build;
- проверку подписи;
- проверку applicationId, versionCode/versionName, minSdk/targetSdk;
- проверку отсутствия INTERNET и опасных разрешений;
- проверку встроенного `simulator-contract.json`;
- формирование APK, SHA-256 и build report.

При отсутствии постоянного development keystore CI создаёт обычный debug APK для удаления/повторной установки. При добавлении секретов поддерживается постоянная подпись и обновление поверх установленной версии.

## Выполненные локальные проверки

PASS:

- целостность исходной структуры;
- simulator contract;
- наличие 15 локальных таблиц;
- наличие основных пользовательских и административных API-маршрутов;
- синтаксис 317 TypeScript/TSX-файлов;
- синтаксис новых demo TS/TSX-модулей;
- AndroidManifest XML;
- YAML обоих CI-файлов;
- отсутствие INTERNET и опасных разрешений;
- согласованность standalone CI и копии внутри пакета;
- отсутствие блокирующих семантических диагностик в изменённых файлах, кроме ошибок отсутствующих локально npm-зависимостей.

Не выполнено локально из-за среды:

- полный `npm ci`;
- полный Next.js static export;
- Android Gradle build и получение APK.

Причина: локальный npm registry в рабочей среде не выдал один из package tarballs, а прямой npm registry был недоступен по DNS. Полная сборка преднамеренно передана каноническому GitHub CI. Готовый APK пока не заявляется как собранный.

## Следующий цикл

1. Загрузить ZIP и workflow в GitHub.
2. Получить первый APK через CI.
3. Установить APK на смартфон.
4. Проверить все экраны и прислать логи CI, скриншоты и перечень визуальных/сценарных ошибок.
5. Исправить Simulator v0.1.1.
6. При получении нового рабочего архива EFHC синхронизировать его фронтенд с локальным simulator layer, не теряя подтверждённые исправления.

## Corrective cycle 001 — GitHub CI 83342982821

Причина падения: Android lint `GestureBackNavigation` на `MainActivity.onBackPressed()` при targetSdk 36.

Исправления:

- удалён устаревший override `Activity.onBackPressed()`;
- `MainActivity` переведён на `ComponentActivity`;
- навигация назад реализована через `OnBackPressedDispatcher` и `OnBackPressedCallback`;
- сохранено поведение WebView history, при пустой истории Activity закрывается;
- удалены устаревшие программные вызовы `statusBarColor`, `navigationBarColor` и WebView `databaseEnabled`;
- добавлена зависимость `androidx.activity:activity-ktx`;
- versionCode повышен до 2, versionName — до 0.1.1.
