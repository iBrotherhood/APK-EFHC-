# EFHC Offline Demo Simulator v0.1.3 — corrective cycle 003

## Результат

Исправлено падение GitHub CI `83376685844`. Дополнительно повторно проверены код, 17 локальных таблиц, 32 экранных маршрута, demo API и все пять наборов демо-данных.

Параметры пакета:

- источник интерфейса: `EFHC v172.43 RELEASE`;
- simulator version: `0.1.3`;
- versionCode: `4`;
- applicationId: `org.federationofavatars.efhc.simulator`;
- minSdk: `26`;
- targetSdk: `36`;
- runtime: `offline_simulator`;
- backend: `local_demo_engine`.

Канонический GitHub workflow не изменялся и не включён в архив.

## Что показал CI

В прогоне `83376685844` успешно прошли:

- проверка ZIP и SHA-256;
- проверка simulator contract;
- `npm ci`;
- TypeScript typecheck;
- тесты demo engine;
- статический Next.js export;
- подготовка Android source assets;
- Gradle unit tests;
- Android lint;
- Kotlin compilation;
- `assembleDebug`;
- подпись APK;
- applicationId, versionCode/versionName, minSdk/targetSdk;
- отсутствие `INTERNET` и опасных разрешений.

Единственное блокирующее падение произошло после успешной сборки APK: файл `assets/web/simulator-contract.json` отсутствовал внутри итогового APK, хотя находился в source assets.

## Исправление упаковки Android assets

Причина была в том, что прежняя задача копировала новый файл непосредственно в изменяемое source-дерево перед `mergeDebugAssets`. Наличие файла до сборки проверялось, но его фактическое включение AAPT в APK не гарантировалось. Дополнительная Gradle-проверка также не являлась зависимостью канонически вызываемой задачи `assembleDebug`.

В v0.1.3:

- создана задача `prepareSimulatorAssets`;
- всё source-дерево `src/main/assets` копируется в отдельное неизменяемое generated-assets дерево внутри `build/`;
- Android `main` source set упаковывает только generated-assets дерево;
- задача выполняется после `clean` и до `preBuild`/`merge*Assets`;
- canonical и source contract сравниваются побайтно;
- после создания APK задача `verifyDebugApkContainsSimulatorContract` открывает фактический APK и проверяет:
  - `assets/web/index.html`;
  - `assets/web/simulator-contract.json`;
  - ненулевой размер обоих файлов;
  - полное побайтовое совпадение embedded contract с `SIMULATOR_CONTRACT.json`;
- `assembleDebug` теперь зависит от этой проверки, поэтому дефект упаковки блокируется внутри проекта без изменения workflow.

## Аудит локальной базы

Схема: `efhc-offline-simulator-v2`, IndexedDB version `2`, таблиц `17`:

1. settings
2. users
3. panels
4. transactions
5. tasks
6. user_tasks
7. referrals
8. wallets
9. withdrawals
10. shop_items
11. shop_orders
12. hub_links
13. admin_events
14. skins
15. templates
16. sale_packages
17. ad_events

Подтверждено:

- нет индексов по boolean-полям;
- уникальные индексы существуют для `global_id`, `tg_id`, `public_id`, wallet address, task/user pair, sale-package code и ad token;
- миграция v1 → v2 использует отдельные read/write-транзакции;
- первичное заполнение проходит integrity-проверку до записи;
- переключение runtime/fault mode больше не удаляет `database_version` и `schema` из строки настроек;
- после ошибки открытия базы promise сбрасывается и допускает корректную повторную попытку.

Проверенные seed-наборы:

- `active`: 17 таблиц, 170 строк;
- `vip`: 17 таблиц, 177 строк;
- `new_user`: 17 таблиц, 86 строк;
- `risk`: 17 таблиц, 170 строк;
- `dense`: 17 таблиц, 862 строки.

## Аудит маршрутов и demo API

Проверено:

- 32 экранных маршрута;
- 17 административных страниц;
- 82 обязательных семейства demo API;
- динамические маршруты кошельков, скинов, заданий, выводов, магазина, Hub, sale packages и административных операций;
- непредусмотренный маршрут завершается явной ошибкой `DEMO_API_ROUTE_NOT_IMPLEMENTED`, а не скрытой фиктивной выдачей.

Подтверждены связанные операции:

- активация и архивирование панелей;
- обмен kWh → EFHC с проверкой доступной энергии;
- награды за задания и рекламу с защитой от повторного начисления;
- подключение, удаление и выбор основного кошелька;
- создание, одобрение и отклонение вывода с однократным возвратом;
- bank mint/burn и административная корректировка баланса;
- магазин, заказы, payment intent и повторная обработка;
- Hub, шаблоны, рекламные провайдеры и sale packages;
- observability, health, отчёты и журналы.

## Исправления demo mode

- режим `empty` теперь возвращает полноценные структуры, совместимые с frontend-валидаторами, для профиля, панелей, рефералов, рейтинга, кошельков, скинов, магазина и административных разделов;
- пустой сценарий отображает корректные empty states вместо ошибок схемы;
- пользовательская и административная части продолжают использовать одну IndexedDB;
- режимы `normal`, `slow`, `error`, `empty` сохраняются;
- production API, Telegram/TON network actions и реальные финансовые операции отключены.

## Проверки пакета

Локально выполнены:

- `test-demo.mjs`: PASS — 32 pages, 17 tables, 82 API route markers;
- синтаксическая проверка изменённых TypeScript/JavaScript-модулей: PASS;
- runtime integrity пяти seed-сценариев: PASS;
- canonical/source contract byte equality: PASS;
- Android Manifest offline guards: PASS;
- отсутствие embedded `.github`/workflow: PASS;
- ZIP structure, CRC и source SHA-256 manifest: PASS.

Полный локальный `npm ci` повторно не завершён из-за недоступности tarball `zod` во внутреннем registry среды. В предоставленном GitHub-прогоне установка зависимостей, typecheck и Next.js build прошли успешно. Новая Gradle-логика упаковки окончательно квалифицируется следующим прогоном канонического GitHub CI.
