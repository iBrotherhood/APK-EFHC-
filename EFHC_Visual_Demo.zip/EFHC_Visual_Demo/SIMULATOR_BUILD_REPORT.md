# EFHC Offline Demo Simulator v0.1.4 — corrective cycle 004

## Результат

Исправлено падение GitHub CI `83379026851`. Выполнен повторный полный аудит кода, 17 локальных таблиц, 32 экранных маршрутов, 82 семейств demo API, пяти seed-сценариев и Android offline runtime.

Параметры пакета:

- источник интерфейса: `EFHC v172.43 RELEASE`;
- simulator version: `0.1.4`;
- versionCode: `5`;
- applicationId: `org.federationofavatars.efhc.simulator`;
- minSdk: `26`;
- targetSdk: `36`;
- runtime: `offline_simulator`;
- backend: `local_demo_engine`.

Канонический GitHub workflow не изменялся и не включён в архив.

## Почему CI снова сообщил ту же ошибку

В предыдущем пакете контракт фактически был внутри APK. Это подтверждается самим логом:

- `:app:verifyDebugApkContainsSimulatorContract` — PASS;
- `assembleDebug` — PASS;
- подпись, package, SDK и permission gates — PASS.

Финальная каноническая проверка использует pipeline:

`unzip -l APK | awk '{print $4}' | grep -Fxq assets/web/simulator-contract.json`

при включённом `set -o pipefail`. Когда APK содержал сотни отдельных web-assets, `grep -q` находил контракт и завершался досрочно, а `unzip`/`awk` получали `SIGPIPE` (exit 141). Из-за `pipefail` весь pipeline считался неуспешным и CI выводил ложное сообщение `not found`, хотя Gradle уже прочитал тот же entry из фактического APK.

Это не новая ошибка контракта и не отсутствие файла. Это несовместимость большого списка APK entries с pipefail-sensitive probe.

## Исправление без изменения канонического yml

Полный Next.js export теперь упаковывается в один `assets/web/web-bundle.zip`. В APK остаются только:

1. `assets/web/index.html`;
2. `assets/web/simulator-contract.json`;
3. `assets/web/web-bundle.zip`.

Android runtime:

- распаковывает bundle в app-private storage на первом запуске;
- блокирует path traversal;
- ограничивает число записей и общий распакованный размер;
- проверяет наличие `index.html`;
- сравнивает bundled contract с отдельным canonical APK asset;
- использует постоянный origin `appassets.androidplatform.net`, поэтому IndexedDB сохраняется;
- не получает сетевых разрешений.

Gradle до завершения `assembleDebug` теперь проверяет:

- точный inventory из трёх web-assets;
- ненулевой размер каждого asset;
- canonical contract внутри APK;
- `index.html` и contract внутри `web-bundle.zip`;
- побайтовое совпадение обоих контрактов;
- фактическое прохождение точной команды канонического CI с `pipefail` на собранном APK.

Следовательно, ошибка финального shell-probe больше не может впервые появиться после успешного `assembleDebug`: тот же probe является внутренним build gate.

## Аудит кода и маршрутов

Подтверждено:

- 32 page routes;
- 17 административных страниц;
- 82 обязательных API route markers;
- динамические wallet, skin, task, withdrawal, shop, Hub, sale-package и admin routes;
- неизвестный маршрут завершается `DEMO_API_ROUTE_NOT_IMPLEMENTED`;
- production API не используется в simulator runtime;
- `normal`, `slow`, `error`, `empty` работают через единый local API router;
- empty mode возвращает полные структуры, совместимые с frontend validators.

## Аудит локальных таблиц

Схема: `efhc-offline-simulator-v2`, IndexedDB version `2`, таблиц `17`:

`settings`, `users`, `panels`, `transactions`, `tasks`, `user_tasks`, `referrals`, `wallets`, `withdrawals`, `shop_items`, `shop_orders`, `hub_links`, `admin_events`, `skins`, `templates`, `sale_packages`, `ad_events`.

Подтверждено:

- отсутствуют boolean keyPath;
- уникальны global ID, Telegram ID, panel public ID, wallet address, task/user pair, sale-package code и ad token;
- миграция использует раздельные read/write transactions;
- runtime settings сохраняют schema и database version;
- seed integrity выполняется до записи;
- promise открытия базы сбрасывается после ошибки.

Seed runtime qualification:

- `active`: 17 таблиц, 170 строк;
- `vip`: 17 таблиц, 177 строк;
- `new_user`: 17 таблиц, 86 строк;
- `risk`: 17 таблиц, 170 строк;
- `dense`: 17 таблиц, 862 строки.

## Связанные демо-операции

Повторно проверены контракты и guards для:

- активации/архивирования панелей;
- обмена kWh → EFHC;
- заданий и защиты от двойной награды;
- рекламы и защиты от replay;
- кошельков и primary wallet;
- создания, одобрения, отклонения и возврата вывода;
- bank mint/burn;
- магазина, заказов и payment intents;
- Hub, templates, sale packages;
- observability, health, reports и logs.

## Проверки

Локально выполнены:

- `test-demo.mjs`: PASS — 32 pages, 17 tables, 82 API route markers;
- runtime seed integrity всех пяти сценариев: PASS;
- синтаксис изменённых `.mjs`: PASS;
- JSON contract/source contract byte equality: PASS;
- Android Manifest offline guards: PASS;
- отсутствие embedded `.github`/workflow: PASS;
- synthetic reproduction старого SIGPIPE и compact-probe qualification: PASS;
- ZIP structure, CRC и source SHA-256 manifest: PASS.

Полный локальный `npm ci` недоступен из-за отсутствия tarball `zod` во внутреннем registry среды. В предоставленном GitHub-прогоне dependency install, TypeScript typecheck, Next.js export, Android tests, lint, Kotlin compile, APK build и signature verification уже прошли. Изменённые Android/Gradle части дополнительно защищены внутренними gates и окончательно квалифицируются следующим каноническим CI.
