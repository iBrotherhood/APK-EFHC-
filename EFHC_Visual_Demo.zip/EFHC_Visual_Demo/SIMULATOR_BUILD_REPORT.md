# EFHC Offline Demo Simulator v0.1.2 — corrective cycle 002

## Результат

Исправлены ошибки GitHub CI `83369525204` и выполнен дополнительный аудит кода, локальных таблиц, экранных маршрутов и demo API.

Исходная база:

- EFHC: `v172.43 RELEASE`;
- Simulator: `v0.1.2`;
- versionCode: `3`;
- applicationId: `org.federationofavatars.efhc.simulator`;
- minSdk: `26`;
- targetSdk: `36`;
- runtime: `offline_simulator`.

## Что показал CI

До финального шага успешно прошли:

- распаковка и проверка исходного ZIP;
- `npm ci`;
- TypeScript typecheck;
- тесты demo engine;
- статический Next.js export;
- подготовка Android assets;
- Gradle unit tests;
- Android lint;
- Kotlin compilation;
- `assembleDebug`;
- подпись APK;
- проверка applicationId, versionCode/versionName, minSdk/targetSdk;
- проверка отсутствия `INTERNET` и опасных разрешений.

Единственное блокирующее падение:

`assets/web/simulator-contract.json` отсутствовал внутри собранного APK, хотя файл существовал в исходном дереве Android assets.

## Исправление упаковки APK

- добавлена Gradle-задача `syncSimulatorContractAsset`;
- `preBuild` и все `merge*Assets` зависят от синхронизации контракта;
- canonical `SIMULATOR_CONTRACT.json` принудительно копируется в `src/main/assets/web/simulator-contract.json`;
- JSON исключён из сжатия через `androidResources.noCompress`;
- добавлена Gradle-задача `verifyDebugApkContainsSimulatorContract`;
- задача открывает фактический APK как ZIP и проверяет наличие и ненулевой размер:
  - `assets/web/index.html`;
  - `assets/web/simulator-contract.json`;
- GitHub CI запускает эту проверку до публикации APK;
- финальный CI-контроль формирует полный список файлов APK через `unzip -Z1` и показывает inventory `assets/web/` при ошибке.

## Аудит локальной базы

Схема повышена до `efhc-offline-simulator-v2`. Таблиц: 17.

1. settings
2. users
3. panels
4. transactions
5. tasks
6. user_tasks
7. referrals
8. wallets
9. withdrawals
10. shop_items
11. shop_orders
12. hub_links
13. admin_events
14. skins
15. templates
16. sale_packages
17. ad_events

Исправления:

- удалены IndexedDB-индексы по булевым полям `is_active` и `is_primary`: boolean не является допустимым IndexedDB key;
- сохранены валидные строковые, числовые и составные индексы;
- миграция v1 → v2 разделена на отдельную read-транзакцию и write-транзакцию, чтобы избежать автоматического закрытия транзакции после `await`;
- добавлено заполнение новых таблиц `sale_packages` и `ad_events`;
- сохранён сброс `readyPromise` после ошибки открытия базы;
- проверена уникальность `global_id`, `tg_id`, wallet address, task/user pair, ad token и других indexed keys.

Runtime-проверка всех seed-сценариев:

- active: 17 таблиц, 170 строк;
- vip: 17 таблиц, 177 строк;
- new_user: 17 таблиц, 86 строк;
- risk: 17 таблиц, 170 строк;
- dense: 17 таблиц, 862 строки.

Все seed-наборы прошли integrity-проверку и проверку допустимости IndexedDB index keys.

## Аудит маршрутов и demo API

Проверено:

- 32 экранных маршрута;
- 17 административных страниц;
- 70 обязательных demo API route markers;
- 75 API-подобных строковых путей во frontend-коде.

Четыре непредставленных строки оказались не API-вызовами, а навигационными/документационными подписями (`/admin/diagnostics`, `/admin/system`, визуальная подпись `/admin/bank · /admin/users` и комментарий `/sync/user/{tg_id}`). Реальных frontend API-вызовов без обработчика не обнаружено.

Исправлены скрытые несовпадения контрактов:

- sale packages: поддержаны `PUT`, `PATCH`, `DELETE`, toggle и прямой формат mutation-response;
- Hub: список возвращается массивом; create/update/toggle/reorder соответствуют фактическим методам интерфейса;
- отсутствующая Hub-запись больше не создаётся как неполная строка при toggle;
- Templates и Ads providers возвращают формат, ожидаемый административными страницами;
- balance history преобразует внутренние направления `user_credit/user_debit` в frontend-схему `credit/debit`;
- shopfront profile возвращает полный профиль магазина;
- create-intent и intent-status работают с общей локальной таблицей заказов и поддерживают idempotency;
- повторная модерация задания не начисляет бонус второй раз;
- отклонение вывода выполняет возврат только один раз;
- bank burn теперь отклоняет списание сверх локального баланса вместо скрытого ограничения значения;
- обмен, вывод, реклама, задания, магазин и административные операции валидируют суммы и существование строк.

## Demo mode

Подтверждено:

- все API-вызовы simulator runtime перенаправляются в локальный `demoApiRouter`;
- пользовательские и административные экраны работают с одной IndexedDB;
- сценарии `active`, `vip`, `new_user`, `risk`, `dense` воспроизводимы;
- fault modes `normal`, `slow`, `error`, `empty` сохранены;
- локальное состояние сохраняется между запусками и сбрасывается через Demo Control Center;
- production API, Telegram/TON network actions и реальные финансовые операции отключены;
- Android Manifest не запрашивает `INTERNET`, камеру, микрофон, геолокацию или контакты.

## Выполненные проверки

PASS:

- синтаксис build/test scripts;
- TypeScript-проверка изменённых demo-модулей;
- 32-page route matrix;
- 17-table schema matrix;
- 70 API route markers;
- canonical/embedded contract byte equality;
- JSON и GitHub Actions YAML parsing;
- runtime seed integrity по пяти сценариям;
- IndexedDB index key validity и uniqueness;
- отсутствие boolean keyPath;
- Android offline permission guards;
- Gradle asset synchronization/verification guards;
- ZIP source structure и SHA-256 manifest.

Полный локальный `npm ci` и Gradle APK build не выполнялись повторно из-за ограничений локального registry/DNS. В предоставленном GitHub-прогоне эти этапы уже прошли до финальной asset-проверки. Окончательная проверка исправленной упаковки выполняется новым GitHub CI.
