# EFHC Offline Demo Simulator v0.2.0 — interface and economic canon sync

## Результат

Симулятор синхронизирован с `EFHC_Bot_v172_50.zip`. Интерфейс обновлён по точному файловому diff, а финансово-энергетическая логика переведена на backend-совместимую d8-арифметику.

Параметры пакета:

- source: `EFHC_Bot_v172_50.zip`;
- source SHA-256: `a4edb6ebbcb99a439e79e839e1ee5160796b0845d2c6925bf77d731e897eb3ca`;
- simulator version: `0.2.0`;
- versionCode: `6`;
- applicationId: `org.federationofavatars.efhc.simulator`;
- minSdk: `26`;
- targetSdk: `36`;
- runtime: `offline_simulator`;
- backend: `local_demo_engine`;
- IndexedDB: version `3`, schema `efhc-offline-simulator-v3`;
- tables: `17`;
- page routes: `32`;
- demo API families: `82`.

Канонический GitHub workflow не изменялся и не включён в архив.

## Точная синхронизация интерфейса

Сравнение полного frontend v172.43 и v172.50 выявило 22 изменённых файла. Все они перенесены из v172.50 побайтно. `INTERFACE_SOURCE_V172_50_MANIFEST.json` хранит SHA-256 каждого файла, а `test-demo.mjs` прекращает сборку при любом расхождении.

Обновление включает GlobalHeader, Layout, onboarding, PWA runtime status, энергетический dashboard, панели, ранги, UI kit, магазин, FAQ, административную главную, глобальные стили и production metadata.

## Backend-совместимая математика

Предыдущие условные demo-ставки удалены. Создан `frontend/src/demo/economics.ts` с fixed-point d8 через `BigInt`.

Канон:

- `Decimal(...).quantize(0.00000001, ROUND_DOWN)` зеркалируется усечением к нулю;
- base generation: `0.00000692 kWh/с` на панель;
- VIP generation: `0.00000741 kWh/с` на панель;
- exchange: `1 kWh → 1.00000000 EFHCm`;
- reverse exchange запрещён;
- scheduler tick: `600 секунд`;
- panel price: `100.00000000 EFHC`;
- panel lifetime: `180 дней`;
- active panel limit: `1000`;
- purchase debit order: `EFHCb → EFHCm`;
- minimum withdrawal: `10.00000000 EFHCm`, только main balance;
- direct referral reward: `0.10000000 EFHCb`, максимум за 10 000 активных;
- level rewards: `1 / 10 / 100 / 300 / 1000 EFHCb` при `10 / 100 / 1000 / 3000 / 10000` активных;
- отрицательные пользовательские балансы запрещены;
- отрицательный bank balance разрешён;
- P2P и автоматическая NFT-доставка запрещены.

Источник констант зафиксирован SHA-256-манифестом восьми backend-файлов. Статический JSON с каноном экспортируется внутрь APK и доступен офлайн.

## Генерация и финансовые операции

Добавлен локальный settlement каждой активной панели:

- расчёт идёт от `last_generated_at` до `min(now, expires_at)`;
- применяется base/VIP ставка владельца;
- результат округляется d8 `ROUND_DOWN`;
- повторный вызов идемпотентен по обновлённому `last_generated_at`;
- просроченная панель переводится в архив;
- одновременно обновляются `panel.generated_kwh`, `user.total_generated_kwh` и `user.available_kwh`;
- invariant пользователя: `available_kwh = total_generated_kwh - exchanged_kwh_total`.

Проверены и приведены к d8:

- активация панели и bonus-first debit;
- банк-зеркало покупки;
- частичный и полный обмен kWh;
- задания и реклама;
- реферальные итоги и уровни;
- вывод, hold и однократный refund;
- скины;
- shop intents;
- admin transfer;
- bank mint/burn;
- отчёты и агрегаты.

## Данные и миграция

IndexedDB schema обновлена до v3. Миграция сохраняет существующее состояние и добавляет:

- канонические ставки генерации;
- `exchanged_kwh_total`;
- 180-дневный срок панелей;
- заблокированную запись `settings/economics`;
- актуальные database version/schema markers.

Пять seed-сценариев проходят проверки формата d8, уникальности, связей и energy mirror invariant:

| Сценарий | Таблиц | Строк |
|---|---:|---:|
| `active` | 17 | 171 |
| `vip` | 17 | 178 |
| `new_user` | 17 | 87 |
| `risk` | 17 | 171 |
| `dense` | 17 | 863 |

## Выполненные проверки

Локально подтверждено:

- `test-demo.mjs`: PASS — 32 страницы, 17 таблиц, 82 API families;
- runtime-компиляция и исполнение economic/seed-модулей внутри `test:demo`: PASS;
- строгий TypeScript typecheck core demo-модулей: PASS;
- синтаксическая transpilation 319 `.ts/.tsx`: PASS;
- арифметические тесты d8/ROUND_DOWN/generation/exchange/debit/referrals: PASS;
- exact frontend diff v172.43 → v172.50: PASS, 22/22 файла;
- contract и Android source contract byte equality: PASS;
- economic asset и economic manifest equality: PASS;
- Android offline permission guards: PASS;
- отсутствие embedded `.github` и workflow: PASS.

Полный локальный `npm ci` не завершён из-за отсутствия tarball `zod-3.25.76.tgz` во внутреннем registry среды. Это инфраструктурное ограничение локальной среды. Канонический GitHub CI выполняет полный `npm ci`, production typecheck, Next.js static export, Gradle tests/lint/compile и APK qualification.
