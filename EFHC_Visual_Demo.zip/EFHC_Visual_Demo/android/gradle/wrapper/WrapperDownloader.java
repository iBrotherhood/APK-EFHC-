import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.time.Duration;
import java.util.zip.ZipFile;

/** Fetch the official Gradle 8.13 wrapper from Gradle distributions and verify SHA256. */
public class WrapperDownloader {
    private static final String URL = "https://services.gradle.org/distributions/gradle-8.13-wrapper.jar";
    private static byte[] request(HttpClient client, String url) throws Exception {
        var req = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(60)).GET().build();
        var response = client.send(req, HttpResponse.BodyHandlers.ofByteArray());
        if (response.statusCode() != 200) throw new IOException("HTTP "+response.statusCode()+" for "+url);
        return response.body();
    }
    public static void main(String[] args) throws Exception {
        if (args.length != 1) throw new IllegalArgumentException("Usage: java WrapperDownloader.java <target.jar>");
        Path dest=Path.of(args[0]);
        HttpClient client=HttpClient.newBuilder().followRedirects(HttpClient.Redirect.NORMAL).connectTimeout(Duration.ofSeconds(30)).build();
        byte[] bytes=request(client,URL);
        String expected=new String(request(client,URL+".sha256"),java.nio.charset.StandardCharsets.US_ASCII).trim().split("\\s+")[0].toLowerCase();
        String actual=HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));
        if(!expected.matches("[a-f0-9]{64}") || !actual.equals(expected)) throw new SecurityException("Gradle wrapper SHA-256 verification failed");
        Files.createDirectories(dest.toAbsolutePath().getParent());
        Path tmp=Files.createTempFile(dest.toAbsolutePath().getParent(),"efhc-gradle-wrapper-",".jar");
        try {
            Files.write(tmp, bytes);
            try(ZipFile jar=new ZipFile(tmp.toFile())) {
                if(jar.getEntry("org/gradle/wrapper/GradleWrapperMain.class") == null)throw new SecurityException("Missing GradleWrapperMain");
            }
            Files.move(tmp,dest,StandardCopyOption.REPLACE_EXISTING);
        } finally {Files.deleteIfExists(tmp);}
        System.out.println("[PASS] Official Gradle 8.13 wrapper JAR downloaded and SHA-256 checked");
    }
}
