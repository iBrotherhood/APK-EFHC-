import java.io.InputStream;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.util.HexFormat;

public final class WrapperDownloader {
    private static final String URL =
        "https://github.com/gradle/gradle/raw/refs/tags/v8.13.0/gradle/wrapper/gradle-wrapper.jar";
    private static final String EXPECTED_SHA256 =
        "81a82aaea5abcc8ff68b3dfcb58b3c3c429378efd98e7433460610fecd7ae45f";

    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            throw new IllegalArgumentException("Expected output path");
        }
        Path output = Path.of(args[0]);
        Files.createDirectories(output.getParent());
        Path temporary = Files.createTempFile(output.getParent(), "gradle-wrapper-", ".jar");
        try (InputStream input = URI.create(URL).toURL().openStream()) {
            Files.copy(input, temporary, StandardCopyOption.REPLACE_EXISTING);
        }
        String actual = HexFormat.of().formatHex(
            MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(temporary))
        );
        if (!EXPECTED_SHA256.equals(actual)) {
            Files.deleteIfExists(temporary);
            throw new SecurityException("Unexpected gradle-wrapper.jar SHA-256: " + actual);
        }
        Files.move(temporary, output, StandardCopyOption.REPLACE_EXISTING);
        System.out.println("Gradle wrapper JAR verified: " + actual);
    }
}
