import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.HexFormat;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

/**
 * Recover the release Gradle 8.13 wrapper from the official, checksum-verified
 * distribution archive. Gradle does not publish a standalone wrapper JAR
 * at /distributions/gradle-8.13-wrapper.jar (that URL returns HTTP 404).
 * The official Gradle wrapper is nested inside gradle-wrapper-main-8.13.jar.
 * No change to Gradle version or Android source is needed.
 */
public class WrapperDownloader {
    private static final String DISTRIBUTION_URL =
        "https://downloads.gradle.org/distributions/gradle-8.13-bin.zip";
    private static final String FALLBACK_DISTRIBUTION_URL =
        "https://services.gradle.org/distributions/gradle-8.13-bin.zip";
    private static final String DISTRIBUTION_SHA256 =
        "20f1b1176237254a6fc204d8434196fa11a4cfb387567519c61556e8710aed78";
    private static final String WRAPPER_SHA256 =
        "81a82aaea5abcc8ff68b3dfcb58b3c3c429378efd98e7433460610fecd7ae45f";
    private static final String WRAPPER_MAIN_PATH =
        "gradle-8.13/lib/plugins/gradle-wrapper-main-8.13.jar";

    private static String sha256(Path file) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        try (InputStream in = Files.newInputStream(file)) {
            byte[] buffer = new byte[1024 * 1024];
            int n;
            while ((n = in.read(buffer)) != -1) md.update(buffer, 0, n);
        }
        return HexFormat.of().formatHex(md.digest());
    }
    private static String sha256(byte[] data) throws Exception {
        return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(data));
    }

    // Package-visible so a local synthetic ZIP-within-ZIP can test extraction
    // without accessing the network or downloading 130 MB.
    static byte[] extractWrapper(Path distribution) throws Exception {
        try (ZipFile zip = new ZipFile(distribution.toFile())) {
            ZipEntry main = zip.getEntry(WRAPPER_MAIN_PATH);
            if (main == null) throw new IOException("Missing official " + WRAPPER_MAIN_PATH);
            try (ZipInputStream nested = new ZipInputStream(zip.getInputStream(main))) {
                ZipEntry entry;
                while ((entry = nested.getNextEntry()) != null) {
                    if (entry.getName().equals("gradle-wrapper.jar")) {
                        byte[] bytes = nested.readNBytes(4 * 1024 * 1024 + 1);
                        if (bytes.length > 4 * 1024 * 1024) {
                            throw new SecurityException("Wrapper JAR unusually large");
                        }
                        try (ZipInputStream wrapper =
                                new ZipInputStream(new java.io.ByteArrayInputStream(bytes))) {
                            boolean found = false;
                            ZipEntry wrapperEntry;
                            while ((wrapperEntry = wrapper.getNextEntry()) != null) {
                                if (wrapperEntry.getName().equals(
                                    "org/gradle/wrapper/GradleWrapperMain.class")) {
                                    found = true;
                                    break;
                                }
                            }
                            if (!found) throw new SecurityException("GradleWrapperMain missing");
                        }
                        return bytes;
                    }
                }
            }
        }
        throw new IOException("gradle-wrapper.jar not present in official wrapper-main JAR");
    }

    private static void download(HttpClient client, String url, Path destination) throws Exception {
        HttpRequest request = HttpRequest.newBuilder(URI.create(url))
            .timeout(Duration.ofMinutes(12)).GET().build();
        HttpResponse<Path> response = client.send(request, HttpResponse.BodyHandlers.ofFile(destination));
        if (response.statusCode() != 200) {
            throw new IOException("HTTP " + response.statusCode() + " for " + url);
        }
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            throw new IllegalArgumentException("Usage: java WrapperDownloader.java <target.jar>");
        }
        Path destination = Path.of(args[0]).toAbsolutePath();
        Files.createDirectories(destination.getParent());
        Path dist = Files.createTempFile("efhc-gradle-8.13-verified-", ".zip");
        Path tmpJar = Files.createTempFile(destination.getParent(), "efhc-gradle-wrapper-", ".jar");
        try {
            HttpClient client = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(40))
                .followRedirects(HttpClient.Redirect.NORMAL).build();
            try {
                download(client, DISTRIBUTION_URL, dist);
            } catch (Exception first) {
                System.err.println("Primary Gradle CDN unavailable; using official fallback: " + first);
                Files.deleteIfExists(dist);
                download(client, FALLBACK_DISTRIBUTION_URL, dist);
            }
            String distActual = sha256(dist);
            if (!DISTRIBUTION_SHA256.equals(distActual)) {
                throw new SecurityException("Gradle 8.13 distribution SHA-256 mismatch: " + distActual);
            }
            byte[] bytes = extractWrapper(dist);
            String actual = sha256(bytes);
            if (!WRAPPER_SHA256.equals(actual)) {
                throw new SecurityException("Gradle 8.13 official wrapper SHA-256 mismatch: " + actual);
            }
            Files.write(tmpJar, bytes);
            Files.move(tmpJar, destination, StandardCopyOption.REPLACE_EXISTING);
            System.out.println("[PASS] Official Gradle 8.13 distribution SHA-256 verified");
            System.out.println("[PASS] Official Gradle 8.13 wrapper JAR SHA-256 verified");
        } finally {
            Files.deleteIfExists(dist);
            Files.deleteIfExists(tmpJar);
        }
    }
}
