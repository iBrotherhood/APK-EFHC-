package org.federationofavatars.efhc.simulator
import org.junit.Assert.assertEquals
import org.junit.Test
class SimulatorContractTest {
    @Test fun runtimeModeIsOfflineSimulator() { assertEquals("offline_simulator", BuildConfig.RUNTIME_MODE) }
}
