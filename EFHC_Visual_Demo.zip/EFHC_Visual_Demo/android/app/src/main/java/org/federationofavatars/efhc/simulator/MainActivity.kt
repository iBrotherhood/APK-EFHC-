package org.federationofavatars.efhc.simulator

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.webkit.MimeTypeMap
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.webkit.WebViewAssetLoader
import java.io.BufferedInputStream
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipInputStream

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val webRoot = SimulatorWebBundle.install(this)
        val assetLoader = WebViewAssetLoader.Builder()
            .setDomain(WebViewAssetLoader.DEFAULT_DOMAIN)
            .addPathHandler("/", SimulatorFilesPathHandler(webRoot))
            .build()

        webView = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.mediaPlaybackRequiresUserGesture = true
            settings.setSupportZoom(false)
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView,
                    request: WebResourceRequest,
                ): WebResourceResponse? {
                    if (request.url.host != WebViewAssetLoader.DEFAULT_DOMAIN) return forbidden()
                    return assetLoader.shouldInterceptRequest(request.url) ?: notFound()
                }

                override fun shouldOverrideUrlLoading(
                    view: WebView,
                    request: WebResourceRequest,
                ): Boolean = request.url.host != WebViewAssetLoader.DEFAULT_DOMAIN
            }
        }

        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    if (::webView.isInitialized && webView.canGoBack()) {
                        webView.goBack()
                    } else {
                        finish()
                    }
                }
            },
        )

        setContentView(webView)
        webView.loadUrl("https://${WebViewAssetLoader.DEFAULT_DOMAIN}/index.html")
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.clearHistory()
            webView.removeAllViews()
            webView.destroy()
        }
        super.onDestroy()
    }

    private fun forbidden() = WebResourceResponse(
        "text/plain",
        "UTF-8",
        403,
        "Forbidden",
        emptyMap(),
        ByteArrayInputStream("Offline simulator blocks external network access".toByteArray()),
    )

    private fun notFound() = WebResourceResponse(
        "text/plain",
        "UTF-8",
        404,
        "Not Found",
        emptyMap(),
        ByteArrayInputStream("Asset not found".toByteArray()),
    )
}

private object SimulatorWebBundle {
    private const val BUNDLE_ASSET = "web/web-bundle.zip"
    private const val CONTRACT_ASSET = "web/simulator-contract.json"
    private const val MAX_ENTRY_COUNT = 10_000
    private const val MAX_EXPANDED_BYTES = 192L * 1024L * 1024L

    @Synchronized
    fun install(context: Context): File {
        val target = File(context.filesDir, "simulator-web-${BuildConfig.VERSION_CODE}")
        if (isValidInstallation(context, target)) return target

        val temporary = File(context.filesDir, "simulator-web-${BuildConfig.VERSION_CODE}.tmp")
        temporary.deleteRecursively()
        check(temporary.mkdirs()) { "Unable to create simulator extraction directory" }

        try {
            extract(context, temporary)
            verify(context, temporary)
            File(temporary, ".ready").writeText(BuildConfig.VERSION_NAME, Charsets.UTF_8)

            target.deleteRecursively()
            if (!temporary.renameTo(target)) {
                check(temporary.copyRecursively(target, overwrite = true)) {
                    "Unable to install simulator web bundle"
                }
                temporary.deleteRecursively()
            }
            check(isValidInstallation(context, target)) {
                "Installed simulator web bundle failed validation"
            }
            return target
        } catch (error: Exception) {
            temporary.deleteRecursively()
            throw error
        }
    }

    private fun isValidInstallation(context: Context, root: File): Boolean = try {
        File(root, ".ready").isFile &&
            File(root, "index.html").isFile &&
            File(root, "simulator-contract.json").isFile &&
            contractBytes(context).contentEquals(File(root, "simulator-contract.json").readBytes())
    } catch (_: Exception) {
        false
    }

    private fun contractBytes(context: Context): ByteArray =
        context.assets.open(CONTRACT_ASSET).use { it.readBytes() }

    private fun verify(context: Context, root: File) {
        val index = File(root, "index.html")
        val contract = File(root, "simulator-contract.json")
        check(index.isFile && index.length() > 0L) { "Offline simulator index is missing" }
        check(contract.isFile && contract.length() > 0L) { "Offline simulator contract is missing" }
        check(contractBytes(context).contentEquals(contract.readBytes())) {
            "Offline simulator contract mismatch"
        }
    }

    private fun extract(context: Context, destination: File) {
        val destinationPath = destination.canonicalPath + File.separator
        var entries = 0
        var expandedBytes = 0L
        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)

        ZipInputStream(BufferedInputStream(context.assets.open(BUNDLE_ASSET))).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                entries += 1
                check(entries <= MAX_ENTRY_COUNT) { "Simulator web bundle has too many entries" }

                val output = File(destination, entry.name)
                val outputPath = output.canonicalPath
                check(outputPath.startsWith(destinationPath)) {
                    "Unsafe simulator web bundle path: ${entry.name}"
                }

                if (entry.isDirectory) {
                    check(output.mkdirs() || output.isDirectory) {
                        "Unable to create simulator directory: ${entry.name}"
                    }
                } else {
                    val parent = output.parentFile
                    check(parent == null || parent.mkdirs() || parent.isDirectory) {
                        "Unable to create simulator parent directory: ${entry.name}"
                    }
                    FileOutputStream(output).use { sink ->
                        while (true) {
                            val read = zip.read(buffer)
                            if (read < 0) break
                            expandedBytes += read
                            check(expandedBytes <= MAX_EXPANDED_BYTES) {
                                "Simulator web bundle exceeds expanded size limit"
                            }
                            sink.write(buffer, 0, read)
                        }
                    }
                }
                zip.closeEntry()
            }
        }
        check(entries > 0) { "Simulator web bundle is empty" }
    }
}

private class SimulatorFilesPathHandler(private val root: File) : WebViewAssetLoader.PathHandler {
    private val canonicalRoot = root.canonicalPath + File.separator

    override fun handle(path: String): WebResourceResponse? {
        val normalized = path.substringBefore('?').trimStart('/').let { raw ->
            when {
                raw.isBlank() -> "index.html"
                raw.endsWith("/") -> "${raw}index.html"
                raw.substringAfterLast('/').contains('.') -> raw
                else -> "$raw/index.html"
            }
        }
        if (normalized.split('/').any { it == ".." }) return null

        val file = File(root, normalized)
        val canonicalFile = try {
            file.canonicalFile
        } catch (_: Exception) {
            return null
        }
        if (!canonicalFile.path.startsWith(canonicalRoot) || !canonicalFile.isFile) return null

        return try {
            WebResourceResponse(mime(normalized), "UTF-8", FileInputStream(canonicalFile)).apply {
                responseHeaders = mapOf(
                    "Cache-Control" to "no-cache",
                    "X-EFHC-Simulator" to "offline",
                    "Content-Security-Policy" to "default-src 'self' data: blob:; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; connect-src 'self'; frame-src 'self'; object-src 'none'",
                )
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun mime(path: String): String = when (path.substringAfterLast('.', "").lowercase()) {
        "html" -> "text/html"
        "js" -> "application/javascript"
        "css" -> "text/css"
        "json", "webmanifest" -> "application/json"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "webp" -> "image/webp"
        "svg" -> "image/svg+xml"
        "woff" -> "font/woff"
        "woff2" -> "font/woff2"
        else -> MimeTypeMap.getSingleton()
            .getMimeTypeFromExtension(path.substringAfterLast('.'))
            ?: "application/octet-stream"
    }
}
