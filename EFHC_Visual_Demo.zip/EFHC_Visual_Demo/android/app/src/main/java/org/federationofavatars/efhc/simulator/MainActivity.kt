package org.federationofavatars.efhc.simulator

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.MimeTypeMap
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.webkit.WebViewAssetLoader
import java.io.ByteArrayInputStream

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val assetLoader = WebViewAssetLoader.Builder()
            .setDomain(WebViewAssetLoader.DEFAULT_DOMAIN)
            .addPathHandler("/", SimulatorAssetsPathHandler(this))
            .build()

        webView = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.mediaPlaybackRequiresUserGesture = true
            settings.setSupportZoom(false)
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView,
                    request: WebResourceRequest,
                ): WebResourceResponse? {
                    if (request.url.host != WebViewAssetLoader.DEFAULT_DOMAIN) return forbidden()
                    return assetLoader.shouldInterceptRequest(request.url) ?: notFound()
                }

                override fun shouldOverrideUrlLoading(
                    view: WebView,
                    request: WebResourceRequest,
                ): Boolean = request.url.host != WebViewAssetLoader.DEFAULT_DOMAIN
            }
        }

        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    if (::webView.isInitialized && webView.canGoBack()) {
                        webView.goBack()
                    } else {
                        finish()
                    }
                }
            },
        )

        setContentView(webView)
        webView.loadUrl("https://${WebViewAssetLoader.DEFAULT_DOMAIN}/index.html")
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.clearHistory()
            webView.removeAllViews()
            webView.destroy()
        }
        super.onDestroy()
    }

    private fun forbidden() = WebResourceResponse(
        "text/plain",
        "UTF-8",
        403,
        "Forbidden",
        emptyMap(),
        ByteArrayInputStream("Offline simulator blocks external network access".toByteArray()),
    )

    private fun notFound() = WebResourceResponse(
        "text/plain",
        "UTF-8",
        404,
        "Not Found",
        emptyMap(),
        ByteArrayInputStream("Asset not found".toByteArray()),
    )
}

private class SimulatorAssetsPathHandler(private val activity: Activity) : WebViewAssetLoader.PathHandler {
    override fun handle(path: String): WebResourceResponse? {
        val normalized = path.substringBefore('?').trimStart('/').let { raw ->
            when {
                raw.isBlank() -> "index.html"
                raw.endsWith("/") -> "${raw}index.html"
                raw.substringAfterLast('/').contains('.') -> raw
                else -> "$raw/index.html"
            }
        }
        val assetPath = "web/$normalized"
        return try {
            val stream = activity.assets.open(assetPath)
            WebResourceResponse(mime(normalized), "UTF-8", stream).apply {
                responseHeaders = mapOf(
                    "Cache-Control" to "no-cache",
                    "X-EFHC-Simulator" to "offline",
                    "Content-Security-Policy" to "default-src 'self' data: blob:; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; connect-src 'self'; frame-src 'self'; object-src 'none'",
                )
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun mime(path: String): String = when (path.substringAfterLast('.', "").lowercase()) {
        "html" -> "text/html"
        "js" -> "application/javascript"
        "css" -> "text/css"
        "json", "webmanifest" -> "application/json"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "webp" -> "image/webp"
        "svg" -> "image/svg+xml"
        "woff" -> "font/woff"
        "woff2" -> "font/woff2"
        else -> MimeTypeMap.getSingleton()
            .getMimeTypeFromExtension(path.substringAfterLast('.'))
            ?: "application/octet-stream"
    }
}
