package org.federationofavatars.efhc.simulator

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.graphics.Color
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import java.io.ByteArrayInputStream

/** EFHC original v865 standalone, in a strictly offline Android WebView. */
class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val origin = "appassets.androidplatform.net"
    private val entry = "https://appassets.androidplatform.net/assets/web/index.html"
    private val shop = "https://appassets.androidplatform.net/assets/web/shop.html"
    private val assetLoader by lazy {
        WebViewAssetLoader.Builder()
            .setDomain(origin)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(5, 8, 13)
        window.navigationBarColor = Color.rgb(5, 8, 13)
        webView = WebView(this)
        webView.setBackgroundColor(Color.rgb(5, 8, 13))
        webView.settings.apply {
            javaScriptEnabled = true // Required for the original locally bundled v865 UI.
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            blockNetworkLoads = true
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically = false
            mediaPlaybackRequiresUserGesture = true
        }
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                if (request.url.host == origin && request.url.path?.startsWith("/assets/web/") == true) {
                    return assetLoader.shouldInterceptRequest(request.url)
                        ?: WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0)))
                }
                return WebResourceResponse("text/plain", "UTF-8", 403, "Offline", emptyMap(), ByteArrayInputStream(ByteArray(0)))
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                if (url.scheme == "https" && url.host == origin && url.path?.startsWith("/assets/web/") == true) return false
                if (url.host == "efhc.app" && url.path == "/browser-shop") {
                    view.loadUrl(shop)
                    return true
                }
                if (request.isForMainFrame) Toast.makeText(this@MainActivity,"Автономная демонстрация: внешний переход отключён",Toast.LENGTH_SHORT).show()
                return true
            }
        }
        setContentView(webView)
        if (savedInstanceState == null) webView.loadUrl(entry)
        else webView.restoreState(savedInstanceState)
    }
    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }
    @Deprecated("Legacy Android back handling")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
