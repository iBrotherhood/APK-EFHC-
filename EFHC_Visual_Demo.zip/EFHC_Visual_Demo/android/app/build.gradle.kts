plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "org.federationofavatars.efhc.simulator"
    compileSdk = 36
    defaultConfig {
        applicationId = "org.federationofavatars.efhc.simulator"
        minSdk = 26
        targetSdk = 36
        versionCode = 865
        versionName = "865.0"
    }
    buildFeatures {
        buildConfig = true
    }
    buildTypes {
        getByName("debug") {
            isDebuggable = true
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint { abortOnError = true }
}
dependencies {
    implementation("androidx.webkit:webkit:1.14.0")
}
