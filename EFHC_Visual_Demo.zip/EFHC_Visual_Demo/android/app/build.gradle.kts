plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val developmentSigningStore = System.getenv("EFHC_DEMO_DEV_SIGNING_STORE_FILE")
val developmentSigningStorePassword = System.getenv("EFHC_DEMO_DEV_SIGNING_STORE_PASSWORD")
val developmentSigningKeyAlias = System.getenv("EFHC_DEMO_DEV_SIGNING_KEY_ALIAS")
val developmentSigningKeyPassword = System.getenv("EFHC_DEMO_DEV_SIGNING_KEY_PASSWORD")
val signingValues = listOf(developmentSigningStore, developmentSigningStorePassword, developmentSigningKeyAlias, developmentSigningKeyPassword)
val signingAny = signingValues.any { !it.isNullOrBlank() }
val signingEnabled = signingValues.all { !it.isNullOrBlank() }
if (signingAny && !signingEnabled) throw GradleException("Incomplete EFHC simulator Development signing configuration.")

android {
    namespace = "org.federationofavatars.efhc.simulator"
    compileSdk = 36
    defaultConfig {
        applicationId = "org.federationofavatars.efhc.simulator"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "0.1.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        buildConfigField("String", "RUNTIME_MODE", "\"offline_simulator\"")
    }
    signingConfigs {
        if (signingEnabled) create("development") {
            storeFile = file(requireNotNull(developmentSigningStore))
            storePassword = requireNotNull(developmentSigningStorePassword)
            keyAlias = requireNotNull(developmentSigningKeyAlias)
            keyPassword = requireNotNull(developmentSigningKeyPassword)
            enableV1Signing = true; enableV2Signing = true; enableV3Signing = true; enableV4Signing = true
        }
    }
    buildTypes {
        debug { isDebuggable = true; if (signingEnabled) signingConfig = signingConfigs.getByName("development") }
        release { isMinifyEnabled = true; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro") }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlin { jvmToolchain(17) }
    buildFeatures { buildConfig = true }
}

dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.webkit:webkit:1.14.0")
    testImplementation("junit:junit:4.13.2")
}
