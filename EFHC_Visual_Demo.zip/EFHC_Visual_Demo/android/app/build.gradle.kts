import java.util.zip.ZipFile

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val developmentSigningStore = System.getenv("EFHC_DEMO_DEV_SIGNING_STORE_FILE")
val developmentSigningStorePassword = System.getenv("EFHC_DEMO_DEV_SIGNING_STORE_PASSWORD")
val developmentSigningKeyAlias = System.getenv("EFHC_DEMO_DEV_SIGNING_KEY_ALIAS")
val developmentSigningKeyPassword = System.getenv("EFHC_DEMO_DEV_SIGNING_KEY_PASSWORD")
val signingValues = listOf(
    developmentSigningStore,
    developmentSigningStorePassword,
    developmentSigningKeyAlias,
    developmentSigningKeyPassword,
)
val signingAny = signingValues.any { !it.isNullOrBlank() }
val signingEnabled = signingValues.all { !it.isNullOrBlank() }
if (signingAny && !signingEnabled) {
    throw GradleException("Incomplete EFHC simulator Development signing configuration.")
}

val simulatorContractSource = rootProject.file("../SIMULATOR_CONTRACT.json")
val simulatorSourceAssets = file("src/main/assets")
val generatedSimulatorAssets = layout.buildDirectory.dir(
    "generated/efhcSimulatorAssets/main",
)

val prepareSimulatorAssets = tasks.register<Sync>("prepareSimulatorAssets") {
    group = "efhc simulator"
    description = "Creates the complete generated Android asset tree for the offline simulator."
    from(simulatorSourceAssets)
    into(generatedSimulatorAssets)
    includeEmptyDirs = false
    inputs.dir(simulatorSourceAssets)
    inputs.file(simulatorContractSource)
    outputs.dir(generatedSimulatorAssets)

    doFirst {
        val sourceIndex = simulatorSourceAssets.resolve("web/index.html")
        val sourceContract = simulatorSourceAssets.resolve(
            "web/simulator-contract.json",
        )
        if (!sourceIndex.isFile || sourceIndex.length() == 0L) {
            throw GradleException(
                "Missing offline web entrypoint: ${sourceIndex.absolutePath}",
            )
        }
        if (!sourceContract.isFile || sourceContract.length() == 0L) {
            throw GradleException(
                "Missing source simulator contract asset: ${sourceContract.absolutePath}",
            )
        }
        if (!simulatorContractSource.isFile) {
            throw GradleException(
                "Missing canonical simulator contract: ${simulatorContractSource.absolutePath}",
            )
        }
        if (!sourceContract.readBytes().contentEquals(simulatorContractSource.readBytes())) {
            throw GradleException("Source simulator contract differs from the canonical contract.")
        }
    }

    doLast {
        val outputRoot = generatedSimulatorAssets.get().asFile
        val outputIndex = outputRoot.resolve("web/index.html")
        val outputContract = outputRoot.resolve("web/simulator-contract.json")
        if (!outputIndex.isFile || outputIndex.length() == 0L) {
            throw GradleException(
                "Generated offline web entrypoint is missing: ${outputIndex.absolutePath}",
            )
        }
        if (!outputContract.isFile || outputContract.length() == 0L) {
            throw GradleException(
                "Generated simulator contract is missing: ${outputContract.absolutePath}",
            )
        }
        if (!outputContract.readBytes().contentEquals(simulatorContractSource.readBytes())) {
            throw GradleException("Generated simulator contract differs from the canonical contract.")
        }
    }
}

prepareSimulatorAssets.configure {
    mustRunAfter("clean")
}

android {
    namespace = "org.federationofavatars.efhc.simulator"
    compileSdk = 36

    defaultConfig {
        applicationId = "org.federationofavatars.efhc.simulator"
        minSdk = 26
        targetSdk = 36
        versionCode = 4
        versionName = "0.1.3"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        buildConfigField("String", "RUNTIME_MODE", "\"offline_simulator\"")
    }

    // Android packages only this immutable generated tree. The frontend build
    // still writes source assets under src/main/assets for the canonical CI
    // pre-build gate, then this task snapshots the complete tree for AAPT.
    sourceSets {
        getByName("main").assets.setSrcDirs(
            listOf(generatedSimulatorAssets.get().asFile),
        )
    }

    androidResources {
        noCompress += listOf("json")
    }

    signingConfigs {
        if (signingEnabled) {
            create("development") {
                storeFile = file(requireNotNull(developmentSigningStore))
                storePassword = requireNotNull(developmentSigningStorePassword)
                keyAlias = requireNotNull(developmentSigningKeyAlias)
                keyPassword = requireNotNull(developmentSigningKeyPassword)
                enableV1Signing = true
                enableV2Signing = true
                enableV3Signing = true
                enableV4Signing = true
            }
        }
    }

    buildTypes {
        debug {
            isDebuggable = true
            if (signingEnabled) {
                signingConfig = signingConfigs.getByName("development")
            }
        }
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlin {
        jvmToolchain(17)
    }
    buildFeatures {
        buildConfig = true
    }
}

tasks.matching {
    it.name == "preBuild" ||
        (it.name.startsWith("merge") && it.name.endsWith("Assets"))
}.configureEach {
    dependsOn(prepareSimulatorAssets)
}

val verifyDebugApkContainsSimulatorContract = tasks.register(
    "verifyDebugApkContainsSimulatorContract",
) {
    group = "verification"
    description = "Verifies required offline assets and canonical contract bytes inside the debug APK."
    dependsOn("packageDebug")

    doLast {
        val apkDirectory = layout.buildDirectory.dir(
            "outputs/apk/debug",
        ).get().asFile
        val apks = fileTree(apkDirectory) {
            include("*.apk")
        }.files.sortedBy { it.name }
        if (apks.size != 1) {
            throw GradleException(
                "Expected exactly one debug APK, found ${apks.size}: $apks",
            )
        }

        ZipFile(apks.single()).use { zip ->
            val indexEntry = zip.getEntry("assets/web/index.html")
                ?: throw GradleException(
                    "Required APK asset is missing: assets/web/index.html",
                )
            if (indexEntry.size == 0L) {
                throw GradleException(
                    "Required APK asset is empty: assets/web/index.html",
                )
            }

            val contractEntry = zip.getEntry(
                "assets/web/simulator-contract.json",
            ) ?: throw GradleException(
                "Required APK asset is missing: assets/web/simulator-contract.json",
            )
            if (contractEntry.size == 0L) {
                throw GradleException(
                    "Required APK asset is empty: assets/web/simulator-contract.json",
                )
            }
            val embeddedContract = zip.getInputStream(contractEntry).use {
                it.readBytes()
            }
            if (!embeddedContract.contentEquals(simulatorContractSource.readBytes())) {
                throw GradleException(
                    "Embedded simulator contract differs from the canonical contract.",
                )
            }
        }
        println(
            "[PASS] debug APK contains offline web entrypoint and canonical simulator contract",
        )
    }
}

// The canonical GitHub workflow invokes assembleDebug only. Make the APK
// content gate an intrinsic dependency of assembleDebug so no workflow edit
// is required and a malformed APK cannot be reported as assembled.
tasks.matching { it.name == "assembleDebug" }.configureEach {
    dependsOn(verifyDebugApkContainsSimulatorContract)
}

dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.activity:activity-ktx:1.11.0")
    implementation("androidx.webkit:webkit:1.14.0")
    testImplementation("junit:junit:4.13.2")
}
