import java.util.zip.ZipFile

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val developmentSigningStore = System.getenv("EFHC_DEMO_DEV_SIGNING_STORE_FILE")
val developmentSigningStorePassword = System.getenv("EFHC_DEMO_DEV_SIGNING_STORE_PASSWORD")
val developmentSigningKeyAlias = System.getenv("EFHC_DEMO_DEV_SIGNING_KEY_ALIAS")
val developmentSigningKeyPassword = System.getenv("EFHC_DEMO_DEV_SIGNING_KEY_PASSWORD")
val signingValues = listOf(
    developmentSigningStore,
    developmentSigningStorePassword,
    developmentSigningKeyAlias,
    developmentSigningKeyPassword,
)
val signingAny = signingValues.any { !it.isNullOrBlank() }
val signingEnabled = signingValues.all { !it.isNullOrBlank() }
if (signingAny && !signingEnabled) {
    throw GradleException("Incomplete EFHC simulator Development signing configuration.")
}

val simulatorContractSource = rootProject.file("../SIMULATOR_CONTRACT.json")
val simulatorSourceAssets = file("src/main/assets")
val generatedSimulatorAssets = layout.buildDirectory.dir(
    "generated/efhcSimulatorAssets/main",
)

val prepareSimulatorAssets = tasks.register<Sync>("prepareSimulatorAssets") {
    group = "efhc simulator"
    description = "Creates the complete generated Android asset tree for the offline simulator."
    from(simulatorSourceAssets)
    into(generatedSimulatorAssets)
    includeEmptyDirs = false
    inputs.dir(simulatorSourceAssets)
    inputs.file(simulatorContractSource)
    outputs.dir(generatedSimulatorAssets)

    doFirst {
        val sourceIndex = simulatorSourceAssets.resolve("web/index.html")
        val sourceContract = simulatorSourceAssets.resolve(
            "web/simulator-contract.json",
        )
        val sourceBundle = simulatorSourceAssets.resolve("web/web-bundle.zip")
        if (!sourceIndex.isFile || sourceIndex.length() == 0L) {
            throw GradleException(
                "Missing offline web entrypoint: ${sourceIndex.absolutePath}",
            )
        }
        if (!sourceContract.isFile || sourceContract.length() == 0L) {
            throw GradleException(
                "Missing source simulator contract asset: ${sourceContract.absolutePath}",
            )
        }
        if (!sourceBundle.isFile || sourceBundle.length() == 0L) {
            throw GradleException(
                "Missing source offline web bundle: ${sourceBundle.absolutePath}",
            )
        }
        if (!simulatorContractSource.isFile) {
            throw GradleException(
                "Missing canonical simulator contract: ${simulatorContractSource.absolutePath}",
            )
        }
        if (!sourceContract.readBytes().contentEquals(simulatorContractSource.readBytes())) {
            throw GradleException("Source simulator contract differs from the canonical contract.")
        }
    }

    doLast {
        val outputRoot = generatedSimulatorAssets.get().asFile
        val outputIndex = outputRoot.resolve("web/index.html")
        val outputContract = outputRoot.resolve("web/simulator-contract.json")
        val outputBundle = outputRoot.resolve("web/web-bundle.zip")
        if (!outputIndex.isFile || outputIndex.length() == 0L) {
            throw GradleException(
                "Generated offline web entrypoint is missing: ${outputIndex.absolutePath}",
            )
        }
        if (!outputContract.isFile || outputContract.length() == 0L) {
            throw GradleException(
                "Generated simulator contract is missing: ${outputContract.absolutePath}",
            )
        }
        if (!outputBundle.isFile || outputBundle.length() == 0L) {
            throw GradleException(
                "Generated offline web bundle is missing: ${outputBundle.absolutePath}",
            )
        }
        if (!outputContract.readBytes().contentEquals(simulatorContractSource.readBytes())) {
            throw GradleException("Generated simulator contract differs from the canonical contract.")
        }
    }
}

prepareSimulatorAssets.configure {
    mustRunAfter("clean")
}

android {
    namespace = "org.federationofavatars.efhc.simulator"
    compileSdk = 36

    defaultConfig {
        applicationId = "org.federationofavatars.efhc.simulator"
        minSdk = 26
        targetSdk = 36
        versionCode = 6
        versionName = "0.2.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        buildConfigField("String", "RUNTIME_MODE", "\"offline_simulator\"")
    }

    // Android packages only this immutable generated tree. The frontend build
    // still writes source assets under src/main/assets for the canonical CI
    // pre-build gate, then this task snapshots the complete tree for AAPT.
    sourceSets {
        getByName("main").assets.setSrcDirs(
            listOf(generatedSimulatorAssets.get().asFile),
        )
    }

    androidResources {
        noCompress += listOf("json", "zip")
    }

    signingConfigs {
        if (signingEnabled) {
            create("development") {
                storeFile = file(requireNotNull(developmentSigningStore))
                storePassword = requireNotNull(developmentSigningStorePassword)
                keyAlias = requireNotNull(developmentSigningKeyAlias)
                keyPassword = requireNotNull(developmentSigningKeyPassword)
                enableV1Signing = true
                enableV2Signing = true
                enableV3Signing = true
                enableV4Signing = true
            }
        }
    }

    buildTypes {
        debug {
            isDebuggable = true
            if (signingEnabled) {
                signingConfig = signingConfigs.getByName("development")
            }
        }
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlin {
        jvmToolchain(17)
    }
    buildFeatures {
        buildConfig = true
    }
}

tasks.matching {
    it.name == "preBuild" ||
        (it.name.startsWith("merge") && it.name.endsWith("Assets"))
}.configureEach {
    dependsOn(prepareSimulatorAssets)
}

val verifyDebugApkContainsSimulatorContract = tasks.register(
    "verifyDebugApkContainsSimulatorContract",
) {
    group = "verification"
    description = "Verifies compact offline assets, contract bytes and the canonical CI probe against the debug APK."
    dependsOn("packageDebug")

    doLast {
        val apkDirectory = layout.buildDirectory.dir(
            "outputs/apk/debug",
        ).get().asFile
        val apks = fileTree(apkDirectory) {
            include("*.apk")
        }.files.sortedBy { it.name }
        if (apks.size != 1) {
            throw GradleException(
                "Expected exactly one debug APK, found ${apks.size}: $apks",
            )
        }
        val apk = apks.single()
        val requiredWebAssets = setOf(
            "assets/web/index.html",
            "assets/web/simulator-contract.json",
            "assets/web/web-bundle.zip",
        )

        ZipFile(apk).use { zip ->
            val apkEntries = zip.entries().asSequence().map { it.name }.toList()
            val packagedWebAssets = apkEntries.filter { it.startsWith("assets/web/") }.toSet()
            if (packagedWebAssets != requiredWebAssets) {
                throw GradleException(
                    "Unexpected compact web asset inventory. Expected $requiredWebAssets, found $packagedWebAssets",
                )
            }

            for (asset in requiredWebAssets) {
                val entry = zip.getEntry(asset)
                    ?: throw GradleException("Required APK asset is missing: $asset")
                if (entry.size == 0L) {
                    throw GradleException("Required APK asset is empty: $asset")
                }
            }

            val contractEntry = zip.getEntry("assets/web/simulator-contract.json")
                ?: throw GradleException(
                    "Required APK asset is missing: assets/web/simulator-contract.json",
                )
            val embeddedContract = zip.getInputStream(contractEntry).use {
                it.readBytes()
            }
            if (!embeddedContract.contentEquals(simulatorContractSource.readBytes())) {
                throw GradleException(
                    "Embedded simulator contract differs from the canonical contract.",
                )
            }

            val bundleEntry = zip.getEntry("assets/web/web-bundle.zip")
                ?: throw GradleException("Required APK asset is missing: assets/web/web-bundle.zip")
            val temporaryBundle = temporaryDir.resolve("web-bundle.zip")
            zip.getInputStream(bundleEntry).use { source ->
                temporaryBundle.outputStream().use { sink -> source.copyTo(sink) }
            }
            ZipFile(temporaryBundle).use { bundle ->
                val index = bundle.getEntry("index.html")
                    ?: throw GradleException("Offline web bundle does not contain index.html")
                val contract = bundle.getEntry("simulator-contract.json")
                    ?: throw GradleException(
                        "Offline web bundle does not contain simulator-contract.json",
                    )
                if (index.size == 0L || contract.size == 0L) {
                    throw GradleException("Offline web bundle contains an empty required entry")
                }
                val bundledContract = bundle.getInputStream(contract).use { it.readBytes() }
                if (!bundledContract.contentEquals(simulatorContractSource.readBytes())) {
                    throw GradleException(
                        "Bundled simulator contract differs from the canonical contract.",
                    )
                }
            }
        }

        // Reproduce the immutable workflow's exact pipefail-sensitive probe.
        // The compact inventory keeps the complete unzip listing below the pipe
        // buffer, so grep does not make upstream unzip/awk terminate with SIGPIPE.
        val canonicalProbe = ProcessBuilder(
            "bash",
            "-lc",
            "set -o pipefail; unzip -l \"\$APK\" | awk '{print \$4}' | grep -Fxq 'assets/web/simulator-contract.json'",
        )
            .redirectErrorStream(true)
            .apply { environment()["APK"] = apk.absolutePath }
            .start()
        val probeOutput = canonicalProbe.inputStream.bufferedReader().readText()
        val probeExit = canonicalProbe.waitFor()
        if (probeExit != 0) {
            throw GradleException(
                "Canonical CI contract probe failed with exit $probeExit: $probeOutput",
            )
        }

        println(
            "[PASS] debug APK contains compact offline bundle, canonical contract and passes the canonical CI probe",
        )
    }
}

// The canonical GitHub workflow invokes assembleDebug only. Make the APK
// content gate an intrinsic dependency of assembleDebug so no workflow edit
// is required and a malformed APK cannot be reported as assembled.
tasks.matching { it.name == "assembleDebug" }.configureEach {
    dependsOn(verifyDebugApkContainsSimulatorContract)
}

dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.activity:activity-ktx:1.11.0")
    implementation("androidx.webkit:webkit:1.14.0")
    testImplementation("junit:junit:4.13.2")
}
