import java.util.zip.ZipFile

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val developmentSigningStore = System.getenv("EFHC_DEMO_DEV_SIGNING_STORE_FILE")
val developmentSigningStorePassword = System.getenv("EFHC_DEMO_DEV_SIGNING_STORE_PASSWORD")
val developmentSigningKeyAlias = System.getenv("EFHC_DEMO_DEV_SIGNING_KEY_ALIAS")
val developmentSigningKeyPassword = System.getenv("EFHC_DEMO_DEV_SIGNING_KEY_PASSWORD")
val signingValues = listOf(developmentSigningStore, developmentSigningStorePassword, developmentSigningKeyAlias, developmentSigningKeyPassword)
val signingAny = signingValues.any { !it.isNullOrBlank() }
val signingEnabled = signingValues.all { !it.isNullOrBlank() }
if (signingAny && !signingEnabled) throw GradleException("Incomplete EFHC simulator Development signing configuration.")

val simulatorContractSource = rootProject.file("../SIMULATOR_CONTRACT.json")
val simulatorContractAsset = file("src/main/assets/web/simulator-contract.json")
val syncSimulatorContractAsset = tasks.register<Copy>("syncSimulatorContractAsset") {
    group = "efhc simulator"
    description = "Embeds the canonical offline simulator contract into Android assets."
    from(simulatorContractSource)
    into(simulatorContractAsset.parentFile)
    rename { simulatorContractAsset.name }
    inputs.file(simulatorContractSource)
    outputs.file(simulatorContractAsset)
    doFirst {
        if (!simulatorContractSource.isFile) {
            throw GradleException("Missing simulator contract: ${simulatorContractSource.absolutePath}")
        }
    }
    doLast {
        if (!simulatorContractAsset.isFile || simulatorContractAsset.length() == 0L) {
            throw GradleException("Simulator contract asset was not synchronized: ${simulatorContractAsset.absolutePath}")
        }
    }
}

android {
    namespace = "org.federationofavatars.efhc.simulator"
    compileSdk = 36
    defaultConfig {
        applicationId = "org.federationofavatars.efhc.simulator"
        minSdk = 26
        targetSdk = 36
        versionCode = 3
        versionName = "0.1.2"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        buildConfigField("String", "RUNTIME_MODE", "\"offline_simulator\"")
    }
    sourceSets {
        getByName("main").assets.srcDir("src/main/assets")
    }
    androidResources {
        noCompress += listOf("json")
    }
    signingConfigs {
        if (signingEnabled) create("development") {
            storeFile = file(requireNotNull(developmentSigningStore))
            storePassword = requireNotNull(developmentSigningStorePassword)
            keyAlias = requireNotNull(developmentSigningKeyAlias)
            keyPassword = requireNotNull(developmentSigningKeyPassword)
            enableV1Signing = true
            enableV2Signing = true
            enableV3Signing = true
            enableV4Signing = true
        }
    }
    buildTypes {
        debug {
            isDebuggable = true
            if (signingEnabled) signingConfig = signingConfigs.getByName("development")
        }
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlin { jvmToolchain(17) }
    buildFeatures { buildConfig = true }
}

tasks.matching {
    it.name == "preBuild" || (it.name.startsWith("merge") && it.name.endsWith("Assets"))
}.configureEach {
    dependsOn(syncSimulatorContractAsset)
}

val verifyDebugApkContainsSimulatorContract = tasks.register("verifyDebugApkContainsSimulatorContract") {
    group = "verification"
    description = "Verifies the offline simulator contract and web entrypoint inside the debug APK."
    dependsOn("assembleDebug")
    doLast {
        val apkDirectory = layout.buildDirectory.dir("outputs/apk/debug").get().asFile
        val apks = fileTree(apkDirectory) {
            include("*.apk")
        }.files.sortedBy { it.name }
        if (apks.size != 1) {
            throw GradleException("Expected exactly one debug APK, found ${apks.size}: $apks")
        }
        ZipFile(apks.single()).use { zip ->
            val requiredEntries = listOf(
                "assets/web/index.html",
                "assets/web/simulator-contract.json",
            )
            for (entryName in requiredEntries) {
                val entry = zip.getEntry(entryName)
                    ?: throw GradleException("Required APK asset is missing: $entryName")
                if (entry.size == 0L) {
                    throw GradleException("Required APK asset is empty: $entryName")
                }
            }
        }
        println("[PASS] debug APK contains offline web entrypoint and simulator contract")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.activity:activity-ktx:1.11.0")
    implementation("androidx.webkit:webkit:1.14.0")
    testImplementation("junit:junit:4.13.2")
}
