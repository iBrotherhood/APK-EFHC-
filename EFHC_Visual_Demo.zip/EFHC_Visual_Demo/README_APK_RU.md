# EFHC FRONTEND v865 — автономная визуальная APK-сборка

## Назначение

Это входной архив `EFHC_Visual_Demo.zip` для существующего GitHub Actions YAML
`iBrotherhood/APK-EFHC-/.github/workflows/android-build-efhc-offline-simulator.yml`.
Создан из исходного `FRONTEND_v865.zip`. Он содержит **полные исходные автономные
визуальные релизы** `FRONTEND_v865.html` и `SHOP_v865.html`, а не упрощённый макет.
Это **визуальный офлайн-симулятор**, не production-приложение с настоящим API.

## Сборка из GitHub

1. Переименовать скачанный пакет `EFHC_Visual_Demo_v865_APK_READY.zip` в `EFHC_Visual_Demo.zip`.
2. Загрузить **ZIP целиком, не распаковывая** в корень ветки `main` репозитория
   `iBrotherhood/APK-EFHC-`, рядом с каталогом `.github/`.
3. Перейти Actions → Build EFHC Offline Demo Simulator APK → запуск по push
   (или Run workflow на ветке main).
4. После успешной сборки скачать ZIP раздела Artifacts. Внутри — APK и проверки.

Важно: **не** загружать ZIP, названный `FRONTEND_v865.zip` — старый YAML ожидает
строгое имя `EFHC_Visual_Demo.zip`. ZIP должен содержать верхний каталог
`EFHC_Visual_Demo/`.

## Архитектура

- `frontend/source/FRONTEND_v865.html` — оригинальный standalone USER/ADMIN релиз.
- `frontend/source/SHOP_v865.html` — оригинальный standalone Browser Shop релиз.
- `frontend/scripts/apk-viewport.css` — только адаптер внешней демонстрационной рамки
  390×844 к реальному экрану Android; оригинальные страницы/CT/SVG не перепроектируются.
- `frontend/scripts/build-demo.mjs` — точное копирование HTML и внедрение адаптера;
  синхронизация `frontend/out/` и `android/app/src/main/assets/web/`.
- `android/` — Kotlin / Gradle WebView, работающий на локальных ресурсах.
- `SIMULATOR_CONTRACT.json` — режим `offline_simulator`, локальные данные,
  отключены production API, реальные финансовые операции и сеть.
- `SOURCE_MANIFEST.json` — SHA-256 оригинального архива и исходных HTML.

## Совместимость с проверками существующего YAML

- `npm ci --no-audit --no-fund`
- `npm run typecheck` (в этом staging-проекте это проверка целостности исходных JS/HTML,
  а не TypeScript typecheck React-кодовой базы)
- `npm run test:demo`
- `npm run build:demo`
- `./gradlew clean testDebugUnitTest lintDebug compileDebugKotlin assembleDebug`
- Android: `applicationId=org.federationofavatars.efhc.simulator`, `minSdk=26`, `targetSdk=36`.
- Debug APK при отсутствии development keystore может требовать удаления старого APK
  перед установкой новой версии из-за разных подписей.

## Ограничения

Действующие балансы, реальная авторизация/сессии, интеграции TON/Telegram и
финансовые операции **не подключаются**. Переходы во внешние сайты намеренно
блокируются. Иллюстративные сценарии работают только настолько, насколько они
реализованы в исходном standalone HTML `FRONTEND_v865`.

Заставка из исходного релиза v865 (цикл 0562) остаётся без изменений (5 секунд).

APK не собирался в этой среде: сборку выполняет GitHub Actions. Структура ZIP,
контракт, исходные SHA и локальные Node.js проверки проверены перед выдачей.
