import { useProfileWallets } from "../queries/useProfile";

export function useWalletsMe(tg_id: number | null) {
  return useProfileWallets(tg_id);
}
