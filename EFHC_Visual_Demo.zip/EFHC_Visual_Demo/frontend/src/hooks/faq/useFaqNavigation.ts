import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/router";
import { faqQuery } from "../../lib/faq/navigation";

type State = {
  sectionId: string | null;
  subsectionId: string | null;
  openItemId: string | null;
};

export function useFaqNavigation() {
  const router = useRouter();
  const [state, setState] = useState<State>({
    sectionId: null,
    subsectionId: null,
    openItemId: null,
  });

  useEffect(() => {
    const sectionId = typeof router.query.section === "string"
      ? router.query.section
      : null;
    const subsectionId = typeof router.query.subsection === "string"
      ? router.query.subsection
      : null;
    const openItemId = typeof router.query.item === "string"
      ? router.query.item
      : null;
    setState({ sectionId, subsectionId, openItemId });
  }, [
    router.query.item,
    router.query.section,
    router.query.subsection,
  ]);

  const pushState = (next: State) => {
    setState(next);
    void router.push(
      { pathname: "/faq", query: faqQuery({
        sectionId: next.sectionId,
        subsectionId: next.subsectionId,
        itemId: next.openItemId,
      }) },
      undefined,
      { shallow: true },
    );
  };

  return useMemo(() => ({
    ...state,
    openSection: (sectionId: string) => {
      pushState({ sectionId, subsectionId: null, openItemId: null });
    },
    openSubsection: (sectionId: string, subsectionId: string) => {
      pushState({ sectionId, subsectionId, openItemId: null });
    },
    openQuestion: (
      sectionId: string,
      subsectionId: string,
      itemId: string,
    ) => {
      pushState({
        sectionId,
        subsectionId,
        openItemId: state.openItemId === itemId ? null : itemId,
      });
    },
    goToSections: () => {
      pushState({
        sectionId: null,
        subsectionId: null,
        openItemId: null,
      });
    },
    goToSubsections: () => {
      if (!state.sectionId) return;
      pushState({
        sectionId: state.sectionId,
        subsectionId: null,
        openItemId: null,
      });
    },
  }), [state.sectionId, state.subsectionId, state.openItemId]);
}
