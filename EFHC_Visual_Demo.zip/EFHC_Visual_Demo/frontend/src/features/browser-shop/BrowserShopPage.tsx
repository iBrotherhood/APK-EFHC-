import React, { useEffect, useMemo, useState } from "react";
import { Button } from "../../components/ui/Button";
import { RouteSkeleton } from "../../components/ui/RouteSkeleton";
import {
  GameHero,
  GameNotice,
  GamePageShell,
  GameProductCard,
  GameStatusPill,
} from "../../components/ui/GameShell";
import { useT } from "../../hooks/useT";
import {
  useBrowserShopAccessKey,
  useBrowserShopBootstrap,
  useBrowserShopCatalog,
  useBrowserShopCreateIntent,
  useBrowserShopIntentStatus,
} from "../../queries/useBrowserShop";
import { normalizeTonConnectTx } from "./browserShopTonTx";
import {
  BrowserShopPreSignChecklist,
} from "./BrowserShopPreSignChecklist";
import {
  buildUsdtTransferPlanFromBrowserShopIntent,
} from "../../lib/ton/browser-shop-intent";
import {
  buildJettonTransferTonConnectTx,
  resolveSenderJettonWallet,
} from "../../lib/ton/jetton-transfer-builder";
import type {
  BrowserShopCatalogItem,
  PaymentIntentStatusResponse,
} from "../../lib/api/generated/economicUserSeams";
import {
  useWalletProvider,
  type WalletTransactionPhase,
} from "../../lib/wallet-provider";

const TOKEN_KEY = "efhc.browserShop.token.v1";
const SKU_KEY = "efhc.browserShop.sku.v1";
const METHOD_KEY = "efhc.browserShop.method.v1";

type PayMethod = "TON" | "USDT";
type PaymentUiState =
  | "idle"
  | "pending"
  | "checking"
  | "done"
  | "error";

type InitialContext = {
  token: string;
  sku: string;
  method: PayMethod;
};

function safeSessionRead(key: string): string {
  if (typeof window === "undefined") return "";
  try {
    return window.sessionStorage.getItem(key) || "";
  } catch {
    return "";
  }
}

function readInitialContext(): InitialContext {
  if (typeof window === "undefined") {
    return { token: "", sku: "", method: "TON" };
  }
  const params = new URLSearchParams(window.location.search);
  const method = params.get("method") || safeSessionRead(METHOD_KEY);
  return {
    token: params.get("token") || safeSessionRead(TOKEN_KEY),
    sku: params.get("sku") || safeSessionRead(SKU_KEY),
    method: method === "USDT" ? "USDT" : "TON",
  };
}

function rememberCheckout(
  token: string,
  sku: string,
  method: PayMethod,
) {
  if (typeof window === "undefined") return;
  try {
    if (token) window.sessionStorage.setItem(TOKEN_KEY, token);
    if (sku) window.sessionStorage.setItem(SKU_KEY, sku);
    window.sessionStorage.setItem(METHOD_KEY, method);
  } catch {
    // Browser privacy modes may deny storage.
  }
  const url = new URL(window.location.href);
  if (token) url.searchParams.set("token", token);
  if (sku) url.searchParams.set("sku", sku);
  url.searchParams.set("method", method);
  window.history.replaceState({}, "", url.toString());
}

function checkoutReturnUrl(
  rawUrl: string,
  sku: string,
  method: PayMethod,
): string {
  const url = new URL(
    rawUrl,
    typeof window === "undefined"
      ? "https://efhc.invalid"
      : window.location.href,
  );
  if (sku) url.searchParams.set("sku", sku);
  url.searchParams.set("method", method);
  return url.toString();
}

function openExternal(url: string) {
  if (typeof window === "undefined") return;
  const tg = (globalThis as any)?.Telegram?.WebApp;
  if (typeof tg?.openLink === "function") {
    tg.openLink(url);
    return;
  }
  window.open(url, "_blank", "noopener,noreferrer");
}

function normalizePrice(value?: string): string {
  return String(value || "").trim() || "—";
}

function paymentUiState(
  status: PaymentIntentStatusResponse | null,
  creating: boolean,
): PaymentUiState {
  if (creating) return "pending";
  if (!status) return "idle";
  const raw = String(status.status || "").trim().toUpperCase();
  const product = String(
    status.flow_truth?.product_state || "",
  ).trim();
  if (raw === "CONFIRMED" || product === "terminal_success") {
    return "done";
  }
  if (
    ["EXPIRED", "CANCELED", "FAILED"].includes(raw)
    || ["terminal_failed", "expired"].includes(product)
  ) {
    return "error";
  }
  return "checking";
}

function formatRemaining(expiresAt: string, nowMs: number): string {
  const expiryMs = Date.parse(expiresAt);
  if (!Number.isFinite(expiryMs)) return "—";
  const seconds = Math.max(0, Math.ceil((expiryMs - nowMs) / 1000));
  const minutes = Math.floor(seconds / 60);
  return `${minutes}:${String(seconds % 60).padStart(2, "0")}`;
}

export default function BrowserShopPage() {
  const t = useT();
  const visualProof = (
    process.env.NEXT_PUBLIC_EFHC_OBSERVABILITY_VISUAL_PROOF
    === "1"
  );
  const {
    address: walletAddress,
    connect: connectWallet,
    sendTransaction,
    isUserRejected,
  } = useWalletProvider();
  const [initial, setInitial] = useState<InitialContext>({
    token: "",
    sku: "",
    method: "TON",
  });
  const [token, setToken] = useState("");
  const [selectedSku, setSelectedSku] = useState("");
  const [selectedMethods, setSelectedMethods] = useState<
    Record<string, PayMethod>
  >({});
  const [activeIntentId, setActiveIntentId] = useState<number | null>(
    null,
  );
  const [createdExpiresAt, setCreatedExpiresAt] = useState("");
  const [localError, setLocalError] = useState("");
  const [walletTxPhase, setWalletTxPhase] = useState<
    WalletTransactionPhase
  >("idle");
  const [nowMs, setNowMs] = useState(Date.now());

  const bootstrapQ = useBrowserShopBootstrap(token);
  const catalogQ = useBrowserShopCatalog();
  const accessKey = useBrowserShopAccessKey();
  const createIntent = useBrowserShopCreateIntent(token);
  const statusQ = useBrowserShopIntentStatus(token, activeIntentId);

  useEffect(() => {
    const restored = readInitialContext();
    setInitial(restored);
    setToken(restored.token);
    setSelectedSku(restored.sku);
    if (restored.sku) {
      setSelectedMethods({ [restored.sku]: restored.method });
    }
  }, []);

  const proofBootstrap = visualProof ? {
    mode: "handoff_bound" as const,
    tg_linked: true,
    tg_id: 1568,
    wallet_linked: true,
    active_wallet_address: "EQ_VISUAL_PROOF",
    wallets: [],
    wallet_sync_required: false,
    bot_open_url: null,
    telegram_sync_url: null,
    wallet_sync_url: null,
    storefront_mode: "browser_shop_mvp" as const,
    access_mode: "telegram_handoff" as const,
    future_game_entry_enabled: false,
    available_modules: ["catalog", "checkout"],
    flow_truth: null,
    active_payment: null,
    intent_history: [],
  } : null;
  const bootstrap = proofBootstrap || bootstrapQ.data || null;
  const flowTruth = bootstrap?.flow_truth || null;
  const readinessState = String(
    flowTruth?.readiness_state || "",
  );
  const walletSyncRequired =
    readinessState === "wallet_sync_required"
    || Boolean(bootstrap?.wallet_sync_required);
  const resumeIntent =
    flowTruth?.next_step === "resume_intent";
  const actionDenied = Boolean(flowTruth?.action_denied);
  const canonicalCenter =
    flowTruth?.canonical_center || "web_profile";
  const proofCatalog: BrowserShopCatalogItem[] = visualProof
    ? [{
        sku: "EFHC-VISUAL-100",
        title: "100 EFHCm",
        description: t("portal.browser_shop.presign_ready"),
        item_type: "efhc_main",
        ton_enabled: true,
        usdt_enabled: true,
        methods: {
          TON: { price: "10.00" },
          USDT: { price: "25.00" },
        },
      }]
    : [];
  const publicCatalog = useMemo(
    () => (proofCatalog.length ? proofCatalog : catalogQ.data || [])
      .filter((item) => item.ton_enabled || item.usdt_enabled),
    [catalogQ.data, proofCatalog],
  );

  useEffect(() => {
    if (!bootstrap?.active_payment || activeIntentId) return;
    setActiveIntentId(bootstrap.active_payment.id);
  }, [activeIntentId, bootstrap?.active_payment]);

  useEffect(() => {
    rememberCheckout(token, selectedSku, initial.method);
  }, [initial.method, selectedSku, token]);

  const activeStatus = statusQ.data
    || bootstrap?.active_payment
    || null;
  const state = paymentUiState(activeStatus, createIntent.isPending);
  const expiresAt = activeStatus?.expires_at || createdExpiresAt;

  useEffect(() => {
    if (!expiresAt || ["done", "error"].includes(state)) return;
    const id = window.setInterval(() => setNowMs(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, [expiresAt, state]);

  useEffect(() => {
    if (state === "done") setLocalError("");
  }, [state]);

  function selectedMethod(item: BrowserShopCatalogItem): PayMethod {
    const current = selectedMethods[item.sku];
    if (current && item.methods?.[current]) return current;
    if (item.sku === initial.sku && item.methods?.[initial.method]) {
      return initial.method;
    }
    return item.methods?.TON ? "TON" : "USDT";
  }

  function chooseMethod(
    item: BrowserShopCatalogItem,
    method: PayMethod,
  ) {
    setSelectedSku(item.sku);
    setSelectedMethods((current) => ({
      ...current,
      [item.sku]: method,
    }));
    rememberCheckout(token, item.sku, method);
  }

  async function linkWebAccount() {
    setLocalError("");
    try {
      const out = await accessKey.mutateAsync();
      const method = selectedSku
        ? selectedMethods[selectedSku] || initial.method
        : initial.method;
      const url = checkoutReturnUrl(
        out.redirect_url,
        selectedSku,
        method,
      );
      window.location.assign(url);
    } catch {
      setLocalError(t("portal.browser_shop.open_from_hub_detail"));
    }
  }

  function openTelegramLink() {
    const url = bootstrap?.telegram_sync_url
      || bootstrap?.bot_open_url
      || "";
    if (!url) return;
    rememberCheckout(token, selectedSku, initial.method);
    openExternal(url);
  }

  function syncWallet() {
    const url = bootstrap?.wallet_sync_url
      || bootstrap?.telegram_sync_url
      || bootstrap?.bot_open_url
      || "";
    if (!url) return;
    rememberCheckout(token, selectedSku, initial.method);
    openExternal(url);
  }

  async function createPayment(item: BrowserShopCatalogItem) {
    const method = selectedMethod(item);
    setSelectedSku(item.sku);
    rememberCheckout(token, item.sku, method);
    setLocalError("");
    setWalletTxPhase("idle");

    if (!token) {
      setLocalError(t("portal.browser_shop.open_from_hub_detail"));
      return;
    }
    if (!bootstrap?.wallet_linked || walletSyncRequired) {
      setLocalError(t("portal.browser_shop.wallet_sync_detail"));
      return;
    }
    if (!walletAddress) {
      try {
        await connectWallet();
      } catch (caught) {
        if (isUserRejected(caught)) {
          setWalletTxPhase("rejected");
          setLocalError(t("wallet.transaction_rejected"));
          return;
        }
        setWalletTxPhase("error");
        setLocalError(t("wallet.transaction_failed"));
      }
      return;
    }

    try {
      const parsed = await createIntent.mutateAsync({
        token,
        sku: item.sku,
        quantity: 1,
        pay_method: method,
        client_nonce: globalThis.crypto?.randomUUID?.(),
      });
      setActiveIntentId(parsed.intent_id);
      setCreatedExpiresAt(parsed.expires_at);

      let tx = normalizeTonConnectTx(parsed.tonconnect_tx);
      if (method === "USDT") {
        const plan = buildUsdtTransferPlanFromBrowserShopIntent(
          parsed,
          {
            senderOwnerAddress: walletAddress,
            recipientPolicy: {
              strategy: "owner_derived_wallet",
              ownerAddress: parsed.to_wallet,
            },
          },
        );
        const endpoint = process.env.NEXT_PUBLIC_TON_RPC_ENDPOINT
          || "https://toncenter.com/api/v2/jsonRPC";
        const senderJettonWallet = await resolveSenderJettonWallet({
          endpoint,
          ownerAddress: walletAddress,
          jettonMasterAddress: plan.jettonMasterAddress,
        });
        tx = buildJettonTransferTonConnectTx(
          plan,
          senderJettonWallet,
        );
      }
      if (!tx) throw new Error("WALLET_TX_MISSING");
      setWalletTxPhase("signing");
      await sendTransaction(tx);
      setWalletTxPhase("signed");
    } catch (caught) {
      if (isUserRejected(caught)) {
        setWalletTxPhase("rejected");
        setLocalError(t("wallet.transaction_rejected"));
        return;
      }
      setWalletTxPhase("error");
      setLocalError(t("wallet.transaction_failed"));
    }
  }

  const loading = !visualProof
    && (bootstrapQ.isLoading || catalogQ.isLoading);
  const loadError = visualProof
    ? null
    : bootstrapQ.error || catalogQ.error;
  const ttl = expiresAt ? formatRemaining(expiresAt, nowMs) : "";
  const accountLinked = visualProof
    || Boolean(token && bootstrap?.tg_linked);
  const walletLinked = visualProof
    || Boolean(bootstrap?.wallet_linked && !walletSyncRequired);

  if (loading) {
    return (
      <GamePageShell
        className="efhc-browser-shop-game-page"
        data-public-surface="browser-shop"
      >
        <RouteSkeleton kind="cards" rows={3} />
      </GamePageShell>
    );
  }

  if (loadError) {
    return (
      <GamePageShell
        className="efhc-browser-shop-game-page"
        data-public-surface="browser-shop"
      >
        <GameNotice
          title={t("portal.browser_shop.open_failed_title")}
          actionLabel={t("portal.browser_shop.open_bot")}
          onAction={openTelegramLink}
        />
      </GamePageShell>
    );
  }

  return (
    <GamePageShell
      className="efhc-browser-shop-game-page efhc-browser-shop-compact"
      data-public-surface="browser-shop"
      data-browser-shop-checkout="ton-usdt"
      data-browser-shop-linking="telegram-web-return"
      data-browser-shop-polling="react-query-5000ms"
      data-browser-shop-ttl={ttl || "none"}
      data-wallet-transaction={walletTxPhase}
      data-tonconnect-transaction={walletTxPhase}
      data-browser-shop-no-bottom-menu="true"
      data-browser-shop-readiness={readinessState || "unknown"}
      data-browser-shop-resume-intent={resumeIntent ? "true" : "false"}
      data-browser-shop-canonical-center={canonicalCenter}
    >
      <GameHero
        kicker="EFHC"
        title={t("portal.browser_shop.storefront_title")}
        icon="◇"
        right={(
          <GameStatusPill
            label={t(`portal.browser_shop.payment_state_${state}`)}
            tone={state === "error" ? "error" : "ok"}
          />
        )}
      />

      <section
        className="efhc-browser-shop-account-bar"
        data-account-linked={accountLinked ? "true" : "false"}
        data-wallet-linked={walletLinked ? "true" : "false"}
      >
        <div>
          <strong>
            {accountLinked
              ? t("portal.browser_shop.linked")
              : t("portal.browser_shop.guest")}
          </strong>
          <span>
            {walletLinked
              ? t("portal.browser_shop.wallet_title")
              : t("portal.browser_shop.wallet_sync_title")}
          </span>
        </div>
        {!accountLinked ? (
          <div className="efhc-browser-shop-account-actions">
            <Button
              onClick={() => void linkWebAccount()}
              disabled={accessKey.isPending}
            >
              {t("portal.browser_shop.open_profile")}
            </Button>
            {bootstrap?.bot_open_url ? (
              <Button variant="secondary" onClick={openTelegramLink}>
                {t("portal.browser_shop.open_telegram")}
              </Button>
            ) : null}
          </div>
        ) : !walletLinked ? (
          <Button onClick={syncWallet}>
            {t("portal.browser_shop.open_sync")}
          </Button>
        ) : null}
      </section>

      {state !== "idle" ? (
        <section className="efhc-browser-shop-payment-strip">
          <div>
            <strong>
              {t(`portal.browser_shop.payment_${state}_title`)}
            </strong>
            {ttl ? (
              <span>
                {t("portal.browser_shop.expires_title")}: {ttl}
              </span>
            ) : null}
          </div>
          {activeIntentId ? (
            <Button
              variant="secondary"
              onClick={() => void statusQ.refetch()}
              disabled={statusQ.isFetching}
            >
              {t("common.refresh")}
            </Button>
          ) : null}
        </section>
      ) : null}

      {walletTxPhase === "signing" ? (
        <section
          className="efhc-tonconnect-transaction is-signing"
          role="status"
          aria-live="polite"
        >
          <span aria-hidden="true">↻</span>
          <div>
            <strong>{t("wallet.transaction_signing")}</strong>
            <p>{t("wallet.transaction_signing_detail")}</p>
          </div>
        </section>
      ) : null}

      {walletTxPhase === "rejected" ? (
        <section
          className="efhc-tonconnect-transaction is-rejected"
          role="status"
          aria-live="polite"
        >
          <span aria-hidden="true">×</span>
          <div>
            <strong>{t("wallet.transaction_rejected")}</strong>
            <p>{t("wallet.transaction_rejected_detail")}</p>
          </div>
        </section>
      ) : null}

      {localError ? (
        <GameNotice title={t("common.error")} detail={localError} />
      ) : null}

      {publicCatalog.length === 0 ? (
        <GameNotice
          title={t("portal.browser_shop.packages_unavailable_title")}
        />
      ) : (
        <section
          className={
            "efhc-game-product-grid "
            + "efhc-browser-shop-product-grid"
          }
          data-browser-shop-product-count={publicCatalog.length}
        >
          {publicCatalog.map((item) => {
            const method = selectedMethod(item);
            const disabled = createIntent.isPending
              || walletTxPhase === "signing"
              || state === "checking"
              || state === "pending"
              || !accountLinked
              || !walletLinked
              || actionDenied
              || resumeIntent;
            return (
              <article
                key={item.sku}
                className="efhc-browser-shop-payment-card"
                data-browser-shop-pay-method={method}
                data-checkout-sku={item.sku}
              >
                <div
                  className="efhc-browser-shop-methods"
                  role="group"
                  aria-label={t(
                    "portal.browser_shop.payment_method_title",
                  )}
                >
                  {item.methods?.TON ? (
                    <Button
                      variant={
                        method === "TON" ? "primary" : "secondary"
                      }
                      onClick={() => chooseMethod(item, "TON")}
                    >
                      {t("portal.browser_shop.pay_ton_gram")}
                    </Button>
                  ) : null}
                  {item.methods?.USDT ? (
                    <Button
                      variant={
                        method === "USDT" ? "primary" : "secondary"
                      }
                      onClick={() => chooseMethod(item, "USDT")}
                    >
                      {t("portal.browser_shop.pay_usdt_ton_gram")}
                    </Button>
                  ) : null}
                </div>
                <BrowserShopPreSignChecklist
                  asset={method}
                  amount={`${method} ${normalizePrice(
                    item.methods?.[method]?.price,
                  )}`}
                  ready={!disabled}
                />
                <GameProductCard
                  title={item.title}
                  detail={
                    item.description
                    && item.description.trim() !== item.title.trim()
                      ? item.description
                      : undefined
                  }
                  price={`${method} ${normalizePrice(
                    item.methods?.[method]?.price,
                  )}`}
                  badge="EFHCm"
                  imageUrl={null}
                  onPrimary={() => void createPayment(item)}
                  primaryLabel={t("portal.browser_shop.pay_button")}
                  disabled={disabled}
                />
              </article>
            );
          })}
        </section>
      )}
    </GamePageShell>
  );
}
