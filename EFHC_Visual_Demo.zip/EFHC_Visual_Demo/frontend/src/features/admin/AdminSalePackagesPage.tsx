import React, { useEffect, useMemo, useState } from "react";

import {
  AdminActionGrid,
} from "../../components/admin/AdminActionGrid";
import {
  AdminDetailShell,
} from "../../components/admin/AdminDetailShell";
import { AdminListShell } from "../../components/admin/AdminListShell";
import { AdminPage } from "../../components/admin/AdminPage";
import {
  AdminPromptModal,
} from "../../components/admin/AdminPromptModal";
import {
  AdminRouteHealthStrip,
} from "../../components/admin/AdminRouteHealthStrip";
import { AdminStatCard } from "../../components/admin/AdminStatCard";
import {
  TelegramInfoBlock,
} from "../../components/ui/telegram/TelegramInfoBlock";
import {
  TelegramSectionRow,
} from "../../components/ui/telegram/TelegramSectionRow";
import {
  TelegramStatusBadge,
} from "../../components/ui/telegram/TelegramStatusBadge";
import { Button } from "../../components/ui/Button";
import {
  adminPath,
  ADMIN_SALE_PACKAGES_PACKAGE_ID_PATH,
  ADMIN_SALE_PACKAGES_PACKAGE_ID_TOGGLE_PATH,
  ADMIN_SALE_PACKAGES_PATH,
} from "../../lib/api/generated/adminSeams";
import { newIdempotencyKey } from "../../lib/idempotency";
import {
  adminSafeLoadError,
  adminUiErrorMessage,
} from "../../lib/adminError";
import {
  useAdminLinkedTransport,
} from "../../queries/useAdminLinkedTransport";

type SalePackage = {
  id: number;
  title: string;
  asset: string;
  price_asset_d8: string;
  efhc_amount_d8: string;
  is_active: boolean;
};

type SalePackagesOut = { items: SalePackage[] };

type PackageFilter = "all" | "active" | "inactive";
type PackageMutationMode = "create" | "edit" | null;
type PackageConfirmAction = {
  kind: "toggle";
  item: SalePackage;
} | null;
type SalePackageForm = {
  title: string;
  asset: string;
  price_asset_d8: string;
  efhc_amount_d8: string;
};

const emptyPackageForm: SalePackageForm = {
  title: "",
  asset: "TON",
  price_asset_d8: "",
  efhc_amount_d8: "",
};

function formFromPackage(item: SalePackage | null): SalePackageForm {
  if (!item) return emptyPackageForm;
  return {
    title: item.title,
    asset: item.asset,
    price_asset_d8: item.price_asset_d8,
    efhc_amount_d8: item.efhc_amount_d8,
  };
}

function hasRequiredFormValues(form: SalePackageForm): boolean {
  return Boolean(
    form.title.trim() &&
      form.asset.trim() &&
      form.price_asset_d8.trim() &&
      form.efhc_amount_d8.trim(),
  );
}

export default function AdminSalePackagesPage() {
  const adminApiRequest = useAdminLinkedTransport();
  const [items, setItems] = useState<SalePackage[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<PackageFilter>("all");
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [mutationMode, setMutationMode] =
    useState<PackageMutationMode>(null);
  const [mutationForm, setMutationForm] =
    useState<SalePackageForm>(emptyPackageForm);
  const [confirmAction, setConfirmAction] =
    useState<PackageConfirmAction>(null);
  const [mutationBusy, setMutationBusy] = useState(false);
  const [confirmPhrase, setConfirmPhrase] = useState("");

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const out = await adminApiRequest<SalePackagesOut>(
        ADMIN_SALE_PACKAGES_PATH,
        "GET",
      );
      const nextItems = Array.isArray(out?.items) ? out.items : [];
      setItems(nextItems);
      setSelectedId((prev) => prev ?? nextItems[0]?.id ?? null);
    } catch (e: any) {
      setError(adminSafeLoadError(e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  const activeCount = useMemo(
    () => items.filter((item) => item.is_active).length,
    [items],
  );

  const filteredItems = useMemo(() => {
    if (filter === "active") {
      return items.filter((item) => item.is_active);
    }
    if (filter === "inactive") {
      return items.filter((item) => !item.is_active);
    }
    return items;
  }, [filter, items]);

  const selectedItem = useMemo(() => {
    return (
      filteredItems.find((item) => item.id === selectedId) ||
      items.find((item) => item.id === selectedId) ||
      filteredItems[0] ||
      items[0] ||
      null
    );
  }, [filteredItems, items, selectedId]);

  function openCreateModal() {
    setMutationForm(emptyPackageForm);
    setMutationMode("create");
  }

  function openEditModal(item: SalePackage | null) {
    if (!item) return;
    setSelectedId(item.id);
    setMutationForm(formFromPackage(item));
    setMutationMode("edit");
  }

  async function submitPackageMutation() {
    if (!hasRequiredFormValues(mutationForm)) return;
    setMutationBusy(true);
    setError(null);
    try {
      if (mutationMode === "create") {
        const created = await adminApiRequest<SalePackage>(
          ADMIN_SALE_PACKAGES_PATH,
          "POST",
          {
            body: {
              title: mutationForm.title.trim(),
              asset: mutationForm.asset.trim(),
              price_asset_d8: mutationForm.price_asset_d8.trim(),
              efhc_amount_d8: mutationForm.efhc_amount_d8.trim(),
              is_active: false,
            },
            idempotencyKey: newIdempotencyKey(),
          },
        );
        if (created?.id) setSelectedId(created.id);
      }
      if (mutationMode === "edit" && selectedItem) {
        await adminApiRequest<SalePackage>(
          adminPath(ADMIN_SALE_PACKAGES_PACKAGE_ID_PATH, {
            package_id: selectedItem.id,
          }),
          "PUT",
          {
            body: {
              title: mutationForm.title.trim(),
              asset: mutationForm.asset.trim(),
              price_asset_d8: mutationForm.price_asset_d8.trim(),
              efhc_amount_d8: mutationForm.efhc_amount_d8.trim(),
            },
            idempotencyKey: newIdempotencyKey(),
          },
        );
      }
      setMutationMode(null);
      await load();
    } catch (e: any) {
      setError(adminSafeLoadError(e));
    } finally {
      setMutationBusy(false);
    }
  }

  async function togglePackage(item: SalePackage) {
    setMutationBusy(true);
    setError(null);
    try {
      await adminApiRequest<SalePackage>(
        adminPath(ADMIN_SALE_PACKAGES_PACKAGE_ID_TOGGLE_PATH, {
          package_id: item.id,
        }),
        "POST",
        { idempotencyKey: newIdempotencyKey() },
      );
      setConfirmAction(null);
      setConfirmPhrase("");
      await load();
    } catch (e: any) {
      setError(adminSafeLoadError(e));
    } finally {
      setMutationBusy(false);
    }
  }

  return (
    <AdminPage
      title="Sale packages"
      subtitle={
        "Операторская панель legacy sale-packages " +
        "с create/edit/toggle " +
        "mutation wiring and SSOT boundary notes."
      }
      backHref="/admin"
      surfaceBadges={[
        { label: "deferred", tone: "warning" },
        { label: "beta", tone: "warning" },
        { label: "mutation-wired", tone: "connected" },
        { label: "не release contour", tone: "warning" },
      ]}
      infoBlock={{
        title: "Классификация release-truth",
        description:
          "Sale packages теперь имеет operator " +
          "create/edit/toggle wiring. " +
          "Boundary remains outside release-core " +
          "evidence until promoted. " +
          "Truth для live-контура остаётся в " +
          "Shop и efhc_core.shop_items.",
      }}
    >
      <AdminRouteHealthStrip
        title="Диагностика маршрута"
        subtitle={
          "Отложенный sale-packages snapshot остаётся видимым " +
          "for internal operator review only."
        }
        items={[
          {
            label: "list",
            path: "/admin/sale-packages/",
            tone: "neutral",
          },
        ]}
      />

      <TelegramInfoBlock
        title="Статус модуля"
        description={
          "Этот экран не является live SSOT для packages. " +
          "Truth остаётся в efhc_core.shop_items / Shop."
        }
      >
        <div className="mt-3 flex flex-wrap gap-2">
          <TelegramStatusBadge label="deferred" tone="warning" />
          <TelegramStatusBadge label="beta" tone="warning" />
          <TelegramStatusBadge
            label="не release contour"
            tone="warning"
          />
          <TelegramStatusBadge
            label="mutation-wired"
            tone="connected"
          />
        </div>
      </TelegramInfoBlock>

      <AdminActionGrid
        title="Действия оператора"
        subtitle={
          "Паттерн из песочницы адаптирован как " +
          "ясный action/filter слой."
        }
        items={[
          {
            label: "Создать пакет",
            note: "Открыть форму создания draft sale-package.",
            onClick: () => openCreateModal(),
            disabled: mutationBusy || loading,
          },
          {
            label: "Обновить snapshot",
            note: "Перезагрузить sale-packages snapshot.",
            onClick: () => {
              void load();
            },
            disabled: mutationBusy || loading,
            variant: "secondary",
          },
          {
            label: "Показать активные",
            note: "Фильтровать только активные отложенные строки.",
            onClick: () => setFilter("active"),
          },
          {
            label: "Показать неактивные",
            note: "Оставить только неактивные snapshot-строки.",
            onClick: () => setFilter("inactive"),
            variant: "ghost",
          },
          {
            label: "Показать всё",
            note: "Вернуть полный отложенный snapshot.",
            onClick: () => setFilter("all"),
            variant: "secondary",
          },
        ]}
      />

      {error ? (
        <TelegramInfoBlock title="Статус раздела">
          {error || null}
        </TelegramInfoBlock>
      ) : null}

      <div className="grid gap-3 md:grid-cols-3">
        <AdminStatCard
          label="Всего пакетов"
          value={items.length}
          hint={
            "Строки, видимые в отложенном " +
            "efhc_sale_packages snapshot."
          }
        />
        <AdminStatCard
          label="Активных"
          value={activeCount}
          hint="Сколько отложенных строк ещё имеют is_active=true."
          tone={activeCount > 0 ? "success" : "neutral"}
        />
        <AdminStatCard
          label="Текущий фильтр"
          value={filter}
          hint="Фильтр списка слева без изменения backend-контракта."
          tone="neutral"
        />
      </div>

      <div className="grid gap-4 xl:grid-cols-[0.95fr_1.05fr]">
        <AdminListShell
          title="Legacy snapshot list"
          subtitle={
            "Левая колонка показывает читаемый список " +
            "пакетов вместо плоской card-ленты."
          }
        >
          {loading ? (
            <TelegramSectionRow
              title="Загрузка"
              subtitle="Загрузка отложенного snapshot..."
              rightSlot={
                <TelegramStatusBadge label="loading" tone="neutral" />
              }
            />
          ) : null}
          {!loading && filteredItems.length === 0 ? (
            <TelegramSectionRow
              title="Нет строк"
              subtitle="Фильтр не оставил отложенных строк."
              rightSlot={
                <TelegramStatusBadge label="empty" tone="neutral" />
              }
            />
          ) : null}
          {filteredItems.map((item) => (
            <TelegramSectionRow
              key={item.id}
              title={item.title}
              subtitle={
                `ID ${item.id} • ${item.asset} • ` +
                `${item.price_asset_d8}`
              }
              rightSlot={
                <TelegramStatusBadge
                  label={item.is_active ? "active" : "inactive"}
                  tone={item.is_active ? "connected" : "warning"}
                />
              }
              onClick={() => setSelectedId(item.id)}
              className={
                selectedItem?.id === item.id
                  ? "border-[color:var(--tg-link-color)]/40"
                  : undefined
              }
            />
          ))}
        </AdminListShell>

        <AdminDetailShell
          title="Детали пакета"
          subtitle={
            "Правая колонка показывает фокусную " +
            "detail-панель выбранной draft-записи."
          }
          actions={
            selectedItem ? (
              <div className="flex flex-wrap gap-2">
                <Button
                  variant="secondary"
                  disabled={mutationBusy || loading}
                  onClick={() => openEditModal(selectedItem)}
                >
                  Редактировать
                </Button>
                <Button
                  variant={
                    selectedItem.is_active ? "ghost" : "secondary"
                  }
                  disabled={mutationBusy || loading}
                  onClick={() => {
                    setConfirmPhrase("");
                    setConfirmAction({
                      kind: "toggle",
                      item: selectedItem,
                    });
                  }}
                >
                  {selectedItem.is_active
                    ? "Деактивировать"
                    : "Активировать"}
                </Button>
              </div>
            ) : null
          }
        >
          {!selectedItem ? (
            <TelegramInfoBlock title="Детали пакета">
              Выберите пакет слева, чтобы увидеть его детали.
            </TelegramInfoBlock>
          ) : (
            <>
              <TelegramSectionRow
                title="Название"
                subtitle={selectedItem.title}
                rightSlot={
                  <TelegramStatusBadge
                    label="selected"
                    tone="primary"
                  />
                }
              />
              <TelegramSectionRow
                title="Актив"
                subtitle={selectedItem.asset}
                rightSlot={
                  <TelegramStatusBadge label="legacy" tone="neutral" />
                }
              />
              <TelegramSectionRow
                title="Цена"
                subtitle={selectedItem.price_asset_d8}
                rightSlot={
                  <TelegramStatusBadge
                    label="snapshot"
                    tone="neutral"
                  />
                }
              />
              <TelegramSectionRow
                title="EFHC"
                subtitle={selectedItem.efhc_amount_d8}
                rightSlot={
                  <TelegramStatusBadge label="draft" tone="warning" />
                }
              />
              <TelegramSectionRow
                title="Состояние"
                subtitle={
                  selectedItem.is_active
                    ? "Эта draft-запись помечена активной."
                    : "Эта draft-запись выключена."
                }
                rightSlot={
                  <TelegramStatusBadge
                    label={
                      selectedItem.is_active ? "active" : "inactive"
                    }
                    tone={
                      selectedItem.is_active ? "connected" : "warning"
                    }
                  />
                }
              />
              <TelegramInfoBlock title="Операторские мутации">
                Create, edit and toggle now call the backend routes with
                Idempotency-Key and reload the list after every
                successful mutation. Deactivation/activation requires
                explicit modal confirmation before the POST toggle call.
              </TelegramInfoBlock>
              <TelegramInfoBlock title="SSOT-заметка">
                Этот экран служит для internal operator review and
                controlled sale-package maintenance. Боевой контур
                пакетов живёт в shop/admin shell and must not replace
                core shop truth without a future SSOT promotion.
              </TelegramInfoBlock>
            </>
          )}
        </AdminDetailShell>
      </div>

      <AdminPromptModal
        open={mutationMode !== null}
        title={
          mutationMode === "create"
            ? "Создать sale-package"
            : "Редактировать sale-package"
        }
        submitLabel={
          mutationMode === "create" ? "Создать" : "Сохранить"
        }
        busy={mutationBusy}
        submitDisabled={!hasRequiredFormValues(mutationForm)}
        values={mutationForm}
        fields={[
          { key: "title", label: "Название" },
          { key: "asset", label: "Актив" },
          { key: "price_asset_d8", label: "Цена asset d8" },
          { key: "efhc_amount_d8", label: "EFHC amount d8" },
        ]}
        onChange={(key, value) => {
          setMutationForm((prev) => ({ ...prev, [key]: value }));
        }}
        onClose={() => setMutationMode(null)}
        onSubmit={() => void submitPackageMutation()}
      />

      <AdminPromptModal
        open={Boolean(confirmAction)}
        title={
          confirmAction?.item.is_active
            ? "Подтвердить деактивацию пакета"
            : "Подтвердить активацию пакета"
        }
        submitLabel={
          confirmAction?.item.is_active
            ? "Деактивировать"
            : "Активировать"
        }
        busy={mutationBusy}
        values={{
          phrase: confirmPhrase,
          package: confirmAction
            ? `${confirmAction.item.id}: ${confirmAction.item.title}`
            : "",
        }}
        fields={[
          { key: "package", label: "Пакет" },
          {
            key: "phrase",
            label: "Фраза подтверждения",
            placeholder: "toggle",
          },
        ]}
        submitDisabled={confirmPhrase.trim().toLowerCase() !== "toggle"}
        onChange={(key, value) => {
          if (key === "phrase") setConfirmPhrase(value);
        }}
        onClose={() => setConfirmAction(null)}
        onSubmit={() => {
          if (confirmAction) void togglePackage(confirmAction.item);
        }}
      />
    </AdminPage>
  );
}
