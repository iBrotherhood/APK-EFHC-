import React, {
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { useRouter } from "next/router";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import {
  GameNotice,
  GameSection,
  GameStat,
  GameStatsGrid,
} from "../../components/ui/GameShell";
import { LayoutContext } from "../../components/Layout";
import { ProfileModal } from "../../components/ProfileModal";
import { SUPPORTED_LANGS, type Lang } from "../../lib/i18n";
import { getUserLevel } from "../../lib/skins";
import { formatD8ToHuman } from "../../lib/format";
import { publicApiErrorMessage } from "../../lib/publicError";
import type {
  BalanceHistoryItem,
  WithdrawHistoryItem,
} from "../../services/profile.service";
import type { UserSettings } from "../../lib/settings";
import type { PanelsSummary } from "../../types/panels";
import { useWalletsMe } from "../../hooks/useWalletsMe";
import {
  useProfileBalanceHistory,
  useProfileWalletActions,
  useProfileWithdrawHistory,
} from "../../queries/useProfile";
import { ProfileWalletSection } from
  "../../components/profile/ProfileWalletSection";
import { ProfileHistorySection } from
  "../../components/profile/ProfileHistorySection";
import {
  balanceHistoryReasonLabel,
} from "../../lib/humanLabels";
import { LegalPolicyView } from
  "../../components/profile/LegalPolicyView";
import type { LegalPolicyKind } from
  "../../data/legalPolicies";

const SETTINGS_GEAR_INNER_PATH =
  "M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Z";

const SETTINGS_GEAR_OUTER_PATH = [
  "M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06",
  "a2 2 0 1 1-2.83 2.83l-.06-.06A1.65 1.65 0 0 0 15 19.4",
  "a1.65 1.65 0 0 0-1 .6V20a2 2 0 1 1-4 0v-.09",
  "a1.65 1.65 0 0 0-1-.6 1.65 1.65 0 0 0-1.82.33",
  "l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.6 15",
  "a1.65 1.65 0 0 0-.6-1H4a2 2 0 1 1 0-4h.09",
  "a1.65 1.65 0 0 0 .6-1 1.65 1.65 0 0 0-.33-1.82",
  "l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6",
  "h.01a1.65 1.65 0 0 0 1-.6V4a2 2 0 1 1 4 0v.09",
  "a1.65 1.65 0 0 0 1 .6 1.65 1.65 0 0 0 1.82-.33",
  "l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9",
  "v.01a1.65 1.65 0 0 0 .6 1H20a2 2 0 1 1 0 4h-.09",
  "a1.65 1.65 0 0 0-.51 1Z",
].join("");

type ProfileSnap = {
  active_payment?: {
    flow_truth?: {
      product_state?: string | null;
      canonical_center?: string | null;
    } | null;
  } | null;
  latest_withdraw_status?: string | null;
  latest_withdraw_outcome?: {
    outcome_kind?: string | null;
  } | null;
  profile?: {
    username?: string | null;
    is_vip?: boolean;
    has_activ?: boolean;
    main_balance?: string;
    bonus_balance?: string;
    total_generated_kwh?: string;
    available_kwh?: string;
    exchanged_kwh_total?: string;
  };
  panels?: PanelsSummary | null;
};



type Props = {
  tg_id: number | null;
  snap: ProfileSnap | null;
  settings: UserSettings;
  setSettings: (settings: UserSettings) => void;
};

type Tab = "profile" | "wallet" | "history" | "faq";

function readAmount(value: string | undefined): string {
  return formatD8ToHuman(value || "0");
}



function addD8ToHuman(
  a: string | undefined,
  b: string | undefined,
): string {
  try {
    const sum = BigInt(a || "0") + BigInt(b || "0");
    return formatD8ToHuman(sum.toString());
  } catch {
    return "0";
  }
}


// History reason i18n compatibility anchors:
// history.reason.exchange_kwh
// history.reason.panel_purchase
// history.reason.admin_credit
// history.reason.admin_debit
// history.reason.withdraw
// history.reason.shop_purchase
// history.reason.unknown
function reasonLabel(
  reason: string,
  t: (key: string) => string,
): string {
  return balanceHistoryReasonLabel(reason, t);
}

function goHome(router: ReturnType<typeof useRouter>) {
  void router.push("/");
}

function goBack(router: ReturnType<typeof useRouter>) {
  if (typeof window !== "undefined" && window.history.length > 1) {
    router.back();
    return;
  }
  goHome(router);
}




function TabButton(props: {
  active: boolean;
  label: string;
  trustSurface: Tab;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      className={
        "efhc-profile-tab " +
        (props.active ? "efhc-profile-tab--active" : "")
      }
      data-profile-trust-tab={props.trustSurface}
      onClick={props.onClick}
    >
      {props.label}
    </button>
  );
}

export default function WebProfilePage(props: Props) {
  const router = useRouter();
  const ctx = useContext(LayoutContext);
  const t = ctx.t;
  const walletsQ = useWalletsMe(props.tg_id);
  const walletActions = useProfileWalletActions(props.tg_id);
  const [historyFilter, setHistoryFilter] = useState("all");
  const [settingsOpen, setSettingsOpen] = useState(false);
  const section = String(router.query.section || "profile");
  const activeTab: Tab =
    section === "wallet" ||
    section === "history" ||
    section === "faq"
      ? section
      : "profile";
  const legalParam = String(router.query.legal || "");
  const routedLegalKind: LegalPolicyKind | null =
    legalParam === "terms" || legalParam === "privacy"
      ? legalParam
      : null;
  const [proofLegalKind, setProofLegalKind] =
    useState<LegalPolicyKind | null>(null);

  useEffect(() => {
    if (process.env.NEXT_PUBLIC_EFHC_E2E_LEGAL_PROOF !== "1") {
      return;
    }
    const proofWindow = window as Window & {
      __EFHC_LEGAL_PROOF_KIND__?: string;
    };
    const value = proofWindow.__EFHC_LEGAL_PROOF_KIND__;
    if (value === "terms" || value === "privacy") {
      setProofLegalKind(value);
    }
  }, []);

  const legalKind = routedLegalKind || proofLegalKind;

  const historyQ = useProfileBalanceHistory(
    props.tg_id,
    activeTab === "history",
  );
  const withdrawHistoryQ = useProfileWithdrawHistory(
    props.tg_id,
    activeTab === "history",
  );

  const profile = props.snap?.profile || {};
  const username = profile.username || t("profile.guest_user");
  const level = useMemo(
    () => getUserLevel(profile.total_generated_kwh || "0"),
    [profile.total_generated_kwh],
  );
  const total = readAmount(profile.total_generated_kwh);
  const main = readAmount(profile.main_balance);
  const bonus = readAmount(profile.bonus_balance);
  const totalBalance = addD8ToHuman(
    profile.main_balance,
    profile.bonus_balance,
  );
  const isVip = Boolean(ctx.isVip || profile.is_vip);
  const isActive = Boolean(profile.has_activ);
  const wallets = walletsQ.data?.wallets || [];
  const historyItems = useMemo<BalanceHistoryItem[]>(
    () => historyQ.data?.pages.flatMap((page) => page.items) || [],
    [historyQ.data],
  );
  const withdrawItems = useMemo<WithdrawHistoryItem[]>(
    () => (
      withdrawHistoryQ.data?.pages.flatMap(
        (page) => page.items,
      ) || []
    ),
    [withdrawHistoryQ.data],
  );
  const walletsError = walletsQ.error
    ? publicApiErrorMessage(walletsQ.error, t, "profile.error_wallet")
    : null;
  const setTab = (tab: Tab) => {
    const query = tab === "profile" ? undefined : { section: tab };
    void router.replace(
      { pathname: "/web-profile", query },
      undefined,
      { shallow: true },
    );
  };

  const updateTheme = (mode: UserSettings["theme_mode"]) => {
    props.setSettings({ ...props.settings, theme_mode: mode });
  };

  const updateLang = (lang: Lang) => {
    props.setSettings({ ...props.settings, lang });
  };

  const historyLoading = historyQ.isLoading || historyQ.isFetching;
  const withdrawLoading =
    withdrawHistoryQ.isLoading || withdrawHistoryQ.isFetching;
  const historyCursor = historyQ.hasNextPage
    ? historyQ.data?.pages.at(-1)?.next_cursor || null
    : null;
  const withdrawCursor = withdrawHistoryQ.hasNextPage
    ? withdrawHistoryQ.data?.pages.at(-1)?.next_cursor || null
    : null;
  const historyError = historyQ.error
    ? publicApiErrorMessage(
      historyQ.error,
      t,
      "profile.error_history",
    )
    : null;
  const withdrawError = withdrawHistoryQ.error
    ? publicApiErrorMessage(
      withdrawHistoryQ.error,
      t,
      "profile.error_withdraw_history",
    )
    : null;

  const refreshHistory = () => {
    void Promise.all([
      historyQ.refetch(),
      withdrawHistoryQ.refetch(),
    ]);
  };

  const loadMoreHistory = () => {
    if (historyQ.hasNextPage && !historyQ.isFetchingNextPage) {
      void historyQ.fetchNextPage();
    }
  };

  const loadMoreWithdraws = () => {
    if (
      withdrawHistoryQ.hasNextPage
      && !withdrawHistoryQ.isFetchingNextPage
    ) {
      void withdrawHistoryQ.fetchNextPage();
    }
  };

  if (legalKind) {
    return (
      <LegalPolicyView
        kind={legalKind}
        lang={props.settings.lang}
      />
    );
  }

  return (
    <div
      className="efhc-profile-page"
      data-public-visual-trust="profile-wallet-history-faq"
      data-public-surface="web-profile"
      data-public-no-admin-diagnostics="true"
      data-public-no-raw-payload="true"
    >
      <div className="efhc-profile-topbar">
        <button type="button" onClick={() => goBack(router)}>
          ← {t("profile.back")}
        </button>
        <strong>{t("profile.page_title")}</strong>
        <div className="efhc-profile-topbar_actions">
          {ctx.isAdmin ? (
            <button
              type="button"
              onClick={() => void router.push("/admin")}
            >
              {t("nav.admin")}
            </button>
          ) : null}
          <button type="button" onClick={() => goHome(router)}>
            {t("profile.exit")}
          </button>
        </div>
      </div>

      <section className="efhc-profile-hero">
        <div className="efhc-profile-avatar" aria-hidden="true">
          ⚡
        </div>
        <div className="min-w-0 text-center">
          <div className="truncate text-2xl font-extrabold">
            {username}
          </div>
          <div
            className="mt-1 text-sm font-bold text-[var(--tg-button)]"
          >
            LVL {level}
          </div>
        </div>
        <div
          className="efhc-profile-badges"
          data-profile-status-model="always-visible-1303"
        >
          {ctx.isAdmin ? (
            <span
              className={
                "efhc-profile-status efhc-profile-status--on"
              }
            >
              {t("profile.admin_badge")}
            </span>
          ) : null}
          <span
            className={
              "efhc-profile-status " +
              (isVip
                ? "efhc-profile-status--on"
                : "efhc-profile-status--off")
            }
            data-profile-vip-status={isVip ? "active" : "inactive"}
          >
            {t("profile.vip_badge")}
          </span>
          <span
            className={
              "efhc-profile-status " +
              (isActive
                ? "efhc-profile-status--on"
                : "efhc-profile-status--off")
            }
            data-profile-active-status={
              isActive ? "active" : "inactive"
            }
          >
            {t("profile.active_badge")}
          </span>
        </div>
      </section>

      <div
        className="efhc-profile-tabs"
        data-profile-primary-navigation="profile-wallet-history-faq"
      >
        <TabButton
          active={activeTab === "profile"}
          label={t("profile.section_profile_tab")}
          trustSurface="profile"
          onClick={() => setTab("profile")}
        />
        <TabButton
          active={activeTab === "wallet"}
          label={t("profile.section_wallet_tab")}
          trustSurface="wallet"
          onClick={() => setTab("wallet")}
        />
        <TabButton
          active={activeTab === "history"}
          label={t("profile.section_history_tab")}
          trustSurface="history"
          onClick={() => setTab("history")}
        />
        <TabButton
          active={activeTab === "faq"}
          label={t("faq.title")}
          trustSurface="faq"
          onClick={() => setTab("faq")}
        />
      </div>

      {activeTab === "wallet" ? (
        <section
          className="grid gap-3"
          data-wallet-list-boundary="wallet-list-only-1305"
          data-wallet-error-microcopy="safe-1306"
        >
          <Card className="efhc-profile-action-card p-4">
            <ProfileWalletSection
              wallets={wallets}
              walletsLoading={walletsQ.isLoading}
              walletsError={walletsError}
              walletHint={ctx.walletHint}
              sessionConnected={ctx.walletSessionConnected}
              sessionRestoring={ctx.walletSessionRestoring}
              tonProofAccepted={ctx.walletProofAccepted}
              connectionPhase={ctx.walletConnectionPhase}
              availableWallets={ctx.availableWallets}
              onConnect={ctx.openWalletConnect}
              onDisconnectSession={ctx.disconnectWalletSession}
              onMakePrimary={(id) => {
                void walletActions.mutateAsync({
                  kind: "make-primary",
                  walletId: id,
                }).catch(() => undefined);
              }}
              onRemove={(id) => {
                void walletActions.mutateAsync({
                  kind: "remove",
                  walletId: id,
                }).catch(() => undefined);
              }}
              hapticsEnabled={props.settings.haptics_enabled}
            />
          </Card>
        </section>
      ) : null}

      {activeTab === "history" ? (
        <section className="grid gap-3">
          <GameNotice
            title={t("profile.history_clean_title")}
            detail={t("profile.history_clean_note")}
          />
          <Card className="efhc-profile-action-card p-4">
            <ProfileHistorySection
              totalBalance={totalBalance}
              mainBalance={main}
              bonusBalance={bonus}
              historyItems={historyItems}
              historyLoading={historyLoading}
              historyError={historyError}
              historyCursor={historyCursor}
              withdrawItems={withdrawItems}
              withdrawLoading={withdrawLoading}
              withdrawError={withdrawError}
              withdrawCursor={withdrawCursor}
              activeFilter={historyFilter}
              onFilterChange={setHistoryFilter}
              onRefresh={refreshHistory}
              onLoadMore={loadMoreHistory}
              onLoadMoreWithdraw={loadMoreWithdraws}
              reasonLabel={(reason) => reasonLabel(reason, t)}
            />
          </Card>
        </section>
      ) : null}

      {activeTab === "faq" ? (
        <section
          className="grid gap-3"
          data-profile-faq-button-only="1304"
        >
          <Card className="efhc-profile-action-card p-4">
            <div className="text-lg font-extrabold">
              {t("faq.title")}
            </div>
            <p className="mt-1 text-sm efhc-text-muted2">
              {t("profile.faq_button_note")}
            </p>
            <div className="mt-4">
              <Button href="/faq" aria-label={t("faq.open_full")}>
                {t("faq.open_full")}
              </Button>
            </div>
          </Card>
        </section>
      ) : null}

      {activeTab === "profile" ? (
        <section className="grid gap-3">
          <GameSection data-profile-main-data="1303">
            <GameStatsGrid>
              <GameStat
                label={t("profile.telegram_ready")}
                value={username}
              />
              <GameStat
                label={t("energy.title")}
                value={total}
                note="kWh"
              />
            </GameStatsGrid>
          </GameSection>
          <Card className="efhc-profile-action-card p-4">
            <div className="efhc-profile-card-heading">
              <div className="min-w-0">
                <div className="text-lg font-extrabold">
                  {t("profile.interface_title")}
                </div>
                <p className="mt-1 text-sm efhc-text-muted2">
                  {t("profile.interface_note")}
                </p>
              </div>
              <button
                type="button"
                className="efhc-profile-settings-button"
                aria-label={t("profile.settings_title")}
                title={t("profile.settings_title")}
                onClick={() => setSettingsOpen(true)}
                data-profile-settings-entry="profile-modal"
              >
                <svg
                  aria-hidden="true"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d={SETTINGS_GEAR_INNER_PATH} />
                  <path d={SETTINGS_GEAR_OUTER_PATH} />
                </svg>
              </button>
            </div>
            <div className="mt-4 grid gap-3">
              <label className="efhc-profile-field">
                <span>{t("profile.language")}</span>
                <select
                  value={props.settings.lang}
                  onChange={(event) => {
                    updateLang(event.currentTarget.value as Lang);
                  }}
                >
                  {SUPPORTED_LANGS.map((lang) => (
                    <option key={lang} value={lang}>
                      {t(`profile.lang.${lang}`)}
                    </option>
                  ))}
                </select>
              </label>
              <div className="efhc-profile-mode-grid">
                <Button
                  variant={
                    props.settings.theme_mode === "dark"
                      ? "primary"
                      : "secondary"
                  }
                  onClick={() => updateTheme("dark")}
                >
                  {t("profile.theme_dark")}
                </Button>
                <Button
                  variant={
                    props.settings.theme_mode === "light"
                      ? "primary"
                      : "secondary"
                  }
                  onClick={() => updateTheme("light")}
                >
                  {t("profile.theme_light")}
                </Button>
              </div>
              <Button
                href="/faq"
                variant="secondary"
                aria-label={t("faq.open_full")}
                data-profile-faq-entry="button-1304"
              >
                {t("faq.open_full")}
              </Button>
            </div>
          </Card>
          <Card
            className="efhc-profile-action-card p-4"
            data-profile-trust-legal-group="true"
          >
            <div className="text-lg font-extrabold">
              {t("profile.trust_legal_title")}
            </div>
            <p className="mt-1 text-sm efhc-text-muted2">
              {t("profile.trust_legal_note")}
            </p>
            <div className="efhc-profile-trust-grid">
              <Button
                variant="secondary"
                onClick={() => void router.push({
                  pathname: "/web-profile",
                  query: { legal: "privacy" },
                })}
              >
                {t("profile.trust_privacy")}
              </Button>
              <Button
                variant="secondary"
                onClick={() => void router.push({
                  pathname: "/web-profile",
                  query: { legal: "terms" },
                })}
              >
                {t("profile.trust_terms")}
              </Button>
              <Button
                href="/faq?section=5&subsection=5.1"
                variant="secondary"
              >
                {t("profile.trust_security")}
              </Button>
              <Button href="/faq" variant="secondary">
                {t("profile.trust_support")}
              </Button>
            </div>
          </Card>
        </section>
      ) : null}

      <ProfileModal
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        settings={props.settings}
        setSettings={props.setSettings}
        telegramName={username}
        telegramAvatarUrl={null}
        isVip={isVip}
        hasActiv={isActive}
        isAdmin={ctx.isAdmin}
        onOpenAdmin={() => void router.push("/admin")}
        initialSection={null}
        walletHint={ctx.walletHint}
        onOpenWalletConnect={ctx.openWalletConnect}
        onOpenDepositLauncher={ctx.openDeposit}
        onDisconnectWalletSession={ctx.disconnectWalletSession}
        tonSessionConnected={ctx.walletSessionConnected}
        tonSessionRestoring={ctx.walletSessionRestoring}
        tonProofAccepted={ctx.walletProofAccepted}
        availableWallets={ctx.availableWallets}
        mainBalance={main}
        bonusBalance={bonus}
        tg_id={props.tg_id}
      />
    </div>
  );
}
