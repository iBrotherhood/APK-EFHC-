export function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}

// UI invariant: show 8 decimals everywhere, DOWN, without scientific.
export function format8(v: string | number | null | undefined): string {
  return formatFixedDown(v, 8);
}

function normalizeDecimalStr(
  v: string | number | null | undefined,
): string {
  if (v === null || v === undefined) return "0";
  const s = typeof v === "number" ? String(v) : String(v);
  // Avoid scientific notation.
  if (s.includes("e") || s.includes("E")) {
    throw new Error("Scientific notation forbidden");
  }
  return s.trim();
}

export function formatFixedDown(
  v: string | number | null | undefined,
  decimals: number,
): string {
  const s = normalizeDecimalStr(v);
  const neg = s.startsWith("-");
  const raw = neg ? s.slice(1) : s;
  const parts = raw.split(".");
  const intPart = parts[0].replace(/\D/g, "") || "0";
  const frac = (parts[1] || "").replace(/\D/g, "");
  const cut = frac.padEnd(decimals, "0").slice(0, decimals);
  const res = `${intPart}.${cut}`;
  return neg ? `-${res}` : res;
}

export function toScaledBigintDown(
  v: string | number | null | undefined,
  scale: number,
): bigint {
  const s = formatFixedDown(v, scale);
  const neg = s.startsWith("-");
  const raw = neg ? s.slice(1) : s;
  const parts = raw.split(".");
  const intPart = parts[0] || "0";
  const frac = (parts[1] || "").padEnd(scale, "0");
  const digits = `${intPart}${frac}`.replace(/^0+(?=\d)/, "");
  const bi = BigInt(digits || "0");
  return neg ? -bi : bi;
}

export function fromScaledBigint(
  v: bigint,
  scale: number,
): string {
  const neg = v < 0n;
  const raw = (neg ? -v : v).toString();
  const padded = raw.padStart(scale + 1, "0");
  const intPart = padded.slice(0, -scale);
  const frac = padded.slice(-scale);
  const out = `${intPart}.${frac}`;
  return neg ? `-${out}` : out;
}

export function sumScaledDown(
  a: string,
  b: string,
  scale: number,
): string {
  const sa = toScaledBigintDown(a, scale);
  const sb = toScaledBigintDown(b, scale);
  const sum = sa + sb;
  return fromScaledBigint(sum, scale);
}

export function cmpFixedDown(
  a: string | number | null | undefined,
  b: string | number | null | undefined,
  decimals: number,
): number {
  const sa = toScaledBigintDown(a, decimals);
  const sb = toScaledBigintDown(b, decimals);
  if (sa === sb) return 0;
  return sa > sb ? 1 : -1;
}

// UI invariant: 8-decimal compare, DOWN, without scientific.
export function cmp8(
  a: string | number | null | undefined,
  b: string | number | null | undefined,
): number {
  return cmpFixedDown(a, b, 8);
}


// UI invariant for human-facing money/cards: show 2 decimals, DOWN.
export function formatD8ToHuman(
  v: string | number | null | undefined,
  decimals = 2,
): string {
  return formatFixedDown(v, decimals);
}
