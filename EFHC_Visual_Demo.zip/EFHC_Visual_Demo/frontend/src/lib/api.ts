import { isSimulatorRuntime } from "../demo/runtime";
import {
  clearAuthSession,
  getAuthAuthorizationHeader,
} from "./auth-session";

export type HttpMethod = "GET" | "POST" | "PUT" | "PATCH" | "DELETE";

export function getApiBase(): string {
  return "";
}

function normalizeApiPath(path: string): string {
  const p = String(path || "");
  if (!p.startsWith("/")) return `/api/${p}`;
  if (
    p.startsWith("/api/") ||
    p === "/health" ||
    p === "/openapi.json" ||
    p === "/redoc" ||
    p.startsWith("/docs") ||
    p.startsWith("/meta/")
  ) {
    return p;
  }
  return `/api${p}`;
}

export type ApiRequestOptions = {
  body?: unknown;
  idempotencyKey?: string;
  headers?: Record<string, string>;
  // Prefer request tracing for incident debugging.
  requestId?: string;
  signal?: AbortSignal;
};

export class ApiError extends Error {
  status: number;
  code?: string;
  requestId?: string;
  payload?: unknown;
  retryable: boolean;

  constructor(args: {
    status: number;
    code?: string;
    requestId?: string;
    payload?: unknown;
    retryable?: boolean;
  }) {
    super("EFHC_API_REQUEST_FAILED");
    this.name = "ApiError";
    this.status = args.status;
    this.code = args.code;
    this.requestId = args.requestId;
    this.payload = args.payload;
    this.retryable =
      args.retryable ??
      (
        args.status === 408 ||
        args.status === 409 ||
        args.status === 425 ||
        args.status === 429 ||
        args.status >= 500
      );
  }
}

function readPayloadCode(payload: unknown): string | undefined {
  if (!payload || typeof payload !== "object") return undefined;
  const record = payload as Record<string, unknown>;
  const code = record.code || record.error_code || record.type;
  if (typeof code !== "string") return undefined;
  const trimmed = code.trim();
  return trimmed ? trimmed : undefined;
}

function readPayloadRequestId(
  payload: unknown,
  headers: Headers,
): string | undefined {
  const fromHeader =
    headers.get("x-request-id") || headers.get("x-correlation-id");
  if (fromHeader && fromHeader.trim()) return fromHeader.trim();
  if (!payload || typeof payload !== "object") return undefined;
  const record = payload as Record<string, unknown>;
  const requestId = record.request_id || record.requestId;
  return typeof requestId === "string" && requestId.trim()
    ? requestId.trim()
    : undefined;
}

async function readErrorPayload(
  res: Response,
  isJson: boolean,
): Promise<unknown> {
  if (isJson) {
    return await res.json().catch(() => null);
  }
  const text = await res.text().catch(() => "");
  return text ? { body: text } : null;
}

export async function apiRequest<T>(
  path: string,
  method: HttpMethod,
  opts: ApiRequestOptions = {},
): Promise<T> {
  if (isSimulatorRuntime()) {
    const { demoApiRequest } = await import("../demo/api");
    return demoApiRequest<T>(path, method, opts);
  }

  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...(opts.headers || {}),
  };

  // Все business API используют только server-side Bearer session.
  // Telegram initData передаётся исключительно login endpoint явно.
  const sessionAuthorization = getAuthAuthorizationHeader();
  if (sessionAuthorization && !headers.Authorization) {
    headers.Authorization = sessionAuthorization;
  }

  if (opts.requestId) headers["X-Request-ID"] = String(opts.requestId);
  if (opts.idempotencyKey) {
    headers["Idempotency-Key"] = String(opts.idempotencyKey);
  }

  const res = await fetch(getApiBase() + normalizeApiPath(path), {
    method,
    headers,
    body:
      opts.body !== undefined
        ? JSON.stringify(opts.body)
        : undefined,
    credentials: "include",
    signal: opts.signal,
  });

  const contentType = res.headers.get("content-type") || "";
  const isJson = contentType.includes("application/json");

  if (!res.ok) {
    if (res.status === 401 && sessionAuthorization) {
      clearAuthSession();
    }
    const payload = await readErrorPayload(res, isJson);
    throw new ApiError({
      status: res.status,
      code: readPayloadCode(payload),
      requestId: readPayloadRequestId(payload, res.headers),
      payload,
    });
  }

  if (isJson) return (await res.json()) as T;
  return undefined as T;
}
