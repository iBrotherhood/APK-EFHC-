export type TranslationFn = (key: string) => string;

function norm(value: string | null | undefined): string {
  return String(value || "").trim().toLowerCase();
}

export function taskStatusLabel(
  status: string | null | undefined,
  t: TranslationFn,
): string {
  const value = norm(status);
  if (!value) return t("tasks.status_ready");
  if (value === "available") return t("tasks.status_available");
  if (value === "completed") return t("tasks.status_completed");
  if (value === "cooldown") return t("tasks.status_cooldown");
  if (value === "claimed") return t("tasks.status_claimed");
  if (value === "not_started") return t("tasks.status_not_started");
  if (value === "pending_check") return t("tasks.status_pending_check");
  if (value === "approved") return t("tasks.status_approved");
  if (value === "auto_paid") return t("tasks.status_auto_paid");
  if (value === "rejected") return t("tasks.status_rejected");
  return t("tasks.status_unknown");
}

export function taskStatusVisualState(
  status: string | null | undefined,
): "done" | "wait" | "ready" {
  const value = norm(status);
  const doneStates = [
    "claimed",
    "completed",
    "approved",
    "auto_paid",
  ];
  if (doneStates.includes(value)) return "done";
  if (["cooldown", "pending_check"].includes(value)) return "wait";
  return "ready";
}

export function balanceHistoryReasonLabel(
  reason: string | null | undefined,
  t: TranslationFn,
): string {
  const value = norm(reason);
  if (!value) return t("history.reason.unknown");
  if (value.startsWith("task_bonus")) {
    return t("history.reason.task_bonus");
  }
  if (value.startsWith("ad_bonus")) return t("history.reason.ad_bonus");
  if (value.includes("exchange")) {
    return t("history.reason.exchange_kwh");
  }
  if (value.includes("panel")) {
    return t("history.reason.panel_purchase");
  }
  if (value.includes("referral")) {
    return t("history.reason.referral_bonus");
  }
  if (value.includes("withdraw")) return t("history.reason.withdraw");
  if (value.includes("deposit")) return t("history.reason.deposit");
  if (value.includes("payment")) return t("history.reason.payment");
  if (value.includes("order") || value.includes("shop")) {
    return t("history.reason.shop_purchase");
  }
  if (value === "admin_credit") return t("history.reason.admin_credit");
  if (value === "admin_debit") return t("history.reason.admin_debit");
  return t("history.reason.unknown");
}

export function withdrawStatusLabel(
  status: string | null | undefined,
  t: TranslationFn,
): string {
  const value = norm(status);
  if (value === "pending") return t("withdraw.status_pending");
  if (value === "paid") return t("withdraw.status_paid");
  if (value === "canceled" || value === "cancelled") {
    return t("withdraw.status_canceled");
  }
  if (value === "rejected") return t("withdraw.status_rejected");
  if (value === "approved") return t("withdraw.status_approved");
  if (value === "failed" || value === "error") {
    return t("withdraw.status_failed");
  }
  return t("withdraw.status_unknown");
}

export function withdrawOutcomeKindLabel(
  kind: string | null | undefined,
  t: TranslationFn,
): string {
  const value = norm(kind);
  if (value === "success") return t("withdraw.outcome_success");
  if (value === "reject" || value === "rejected") {
    return t("withdraw.outcome_rejected");
  }
  if (value === "failed" || value === "error") {
    return t("withdraw.outcome_failed");
  }
  if (value === "pending" || value === "manual_review") {
    return t("withdraw.outcome_pending");
  }
  if (value === "canceled" || value === "cancelled") {
    return t("withdraw.outcome_canceled");
  }
  return t("withdraw.outcome_unknown");
}

export function balanceTypeLabel(
  balanceType: string | null | undefined,
  t: TranslationFn,
): string {
  const value = norm(balanceType);
  if (value === "main") return t("withdraw.balance_main");
  if (value === "bonus") return t("withdraw.balance_bonus");
  return t("withdraw.balance_unknown");
}

export function adminWithdrawStatusLabel(
  status: string | null | undefined,
): string {
  const value = norm(status);
  const labels: Record<string, string> = {
    pending: "Ожидает обработки",
    approved: "Одобрено",
    rejected: "Отклонено",
    canceled: "Отменено",
    cancelled: "Отменено",
    paid: "Выплачено",
    failed: "Ошибка выплаты",
    error: "Ошибка выплаты",
  };
  return labels[value] || "Статус не определён";
}

export function adminWithdrawOutcomeLabel(
  outcome: string | null | undefined,
): string {
  const value = norm(outcome);
  const labels: Record<string, string> = {
    success: "Успешный результат",
    reject: "Отклонение",
    rejected: "Отклонение",
    failed: "Ошибка результата",
    error: "Ошибка результата",
    pending: "Ожидает обработки",
  };
  return labels[value] || "Результат не определён";
}

export function adminShopStatusLabel(
  status: string | null | undefined,
): string {
  const value = norm(status);
  const labels: Record<string, string> = {
    live: "Опубликовано",
    hidden: "Скрыто",
    draft: "Архив",
    active: "Активна",
    inactive: "Неактивна",
  };
  return labels[value] || "Статус не определён";
}
