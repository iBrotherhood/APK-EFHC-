import type {
  HubShopTruthResponse,
} from "../api/generated/economicUserSeams";

export function openShopExternal(url: string) {
  if (typeof window === "undefined") return;
  window.open(url, "_blank", "noopener,noreferrer");
}

export type ShopLauncherResult =
  | "wallet_sync_required"
  | "telegram_handoff_required"
  | "external_flow_unavailable"
  | "browser_shop_opened";

export function getShopLauncherResult(
  truth: HubShopTruthResponse,
): ShopLauncherResult {
  const flow = truth.flow_truth;
  const primaryCta = String(flow?.primary_cta || "").trim();
  if (primaryCta === "sync_wallet") {
    return "wallet_sync_required";
  }
  if (primaryCta === "open_telegram_handoff") {
    return "telegram_handoff_required";
  }
  if (flow?.action_denied || primaryCta === "unavailable") {
    return "external_flow_unavailable";
  }
  return "browser_shop_opened";
}
