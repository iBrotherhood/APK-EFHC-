import { apiRequest } from "./api";
import {
  type AuthSessionContext,
  type AuthSessionCredential,
} from "./auth-session";
import {
  acceptIssuedAuthSession,
  fetchAuthSessionContext,
  revokeAuthSession,
} from "./auth-session-client";

export type TonProofLoginResponse = {
  verified: true;
  challenge_id: string;
  provider: "ton_wallet";
  provider_subject: string;
  network: "mainnet" | "testnet";
  verified_at: string;
  global_id: string;
  account_outcome:
    | "existing_identity"
    | "existing_binding"
    | "registered";
  session: AuthSessionCredential;
};

export async function completeTonProofLogin(
  proofRequest: unknown,
): Promise<TonProofLoginResponse> {
  const result = await apiRequest<TonProofLoginResponse>(
    "/auth/ton/proof",
    "POST",
    {
      body: proofRequest,
    },
  );
  acceptIssuedAuthSession(result);
  return result;
}

export async function loadAuthSessionContext():
  Promise<AuthSessionContext> {
  return await fetchAuthSessionContext();
}

export async function logoutAuthSession(): Promise<void> {
  await revokeAuthSession();
}
