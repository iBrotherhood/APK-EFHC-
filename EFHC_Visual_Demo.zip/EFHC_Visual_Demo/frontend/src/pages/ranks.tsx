import React, { useMemo, useRef } from "react";

import { Badge } from "../components/ui/Badge";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { EmptyState } from "../components/ui/EmptyState";
import {
  GameHero,
  GamePageShell,
  GameStat,
  GameStatsGrid,
} from "../components/ui/GameShell";
import { Skeleton } from "../components/ui/Skeleton";
import { useT } from "../hooks/useT";
import type { SyncSnapshot } from "../hooks/useSnapshot";
import { formatD8ToHuman } from "../lib/format";
import { publicApiErrorMessage } from "../lib/publicError";
import { hapticSelection, hapticSoft } from "../lib/telegram";
import {
  useMyRankWithTop,
  useRankTopPages,
  useRefreshRanks,
} from "../queries/useRanks";
import type { RankItem } from "../services/ranks.service";

function medalForRank(pos: number): string {
  if (pos === 1) return "1";
  if (pos === 2) return "2";
  if (pos === 3) return "3";
  return String(pos);
}

function displayName(item: RankItem, hiddenLabel: string): string {
  return item.username ? `@${item.username}` : hiddenLabel;
}

function RankRow(props: {
  item: RankItem;
  hiddenLabel: string;
  mine: boolean;
  mineLabel: string;
}) {
  return (
    <article
      className={
        `efhc-rank-card ${props.mine ? "efhc-rank-card--mine" : ""}`
      }
      data-ranks-card="vertical-1299"
      data-ranks-username-only="true"
      data-ranks-me={props.mine ? "true" : "false"}
    >
      <div
        className="efhc-rank-medal"
        aria-label={`#${props.item.rank_pos}`}
      >
        {medalForRank(props.item.rank_pos)}
      </div>
      <div className="min-w-0 flex-1">
        <div className="truncate text-sm font-semibold">
          {displayName(props.item, props.hiddenLabel)}
        </div>
        <div className="text-xs efhc-text-muted2">
          {formatD8ToHuman(props.item.total_generated_kwh)} kWh
        </div>
      </div>
      <div className="flex shrink-0 items-center gap-2">
        {props.mine ? <Badge>{props.mineLabel}</Badge> : null}
        {props.item.is_vip ? <Badge variant="vip">VIP</Badge> : null}
      </div>
    </article>
  );
}

export default function RanksPage(props: {
  tg_id: number | null;
  snap: SyncSnapshot | null;
}) {
  const t = useT();
  const myCardRef = useRef<HTMLDivElement | null>(null);
  const rankQ = useMyRankWithTop(props.tg_id);
  const moreQ = useRankTopPages(
    props.tg_id,
    rankQ.data?.next_cursor,
  );
  const refreshRanks = useRefreshRanks(props.tg_id);

  const fallbackMe: RankItem = {
    tg_id: props.tg_id ?? 0,
    username: null,
    total_generated_kwh:
      props.snap?.profile?.total_generated_kwh || "0.00000000",
    rank_pos: 0,
    is_vip: Boolean(props.snap?.profile?.is_vip),
    active_referrals: 0,
  };
  const me = rankQ.data?.me ?? fallbackMe;
  const hiddenLabel = props.tg_id
    ? t("ranks.user_hidden_fallback")
    : t("ranks.browser_user_fallback");

  const leaderboard = useMemo(() => {
    const initial = rankQ.data?.top ?? [];
    const additional = (moreQ.data?.pages ?? []).flatMap(
      (page) => page.items,
    );
    return [...initial, ...additional]
      .filter((item) => item.tg_id !== me.tg_id)
      .filter(
        (item, index, rows) =>
          rows.findIndex((row) => row.tg_id === item.tg_id) === index,
      )
      .sort((a, b) => a.rank_pos - b.rank_pos)
      .slice(0, 100);
  }, [me.tg_id, moreQ.data?.pages, rankQ.data?.top]);

  const refresh = async () => {
    hapticSelection(true);
    await refreshRanks();
    hapticSoft(true);
  };

  const findMe = () => {
    hapticSelection(true);
    myCardRef.current?.scrollIntoView({
      behavior: "smooth",
      block: "center",
    });
  };

  return (
    <GamePageShell
      className="efhc-ranks-shell"
      data-public-visual-beauty="tasks-referrals-ranks"
      data-public-surface="ranks"
      data-ranks-proof-pass="1558"
      data-ranks-runtime="react-query-kwh-1558"
    >
      <GameHero
        kicker={t("ranks.game_kicker")}
        title={t("ranks.title")}
        detail={`${t("ranks.snapshot_at")}: ${rankQ.data?.snapshot_at ?? "—"}`}
        icon="★"
        right={
          <Button
            aria-label={t("common.refresh")}
            variant="secondary"
            disabled={rankQ.isFetching}
            onClick={() => void refresh()}
          >
            {t("common.refresh")}
          </Button>
        }
      >
        <GameStatsGrid>
          <GameStat
            label={t("ranks.me")}
            value={me.rank_pos > 0 ? `#${me.rank_pos}` : "—"}
          />
          <GameStat
            label={t("ranks.my_energy")}
            value={`${formatD8ToHuman(me.total_generated_kwh)} kWh`}
          />
        </GameStatsGrid>
      </GameHero>

      <div ref={myCardRef}>
        <Card
          title={t("ranks.me")}
          className="efhc-ranks-me-card"
          data-ranks-my-card="true"
          data-ranks-show-me-boundary="1558"
        >
          {rankQ.isLoading ? (
            <Skeleton className="h-16" />
          ) : (
            <RankRow
              item={me}
              hiddenLabel={hiddenLabel}
              mine
              mineLabel={t("ranks.me_badge")}
            />
          )}
        </Card>
      </div>

      {rankQ.isError ? (
        <EmptyState
          title={t("common.error")}
          detail={publicApiErrorMessage(rankQ.error, t)}
          actionLabel={t("common.refresh")}
          onAction={() => void refresh()}
        />
      ) : null}

      <Card
        title={t("ranks.top")}
        className="grid gap-3"
        data-ranks-leaderboard="top-100"
      >
        <div className="flex items-center justify-between gap-3">
          <div className="text-sm efhc-text-muted2">
            {t("ranks.top_hint")}
          </div>
          <Button
            aria-label={t("ranks.find_me")}
            variant="secondary"
            data-ranks-show-me-action="scroll-to-my-card"
            onClick={findMe}
          >
            {t("ranks.find_me")}
          </Button>
        </div>

        {rankQ.isLoading ? (
          <div className="grid gap-2">
            <Skeleton className="h-16" />
            <Skeleton className="h-16" />
            <Skeleton className="h-16" />
          </div>
        ) : null}

        <div className="grid gap-2" data-ranks-card-layout="vertical-1299">
          {leaderboard.map((item) => (
            <RankRow
              key={`${item.tg_id}-${item.rank_pos}`}
              item={item}
              hiddenLabel={hiddenLabel}
              mine={false}
              mineLabel={t("ranks.me_badge")}
            />
          ))}
        </div>

        {!rankQ.isLoading && !rankQ.isError && leaderboard.length === 0 ? (
          <EmptyState
            title={t("ranks.leaderboard_empty")}
            detail={t("ranks.empty_detail")}
            actionLabel={t("common.refresh")}
            onAction={() => void refresh()}
          />
        ) : null}

        {moreQ.hasNextPage && leaderboard.length < 100 ? (
          <Button
            disabled={moreQ.isFetchingNextPage}
            onClick={() => {
              hapticSelection(true);
              void moreQ.fetchNextPage();
            }}
          >
            {moreQ.isFetchingNextPage
              ? t("common.loading")
              : t("common.load_more")}
          </Button>
        ) : null}
      </Card>
    </GamePageShell>
  );
}
