// /app is a Telegram deep-link alias for the public Energy screen.
// The global application shell lives in pages/_app.tsx.
// Do not duplicate the custom Next App component here: Next treats this
// file as a normal route and prerendering would pass no Component prop.
export { default } from "./index";
