import { useEffect, useMemo } from "react";
import { useRouter } from "next/router";

import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { useT } from "../hooks/useT";

// Canon: Ads is not a standalone player page.
// Keep this route only as a compatibility alias to /tasks.
export default function AdsRedirect() {
  const r = useRouter();
  const t = useT();

  const targetHref = useMemo(() => {
    const q = r.asPath.split("?")[1];
    return q ? `/tasks?${q}` : "/tasks";
  }, [r.asPath]);

  useEffect(() => {
    if (targetHref === "/tasks") {
      void r.replace("/tasks");
      return;
    }
    void r.replace(targetHref);
  }, [r, targetHref]);

  return (
    <div
      className="grid gap-4 efhc-ads-trust-shell"
      data-public-visual-trust="hub-browser-shop-withdraw-ads"
      data-public-surface="ads"
    >
      <section
        className="efhc-ads-trust-rail"
        aria-label="Ads compatibility flow"
      >
        <span className="is-active">{t("tasks.no_separate_ads_page")}</span>
        <span>{t("tasks.title")}</span>
        <span>{t("tasks.next")}</span>
      </section>
      <Card title={t("tasks.no_separate_ads_page")}>
        <div className="space-y-3 text-sm">
          <div>
            {t("tasks.no_separate_ads_page")}
          </div>
          <Button href={targetHref}>{t("tasks.title")}</Button>
        </div>
      </Card>
    </div>
  );
}
