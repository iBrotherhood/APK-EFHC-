export { default } from "../features/profile/WebProfilePage";
