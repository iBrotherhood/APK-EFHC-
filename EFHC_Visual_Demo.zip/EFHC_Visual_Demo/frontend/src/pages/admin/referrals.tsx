import React, { useEffect, useMemo, useState } from "react";
import { AdminPage } from "../../components/admin/AdminPage";
import { AdminRouteHealthStrip } from "../../components/admin/AdminRouteHealthStrip";
import { AdminReferralsDashboardRuntime } from "../../components/admin/AdminTasksReferralsDashboardRuntime";
import { AdminActionGrid } from "../../components/admin/AdminActionGrid";
import { AdminDetailShell } from "../../components/admin/AdminDetailShell";
import { AdminListShell } from "../../components/admin/AdminListShell";
import { Button } from "../../components/ui/Button";
import {
  ADMIN_REFERRAL_SUMMARY_PATH,
  type AdminReferralSummaryItem,
  type AdminReferralSummaryResponse,
} from "../../lib/api/generated/adminSeams";
import { parseAdminReferralSummaryResponse } from "../../lib/api/generated/adminSeamValidators";
import { useT } from "../../hooks/useT";
import { TelegramEmptyState } from "../../components/ui/telegram/TelegramEmptyState";
import { TelegramInfoBlock } from "../../components/ui/telegram/TelegramInfoBlock";
import { TelegramSectionRow } from "../../components/ui/telegram/TelegramSectionRow";
import { TelegramStatusBadge } from "../../components/ui/telegram/TelegramStatusBadge";
import { adminSafeLoadError } from "../../lib/adminError";
import { useAdminLinkedTransport } from "../../queries/useAdminLinkedTransport";

type SummaryItem = AdminReferralSummaryItem;
type SummaryResponse = AdminReferralSummaryResponse;


export default function AdminReferralsPage() {
  const adminApiRequest = useAdminLinkedTransport();
  const t = useT();
  const [summary, setSummary] = useState<SummaryResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedInviter, setSelectedInviter] = useState<number | null>(null);


  async function load() {
    setLoading(true);
    setError(null);
    try {
      const res = await adminApiRequest<unknown>(
        `${ADMIN_REFERRAL_SUMMARY_PATH}?limit=100`,
        "GET",
      );
      setSummary(parseAdminReferralSummaryResponse(res));
    } catch (e: any) {
      setError(adminSafeLoadError(e, t));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
  }, []);

  const items = summary?.items || [];
  useEffect(() => {
    if (!items.length) {
      setSelectedInviter(null);
      return;
    }
    if (!items.some((item) => item.inviter_tg_id === selectedInviter)) {
      setSelectedInviter(items[0].inviter_tg_id);
    }
  }, [items, selectedInviter]);


  const totalInviters = items.length;
  const totalActive = useMemo(
    () => items.reduce((sum, item) => sum + Number(item.active_count || 0), 0),
    [items],
  );
  const totalInactive = useMemo(
    () =>
      items.reduce((sum, item) => sum + Number(item.inactive_count || 0), 0),
    [items],
  );
  const selected = useMemo(
    () => items.find((item) => item.inviter_tg_id === selectedInviter) || null,
    [items, selectedInviter],
  );


  return (
    <AdminPage
      title={t("admin.referrals")}
      subtitle={t("admin.referrals_note")}
      backHref="/admin"
      actions={
        <Button onClick={() => void load()} disabled={loading}>
          {loading ? t("common.loading") : t("common.refresh")}
        </Button>
      }
    >
      {error ? (
        <TelegramEmptyState title="Referral-контур обновляется" detail={error || undefined} />
      ) : null}

      <AdminRouteHealthStrip
        title="Диагностика маршрута"
        subtitle="Админские referral-связи, сверенные с backend schemas."
        items={[
          {
            label: "summary",
            path: ADMIN_REFERRAL_SUMMARY_PATH,
            tone: "connected",
          },
        ]}
      />

      <AdminReferralsDashboardRuntime
        items={items}
        selectedInviter={selectedInviter}
        loading={loading}
        error={error}
        updatedAt={new Date().toISOString()}
        hasNextPage={Boolean(summary?.next_cursor)}
        onRefresh={() => void load()}
      />

      <TelegramInfoBlock
        title={t("admin.referrals_summary")}
        description="Тяжёлый referral operator contour переведён в единый list/detail shell."
      />

      <AdminActionGrid
        title="Действия оператора"
        subtitle="Основные операторские действия вынесены в единый action grid."
        items={[
          {
            label: selected
              ? `inviter ${selected.inviter_tg_id}`
              : "Нет пригласителя",
            note: selected
              ? "Текущий выбранный inviter в detail shell."
              : "Нет выбранной записи.",
            variant: "ghost",
            disabled: !selected,
          },
        ]}
      />

      {summary ? (
        <div className="space-y-4">
          <div className="grid gap-4 xl:grid-cols-[0.95fr_1.05fr]">
            <AdminListShell
              title={t("admin.referrals_summary")}
              subtitle="Левая колонка показывает summary list пригласителя."
            >
              <TelegramSectionRow
                compact
                title="Инвайтеров в сводке"
                subtitle={String(totalInviters)}
                rightSlot={
                  <TelegramStatusBadge label="summary" tone="primary" />
                }
              />
              <TelegramSectionRow
                compact
                title="Активных приглашённых"
                subtitle={String(totalActive)}
              />
              <TelegramSectionRow
                compact
                title="Неактивных приглашённых"
                subtitle={String(totalInactive)}
              />
              {items.length ? (
                items
                  .slice(0, 12)
                  .map((item) => (
                    <TelegramSectionRow
                      key={item.inviter_tg_id}
                      compact
                      title={`inviter ${item.inviter_tg_id}`}
                      subtitle={[
                        `Активные: ${item.active_count}`,
                        `Неактивные: ${item.inactive_count}`,
                        `Бонус: ${item.total_bonus_efhc}`,
                      ].join(" • ")}
                      className={
                        selectedInviter === item.inviter_tg_id
                          ? "ring-1 ring-[color:var(--tg-link)]"
                          : ""
                      }
                      onClick={() => setSelectedInviter(item.inviter_tg_id)}
                      rightSlot={
                        item.last_invited_at ? (
                          <TelegramStatusBadge label="Недавно" tone="neutral" />
                        ) : null
                      }
                    />
                  ))
              ) : (
                <TelegramEmptyState title="Сводка пока пустая" />
              )}
            </AdminListShell>

            <AdminDetailShell
              title={
                selected
                  ? `inviter ${selected.inviter_tg_id}`
                  : "Детали реферала"
              }
              subtitle="Правая колонка показывает detail split по выбранному пригласителю."
            >
              {selected ? (
                <>
                  <TelegramSectionRow
                    compact
                    title="Активные рефералы"
                    subtitle={String(selected.active_count)}
                    rightSlot={
                      <TelegramStatusBadge label="Активно" tone="connected" />
                    }
                  />
                  <TelegramSectionRow
                    compact
                    title="Неактивные рефералы"
                    subtitle={String(selected.inactive_count)}
                    rightSlot={
                      <TelegramStatusBadge label="Неактивно" tone="neutral" />
                    }
                  />
                  <TelegramSectionRow
                    compact
                    title="Всего бонусов EFHC"
                    subtitle={selected.total_bonus_efhc}
                    rightSlot={
                      <TelegramStatusBadge label="Бонус банка" tone="primary" />
                    }
                  />
                  <TelegramSectionRow
                    compact
                    title="Последнее приглашение"
                    subtitle={selected.last_invited_at || "—"}
                  />
                  <TelegramInfoBlock title="Безопасность оператора">
                    <div className="mt-3 flex flex-wrap gap-2">
                      <TelegramStatusBadge
                        label={
                          summary.next_cursor
                            ? "Есть следующая страница"
                            : "Одна страница"
                        }
                        tone="neutral"
                      />
                    </div>
                  </TelegramInfoBlock>
                </>
              ) : (
                <TelegramEmptyState title="Выберите пригласителя" />
              )}
            </AdminDetailShell>
          </div>
        </div>
      ) : !loading ? (
        <TelegramEmptyState
          title="Сводка пока недоступна"
          actionLabel={t("common.refresh")}
          onAction={() => void load()}
        />
      ) : null}

    </AdminPage>
  );
}
