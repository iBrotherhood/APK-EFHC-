import React, { useEffect, useMemo, useState } from "react";

import { AdminActionGrid } from "../../components/admin/AdminActionGrid";
import { AdminDepositsDashboardRuntime } from "../../components/admin/AdminDepositsDashboardRuntime";
import type {
  AdminDepositsRuntimeSummary,
} from "../../components/admin/AdminDepositsDashboardRuntime";
import { AdminDetailShell } from "../../components/admin/AdminDetailShell";
import { AdminListShell } from "../../components/admin/AdminListShell";
import { AdminPage } from "../../components/admin/AdminPage";
import { AdminPromptModal } from "../../components/admin/AdminPromptModal";
import { AdminRouteHealthStrip } from "../../components/admin/AdminRouteHealthStrip";
import { AdminStatCard } from "../../components/admin/AdminStatCard";
import { Button } from "../../components/ui/Button";
import { TelegramInfoBlock } from "../../components/ui/telegram/TelegramInfoBlock";
import { TelegramSectionRow } from "../../components/ui/telegram/TelegramSectionRow";
import { TelegramStatusBadge } from "../../components/ui/telegram/TelegramStatusBadge";
import { newIdempotencyKey } from "../../lib/idempotency";
import {
  adminPath,
  ADMIN_EFHC_DEPOSITS_RUNTIME_SUMMARY_PATH,
  ADMIN_EFHC_DEPOSITS_REPROCESS_TX_HASH_PATH,
  ADMIN_EFHC_DEPOSITS_PROCESS_PATH,
  ADMIN_SHOP_ORDERS_ORDER_ID_FORCE_FULFILL_PATH,
} from "../../lib/api/generated/adminSeams";
import { adminSafeLoadError, adminUiErrorMessage } from "../../lib/adminError";
import { useAdminLinkedTransport } from "../../queries/useAdminLinkedTransport";

type ProcessResult = Record<string, unknown>;
type FocusMode = "input" | "result";

export default function AdminEfhcDepositsPage() {
  const adminApiRequest = useAdminLinkedTransport();
  const [form, setForm] = useState<Record<string, string>>({
    tx_hash: "",
    amount: "",
    memo: "",
    from_address: "",
    to_address: "",
    raw_tx: "",
    note: "",
  });
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [fulfillModalOpen, setFulfillModalOpen] = useState(false);
  const [fulfillForm, setFulfillForm] = useState<Record<string, string>>({
    order_id: "",
    reason: "manual force fulfill",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<ProcessResult | null>(null);
  const [runtimeSummary, setRuntimeSummary] = useState<
    AdminDepositsRuntimeSummary | null
  >(null);
  const [focusMode, setFocusMode] = useState<FocusMode>("input");


  async function loadRuntimeSummary() {
    try {
      const response = await adminApiRequest<AdminDepositsRuntimeSummary>(
        ADMIN_EFHC_DEPOSITS_RUNTIME_SUMMARY_PATH,
        "GET",
      );
      setRuntimeSummary(response);
    } catch (e: any) {
      setError((prev) => prev || adminSafeLoadError(e));
    }
  }

  async function replayAutomatedPath() {
    if (!form.tx_hash.trim()) {
      setError("tx_hash is required for replay.");
      setFocusMode("result");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const response = await adminApiRequest<ProcessResult>(
        adminPath(ADMIN_EFHC_DEPOSITS_REPROCESS_TX_HASH_PATH, {
          tx_hash: form.tx_hash.trim(),
        }),
        "POST",
        { idempotencyKey: newIdempotencyKey() },
      );
      setResult(response);
      setFocusMode("result");
      await loadRuntimeSummary();
    } catch (e: any) {
      setError(adminSafeLoadError(e));
      setFocusMode("result");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void loadRuntimeSummary();
  }, []);

  async function submit() {
    setLoading(true);
    setError(null);
    try {
      const rawTx = form.raw_tx.trim();
      const body = {
        tx_hash: form.tx_hash.trim(),
        amount: form.amount.trim(),
        memo: form.memo.trim() || null,
        from_address: form.from_address.trim() || null,
        to_address: form.to_address.trim() || null,
        raw_tx: rawTx ? JSON.parse(rawTx) : null,
      };
      const response = await adminApiRequest<ProcessResult>(
        ADMIN_EFHC_DEPOSITS_PROCESS_PATH,
        "POST",
        {
          body,
          idempotencyKey: newIdempotencyKey(),
        },
      );
      setResult(response);
      setFocusMode("result");
      setConfirmOpen(false);
      await loadRuntimeSummary();
    } catch (e: any) {
      setError(adminSafeLoadError(e));
      setFocusMode("result");
    } finally {
      setLoading(false);
    }
  }


  async function forceFulfill() {
    setLoading(true);
    setError(null);
    try {
      const orderId = Number(fulfillForm.order_id);
      const response = await adminApiRequest<ProcessResult>(
        adminPath(ADMIN_SHOP_ORDERS_ORDER_ID_FORCE_FULFILL_PATH, {
          order_id: orderId,
        }),
        "POST",
        {
          body: { reason: fulfillForm.reason.trim() || "manual force fulfill" },
          idempotencyKey: newIdempotencyKey(),
        },
      );
      setResult(response);
      setFocusMode("result");
      setFulfillModalOpen(false);
      await loadRuntimeSummary();
    } catch (e: any) {
      setError(adminSafeLoadError(e));
      setFocusMode("result");
    } finally {
      setLoading(false);
    }
  }

  const summary = [
    `tx_hash: ${form.tx_hash || "—"}`,
    `amount: ${form.amount || "—"}`,
    `memo: ${form.memo || "—"}`,
    `from: ${form.from_address || "—"}`,
    `to: ${form.to_address || "—"}`,
    `note: ${form.note || "—"}`,
  ].join("\n");

  const filledFields = useMemo(
    () =>
      [
        form.tx_hash,
        form.amount,
        form.memo,
        form.from_address,
        form.to_address,
        form.raw_tx,
        form.note,
      ].filter((value) => value.trim().length > 0).length,
    [form],
  );

  const resultEntries = useMemo(
    () => (result ? Object.entries(result) : []),
    [result],
  );

  const rawTxState = useMemo(() => {
    if (!form.raw_tx.trim()) return "empty";
    try {
      JSON.parse(form.raw_tx);
      return "valid";
    } catch {
      return "invalid";
    }
  }, [form.raw_tx]);

  const finalResultLabel = useMemo(() => {
    if (error) return "operator attention";
    if (!result) return "not started";
    const replayStatus = String(result.replay_status || "").toLowerCase();
    if (replayStatus === "credited") return "automated credit restored";
    if (replayStatus === "duplicate") return "already credited";
    if (replayStatus === "pending_manual") return "exception path required";
    if (String(result.ok) === "true") return "result captured";
    return "check result detail";
  }, [error, result]);

  const finalResultTone = useMemo(() => {
    if (error) return "warning" as const;
    if (!result) return "neutral" as const;
    const replayStatus = String(result.replay_status || "").toLowerCase();
    if (replayStatus === "credited" || replayStatus === "duplicate") {
      return "success" as const;
    }
    if (replayStatus === "pending_manual") return "warning" as const;
    if (String(result.ok) === "true") return "success" as const;
    return "neutral" as const;
  }, [error, result]);

  return (
    <AdminPage
      surfaceBadges={[
        { label: "automated", tone: "connected" },
        { label: "automated_with_operator_fallback", tone: "connected" },
        { label: "release_core_eligible", tone: "neutral" },
        { label: "operator_exception_path", tone: "warning" },
      ]}
      infoBlock={{
        title: "Автоматизированный контур с fallback",
        description: (
          "Депозиты EFHC теперь используют основной автоматический путь. " +
          "Оператор остаётся fallback для replay и исключений, " +
          "not the base processing mode."
        ),
      }}
      title="Депозиты EFHC"
      subtitle="Production-grade автоматизация с операторским fallback"
      backHref="/admin"
      actions={
        <Button
          variant="secondary"
          onClick={() => setFocusMode(result ? "result" : "input")}
        >
          Активная панель
        </Button>
      }
    >

      <AdminDepositsDashboardRuntime
        error={error}
        finalResultLabel={finalResultLabel}
        finalResultTone={finalResultTone}
        formReadyFields={filledFields}
        loading={loading}
        onRefresh={() => void loadRuntimeSummary()}
        rawTxState={rawTxState}
        resultFieldCount={resultEntries.length}
        summary={runtimeSummary}
        updatedAt="runtime summary snapshot"
      />

      <AdminRouteHealthStrip
        title="Диагностика маршрута"
        subtitle="Основной автоматический путь плюс маршруты replay и exception."
        items={[
          {
            label: "runtime summary",
            path: "/admin/efhc-deposits/runtime-summary",
            tone: "connected",
          },
          {
            label: "reprocess",
            path: "/admin/efhc-deposits/reprocess/{tx_hash}",
            tone: "warning",
          },
          {
            label: "process exception",
            path: "/admin/efhc-deposits/process",
            tone: "warning",
          },
        ]}
      />

      <TelegramInfoBlock
        title="Статус operator contour"
        description={
          "Основной поток депозита автоматизирован. Операторские действия ограничены " +
          "to replay, recovery, and exception handling."
        }
      />

      <TelegramInfoBlock
        title="Предпочтительная audit chain"
        description={
          "1) runtime summary, 2) replay automated path, " +
          "3) process exception only if unresolved, 4) final result detail."
        }
      />

      <AdminActionGrid
        title="Действия оператора"
        subtitle="Сначала автоматизация, затем replay, последним — ручной exception path."
        items={[
          {
            label: "Replay automated path",
            note: "Повторно запустить watcher path для текущего tx_hash.",
            onClick: () => void replayAutomatedPath(),
            disabled: loading || !form.tx_hash.trim(),
          },
          {
            label: "Открыть подтверждение",
            note: "Использовать ручную exception-path обработку.",
            onClick: () => setConfirmOpen(true),
            disabled: loading,
          },
          {
            label: "Фокус на вводе",
            note: "Показать левый snapshot как основную панель.",
            onClick: () => setFocusMode("input"),
          },
          {
            label: "Фокус на результате",
            note: "Переключить detail shell на ответ обработки.",
            onClick: () => setFocusMode("result"),
            variant: "ghost",
          },
        ]}
      />

      <div className="grid gap-3 md:grid-cols-3">
        <AdminStatCard
          label="Заполнено полей"
          value={filledFields}
          hint="Сколько входных полей уже заполнено оператором."
        />
        <AdminStatCard
          label="raw_tx"
          value={rawTxState}
          hint="Локальная JSON-проверка перед confirm step."
          tone={
            rawTxState === "valid"
              ? "success"
              : rawTxState === "invalid"
                ? "warning"
                : "neutral"
          }
        />
        <AdminStatCard
          label="Автозачислено"
          value={runtimeSummary?.auto_credited_count ?? "—"}
          hint="Сколько inbox-строк уже завершились автоматическим начислением."
          tone="success"
        />
        <AdminStatCard
          label="Ожидают ручной обработки"
          value={runtimeSummary?.pending_manual_count ?? "—"}
          hint="Строки, которым всё ещё нужен replay или операторская обработка исключений."
          tone="warning"
        />
        <AdminStatCard
          label="Final result"
          value={finalResultLabel}
          hint="Result path after replay or exception processing."
          tone={finalResultTone}
        />
        <AdminStatCard
          label="Результат"
          value={resultEntries.length || "—"}
          hint="Количество полей в ответе ручной обработки."
          tone={result ? "success" : "neutral"}
        />
      </div>

      <div className="grid gap-4 xl:grid-cols-[0.95fr_1.05fr]">
        <AdminListShell
          title="Снимок ввода"
          subtitle="Левая колонка показывает оператору, что уже собрано перед запуском."
        >
          <TelegramSectionRow
            title="tx_hash"
            subtitle={form.tx_hash || "Не заполнен"}
            rightSlot={
              <TelegramStatusBadge
                label={form.tx_hash ? "ready" : "empty"}
                tone={form.tx_hash ? "connected" : "neutral"}
              />
            }
          />
          <TelegramSectionRow
            title="amount"
            subtitle={form.amount || "Не заполнен"}
            rightSlot={
              <TelegramStatusBadge
                label={form.amount ? "ready" : "empty"}
                tone={form.amount ? "connected" : "neutral"}
              />
            }
          />
          <TelegramSectionRow
            title="memo"
            subtitle={form.memo || "Не указан"}
            rightSlot={
              <TelegramStatusBadge label="optional" tone="neutral" />
            }
          />
          <TelegramSectionRow
            title="from / to"
            subtitle={
              `${form.from_address || "—"} → ${form.to_address || "—"}`
            }
            rightSlot={
              <TelegramStatusBadge label="route" tone="neutral" />
            }
          />
          <TelegramSectionRow
            title="raw_tx JSON"
            subtitle={
              rawTxState === "valid"
                ? "JSON разобран локально до отправки."
                : rawTxState === "invalid"
                  ? "JSON содержит ошибку и требует правки."
                  : "Снимок raw_tx пока не добавлен."
            }
            rightSlot={
              <TelegramStatusBadge
                label={rawTxState}
                tone={
                  rawTxState === "valid"
                    ? "connected"
                    : rawTxState === "invalid"
                      ? "warning"
                      : "neutral"
                }
              />
            }
            onClick={() => setFocusMode("input")}
          />
          <TelegramSectionRow
            title="Шаг подтверждения"
            subtitle="Перед отправкой оператор видит итоговый summary и аудит-заметка."
            rightSlot={
              <TelegramStatusBadge
                label={confirmOpen ? "open" : "ready"}
                tone={confirmOpen ? "warning" : "neutral"}
              />
            }
            onClick={() => setConfirmOpen(true)}
          />
        </AdminListShell>

        <AdminDetailShell
          title={focusMode === "input" ? "Детали ввода" : "Детали результата"}
          subtitle={
            focusMode === "input"
              ? "Detail shell показывает текущий payload до запуска ручной обработки."
              : "Detail shell показывает текущий ответ обработки или ошибку."
          }
        >
          {focusMode === "input" ? (
            <>
              <label className="grid gap-1">
                <span className="text-xs">tx_hash</span>
                <input
                  className="efhc-input"
                  value={form.tx_hash}
                  onChange={(e) =>
                    setForm((prev) => ({
                      ...prev,
                      tx_hash: e.target.value,
                    }))
                  }
                />
              </label>
              <label className="grid gap-1">
                <span className="text-xs">amount</span>
                <input
                  className="efhc-input"
                  value={form.amount}
                  onChange={(e) =>
                    setForm((prev) => ({
                      ...prev,
                      amount: e.target.value,
                    }))
                  }
                />
              </label>
              <label className="grid gap-1">
                <span className="text-xs">memo</span>
                <input
                  className="efhc-input"
                  value={form.memo}
                  onChange={(e) =>
                    setForm((prev) => ({
                      ...prev,
                      memo: e.target.value,
                    }))
                  }
                />
              </label>
              <label className="grid gap-1">
                <span className="text-xs">from_address</span>
                <input
                  className="efhc-input"
                  value={form.from_address}
                  onChange={(e) =>
                    setForm((prev) => ({
                      ...prev,
                      from_address: e.target.value,
                    }))
                  }
                />
              </label>
              <label className="grid gap-1">
                <span className="text-xs">to_address</span>
                <input
                  className="efhc-input"
                  value={form.to_address}
                  onChange={(e) =>
                    setForm((prev) => ({
                      ...prev,
                      to_address: e.target.value,
                    }))
                  }
                />
              </label>
              <label className="grid gap-1">
                <span className="text-xs">raw_tx JSON</span>
                <textarea
                  className="efhc-input min-h-24"
                  value={form.raw_tx}
                  onChange={(e) =>
                    setForm((prev) => ({
                      ...prev,
                      raw_tx: e.target.value,
                    }))
                  }
                />
              </label>
              <label className="grid gap-1">
                <span className="text-xs">аудит-заметка</span>
                <textarea
                  className="efhc-input min-h-24"
                  value={form.note}
                  onChange={(e) =>
                    setForm((prev) => ({
                      ...prev,
                      note: e.target.value,
                    }))
                  }
                />
              </label>
              <div className="text-xs text-[color:var(--tg-hint)]">
                Primary flow is automated. Use replay first. Шаг подтверждения is
                kept for exception handling only.
              </div>
              <Button onClick={() => setConfirmOpen(true)} disabled={loading}>
                Открыть exception path
              </Button>
            </>
          ) : null}

          {focusMode === "result" ? (
            <>
              {error ? (
                <TelegramInfoBlock title="Статус раздела">{error || null}</TelegramInfoBlock>
              ) : null}
              {!error && !result ? (
                <TelegramInfoBlock title="Детали результата">
                  Операторская цепочка ещё не запускалась. Сначала проверьте runtime summary, затем replay, и только после этого используйте exception path при необходимости.
                </TelegramInfoBlock>
              ) : null}
              {result ? (
                <div className="space-y-2">
                  {resultEntries.map(([key, value]) => (
                    <TelegramSectionRow
                      key={key}
                      compact
                      title={key}
                      subtitle={
                        typeof value === "object"
                          ? JSON.stringify(value)
                          : String(value)
                      }
                      rightSlot={
                        <TelegramStatusBadge
                          label="result"
                          tone="neutral"
                        />
                      }
                    />
                  ))}
                </div>
              ) : null}
            </>
          ) : null}
        </AdminDetailShell>
      </div>

      <AdminPromptModal
        open={fulfillModalOpen}
        title="Принудительно исполнить заказ"
        submitLabel="Зачислить вручную"
        busy={loading}
        values={fulfillForm}
        fields={[
          { key: "order_id", label: "ID заказа" },
          { key: "reason", label: "Причина" },
        ]}
        onChange={(key, value) => {
          setFulfillForm((prev) => ({ ...prev, [key]: value }));
        }}
        onClose={() => setFulfillModalOpen(false)}
        onSubmit={() => void forceFulfill()}
      />

      <AdminPromptModal
        open={confirmOpen}
        title="Подтвердить обработку EFHC депозита"
        submitLabel="Запустить обработку"
        fields={[
          { key: "summary", label: "Контекст", type: "textarea" },
          { key: "note", label: "Аудит-заметка", type: "textarea" },
        ]}
        values={{ summary, note: form.note }}
        busy={loading}
        onChange={(key, value) => {
          if (key === "note") {
            setForm((prev) => ({ ...prev, note: value }));
          }
        }}
        onClose={() => setConfirmOpen(false)}
        onSubmit={() => {
          void submit();
        }}
      />
    </AdminPage>
  );
}
