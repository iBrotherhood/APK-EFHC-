import React, { useEffect, useState } from "react";
import { AdminPage } from "../../components/admin/AdminPage";
import {
  AdminReportsExportDownloadPanel,
} from "../../components/admin/AdminReportsExportDownloadPanel";
import {
  AdminReportsVisualDashboardPanel,
} from "../../components/admin/AdminReportsVisualDashboardPanel";
import { useT } from "../../hooks/useT";
import {
  ADMIN_REPORTS_OVERVIEW_PATH,
} from "../../lib/api/generated/adminSeams";
import { adminSafeLoadError, adminUiErrorMessage } from "../../lib/adminError";
import { useAdminLinkedTransport } from "../../queries/useAdminLinkedTransport";

type Overview = {
  ok: boolean;
  ts: string;
  counters: Record<string, number>;
  facts?: Record<string, string>;
  notes?: string | null;
};

export default function AdminReportsPage() {
  const adminApiRequest = useAdminLinkedTransport();
  const t = useT();
  const [overview, setOverview] = useState<Overview | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const res = await adminApiRequest<Overview>(
        ADMIN_REPORTS_OVERVIEW_PATH,
        "GET",
      );
      setOverview(res);
    } catch (e: unknown) {
      setError(adminSafeLoadError(e, t));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { void load(); }, []);

  return (
    <AdminPage
      title={t("admin.reports")}
      subtitle={t("admin.reports_note")}
      backHref="/admin"
    >
      <AdminReportsVisualDashboardPanel
        error={error}
        loading={loading}
        onRefresh={() => void load()}
        overview={overview}
      />
      <AdminReportsExportDownloadPanel
        loading={loading}
        onRefresh={() => void load()}
        overview={overview}
      />
    </AdminPage>
  );
}
