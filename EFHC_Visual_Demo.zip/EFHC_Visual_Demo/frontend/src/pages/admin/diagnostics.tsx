import React from "react";

import { AdminPage } from "../../components/admin/AdminPage";
import {
  AdminSectionCard,
} from "../../components/admin/AdminSectionCard";
import {
  AdminRouteHealthStrip,
} from "../../components/admin/AdminRouteHealthStrip";
import {
  SurfaceFactsStrip,
} from "../../components/ui/SurfaceFactsStrip";
import {
  AdminActionGrid,
} from "../../components/admin/AdminActionGrid";
import { Button } from "../../components/ui/Button";
import {
  AdminDiagnosticsTechnicalBoundaryPanel,
} from "../../components/admin/AdminDiagnosticsTechnicalBoundaryPanel";
import {
  AdminRuntimePosturePanel,
} from "../../components/admin/AdminRuntimePosturePanel";

export default function AdminDiagnosticsPage() {
  return (
    <AdminPage
      title="Диагностика"
      subtitle={
        "Сводная страница по основным контурам admin и " +
        "user-facing поверхностей."
      }
      backHref="/admin"
      surfaceBadges={[
        { label: "helper", tone: "neutral" },
        { label: "beta", tone: "warning" },
        { label: "non-core", tone: "neutral" },
        { label: "not release contour", tone: "warning" },
      ]}
      infoBlock={{
        title: "Классификация release-truth",
        description: (
          "Диагностика используется как обзорный non-core " +
          "helper-layer: он помогает оператору быстро " +
          "оценить маршруты и связки, но не является " +
          "отдельным боевым релизным модулем."
        ),
      }}
    >
      <AdminRuntimePosturePanel />

      <AdminDiagnosticsTechnicalBoundaryPanel />

      <AdminSectionCard
        title="Сводка админки"
        subtitle="Быстрый обзор главных admin-маршрутов и поверхностей."
      >
        <div className="space-y-4">
          <AdminRouteHealthStrip
            items={[
              {
                label: "dashboard",
                path: "/admin/reports/overview",
                tone: "connected",
              },
              {
                label: "shop",
                path: "/admin/shop/items",
                tone: "connected",
              },
              {
                label: "users",
                path: "/admin/users/search",
                tone: "connected",
              },
              {
                label: "withdrawals",
                path: "/admin/withdrawals",
                tone: "connected",
              },
              {
                label: "hub",
                path: "/admin/hub/links",
                tone: "connected",
              },
            ]}
          />
          <AdminRouteHealthStrip
            items={[
              {
                label: "bank",
                path: "/admin/bank/balance",
                tone: "connected",
              },
              {
                label: "referrals",
                path: "/admin/referrals/summary",
                tone: "connected",
              },
              {
                label: "logs",
                path: "/admin/logs/transfers",
                tone: "connected",
              },
              {
                label: "tasks",
                path: "/admin/tasks/refresh-statuses",
                tone: "warning",
              },
              {
                label: "efhc deposits",
                path: "/admin/efhc-deposits/runtime-summary",
                tone: "connected",
              },
            ]}
          />
        </div>
      </AdminSectionCard>

      <AdminSectionCard
        title="Пользовательская сводка"
        subtitle="Ключевые внешние страницы и их основные действия."
      >
        <div className="space-y-4">
          <SurfaceFactsStrip
            title="Витрина и портал"
            items={[
              {
                label: "catalog · /shopfront/catalog",
                tone: "connected",
              },
              {
                label: "profile · /shopfront/profile",
                tone: "connected",
              },
              {
                label: "hub handoff · /hub/efhc-handoff",
                tone: "connected",
              },
            ]}
          />
          <SurfaceFactsStrip
            title="Экономические действия"
            items={[
              {
                label: "exchange · /exchange/convert",
                tone: "connected",
              },
              {
                label: "withdraw · /withdraw/request",
                tone: "connected",
              },
              {
                label: "wallet required for withdraw",
                tone: "warning",
              },
            ]}
          />
        </div>
      </AdminSectionCard>




      <AdminSectionCard
        title="HUB / Storefront operator diagnostics"
        subtitle={
          "Технические сведения публичного HUB перенесены сюда, " +
          "чтобы пользователь видел только два действия."
        }
      >
        <div className="space-y-4">
          <SurfaceFactsStrip
            title="HUB handoff"
            items={[
              {
                label: "hub handoff · /hub/efhc-handoff",
                tone: "connected",
              },
              {
                label: "shop truth · /hub/shop-truth",
                tone: "warning",
              },
              {
                label: "vip url · https://getgems.io/efhc-nft",
                tone: "vip",
              },
            ]}
          />
          <SurfaceFactsStrip
            title="Public UI boundary"
            items={[
              {
                label: "public HUB · two actions only",
                tone: "connected",
              },
              { label: "diagnostics · admin only", tone: "connected" },
              {
                label: "wallet facts · profile/admin only",
                tone: "warning",
              },
            ]}
          />
        </div>
      </AdminSectionCard>



      <AdminSectionCard
        title="Browser-Shop payment diagnostics"
        subtitle={
          "Технические сведения витрины перенесены сюда, " +
          "чтобы публичная страница показывала только карточки."
        }
      >
        <div className="space-y-4">
          <SurfaceFactsStrip
            title="Storefront endpoints"
            items={[
              {
                label: "catalog · /shopfront/catalog",
                tone: "connected",
              },
              {
                label: "create payment · /shopfront/create-intent",
                tone: "connected",
              },
              {
                label: "payment status · /shopfront/intent-status",
                tone: "warning",
              },
            ]}
          />
          <SurfaceFactsStrip
            title="Public storefront boundary"
            items={[
              {
                label: "cards · title/description/price/pay",
                tone: "connected",
              },
              {
                label: "admin fields · diagnostics only",
                tone: "connected",
              },
              {
                label: "wallet and memo · hidden from public UI",
                tone: "warning",
              },
            ]}
          />
        </div>
      </AdminSectionCard>


      <AdminSectionCard
        title="Current release-core evidence subset"
        subtitle={
          "Подтверждённые зрелые admin-модули, которые входят в текущий " +
          "evidence pack без helper/deferred шума."
        }
      >
        <SurfaceFactsStrip
          title="Пакет доказательств"
          items={[
            { label: "withdrawals · release-core payout/outcome", tone: "connected" },
            { label: "bank · release-core balance/ledger", tone: "connected" },
            { label: "templates · release-core system texts", tone: "connected" },
            { label: "reports · release-core overview facts", tone: "connected" },
            { label: "efhc deposits · automation-first deposit", tone: "connected" },
          ]}
        />
      </AdminSectionCard>


      <AdminActionGrid
        title="Быстрые разделы админки"
        subtitle="Быстрые кнопки вместо простых ссылок для главных admin-контуров."
        items={[
          { href: "/admin/users", label: "Пользователи", note: "Поиск, карточка, VIP и корректировки." },
          { href: "/admin/shop", label: "Магазин", note: "Карточки товаров, статусы и история." },
          { href: "/admin/withdrawals", label: "Выводы", note: "Одобрение, отклонение и контроль статусов." },
          { href: "/admin/logs", label: "Логи", note: "Cursor-логи и подозрительные сигналы." },
          { href: "/admin/reports", label: "Отчёты", note: "Обзорные факты и графики." },
          { href: "/admin/hub", label: "Hub", note: "Управление hub links и порядком." },
        ]}
      />

      <AdminActionGrid
        title="Release-core finance actions"
        subtitle="Операторские действия с приоритетом автоматизации внутри live release-core evidence pack."
        items={[
          { href: "/admin/efhc-deposits", label: "Депозиты EFHC", note: "Контур с приоритетом автоматизации, операторским replay и exception fallback." },
          { href: "/admin/withdrawals", label: "Выводы", note: "Release-core путь выплат и контроля результата." },
          { href: "/admin/bank", label: "Банк", note: "Основная поверхность балансов и ledger review." },
        ]}
      />

      <AdminActionGrid
        title="Support and helper sections"
        subtitle="Видимый, но вторичный helper/internal/deferred кластер вне release-core доказательной базы."
        items={[
          { href: "/admin/diagnostics", label: "Диагностика", note: "Beta helper/internal route overview, не release-core evidence." },
          { href: "/admin/ads", label: "Реклама", note: "Beta compatibility/helper контур вне release-core proof." },
          { href: "/admin/sale-packages", label: "Sale packages", note: "Deferred beta read-only snapshot, не release-core evidence." },
        ]}
      />

      <div className="flex flex-wrap gap-2">
        <Button href="/admin" variant="secondary">Назад в admin</Button>
        <Button href="/browser-shop" variant="secondary">Открыть storefront</Button>
      </div>
    </AdminPage>
  );
}
