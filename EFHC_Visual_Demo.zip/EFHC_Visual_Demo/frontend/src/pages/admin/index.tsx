import dynamic from "next/dynamic";
import React, { useCallback, useEffect, useState } from "react";
import { AdminHeroPanel } from "../../components/admin/AdminHeroPanel";
import { AdminAppButtonGrid } from "../../components/admin/AdminAppButtonGrid";
import {
  AdminSecurityAttentionBadge,
} from "../../components/admin/AdminSecurityAttentionBadge";
import { AdminPage } from "../../components/admin/AdminPage";
import { AdminRouteHealthStrip } from "../../components/admin/AdminRouteHealthStrip";
import { AdminPromptModal } from "../../components/admin/AdminPromptModal";
import { AdminSectionCard } from "../../components/admin/AdminSectionCard";
import {
  AdminUiKitAdoptionProofPanel,
} from "../../components/admin/AdminUiKitAdoptionProofPanel";
import {
  AdminScreenshotQaPreparationPanel,
} from "../../components/admin/AdminScreenshotQaPreparationPanel";
import { AdminStatCard } from "../../components/admin/AdminStatCard";
import { Button } from "../../components/ui/Button";
import { RouteSkeleton } from "../../components/ui/RouteSkeleton";
import { AdminCharts } from "../../components/AdminCharts";
import { AdminTable } from "../../components/AdminTable";
import {
  AdminOverviewDashboardRuntime,
} from "../../components/admin/AdminOverviewDashboardRuntime";
import { useT } from "../../hooks/useT";
import { newIdempotencyKey } from "../../lib/idempotency";
import {
  ADMIN_REPORTS_OVERVIEW_PATH,
  ADMIN_TON_RECONCILE_PATH,
} from "../../lib/api/generated/adminSeams";
import { TelegramStatusBadge } from
  "../../components/ui/telegram/TelegramStatusBadge";
import { TelegramEmptyState } from
  "../../components/ui/telegram/TelegramEmptyState";
import { adminSafeLoadError, adminUiErrorMessage } from "../../lib/adminError";
import { useAdminLinkedTransport } from "../../queries/useAdminLinkedTransport";


const AdminObservabilityTimeseriesDashboardRuntime = dynamic(
  () => import(
    "../../components/admin/AdminObservabilityTimeseriesDashboardRuntime"
  ).then((mod) => mod.AdminObservabilityTimeseriesDashboardRuntime),
  {
    loading: () => (
      <section
        className="efhc-admin-dashboard-lazy-placeholder efhc-dashboard-surface"
        data-admin-observability-lazy-placeholder="1493"
        data-admin-heavy-panel-lazy-loaded="true"
        data-admin-heavy-panel-ssr="false"
      >
        <RouteSkeleton kind="table" rows={5} />
      </section>
    ),
    ssr: false,
  },
);

type Overview = {
  ok: boolean;
  ts: string;
  counters: Record<string, number>;
  facts?: Record<string, string>;
  notes?: string | null;
};

type AdminModule = {
  href: string;
  label: string;
  note: string;
  state: "live" | "helper" | "draft" | "deferred";
  releaseTier: "core" | "non_core" | "deferred";
};

const FACT_LABELS: Record<string, string> = {
  panels_total_bought: "Панелей активировано всего",
  panels_total_active: "Активных панелей",
  panels_total_archived: "Архивных панелей",
  panels_total_paid_efhc: "EFHC списано на панели",
  panels_total_paid__main__efhc: "EFHCm списано на панели",
  panels_total_paid_bonus_efhc: "EFHCb списано на панели",
  users_total_generated_kwh: "kWh сгенерировано всего",
  users_total_exchanged_kwh: "kWh обменяно в EFHC main",
  users_total__main__efhc: "EFHC main на балансах",
  users_total_bonus_efhc: "EFHCb на балансах",
};

const FACT_ORDER = [
  "users_total__main__efhc",
  "users_total_bonus_efhc",
  "users_total_generated_kwh",
  "users_total_exchanged_kwh",
  "panels_total_active",
  "panels_total_bought",
  "panels_total_paid_efhc",
  "panels_total_archived",
  "panels_total_paid__main__efhc",
  "panels_total_paid_bonus_efhc",
];


const CANONICAL_ADMIN_MODULES: AdminModule[] = [
  {
    href: "/admin/users",
    label: "Пользователи",
    note: "Профили, балансы, статусы и операторские действия.",
    state: "live",
    releaseTier: "core",
  },
  {
    href: "/admin/bank",
    label: "Банк",
    note: "EFHC main/bonus, банк и контроль проводок.",
    state: "live",
    releaseTier: "core",
  },
  {
    href: "/admin/withdrawals",
    label: "Выводы",
    note: "Заявки на вывод и финальные решения оператора.",
    state: "live",
    releaseTier: "core",
  },
  {
    href: "/admin/shop",
    label: "Магазин",
    note: "Товары, витрина, пакеты и платёжный контур.",
    state: "live",
    releaseTier: "core",
  },
  {
    href: "/admin/tasks",
    label: "Задания",
    note: "Каталог заданий, реклама, проверки и начисления.",
    state: "live",
    releaseTier: "core",
  },
  {
    href: "/admin/reports",
    label: "Отчёты",
    note: "Экономические показатели и контрольные отчёты.",
    state: "live",
    releaseTier: "core",
  },
  {
    href: "/admin/diagnostics",
    label: "Диагностика",
    note: "Служебные проверки, маршруты и состояние системы.",
    state: "helper",
    releaseTier: "non_core",
  },
  {
    href: "/admin/system",
    label: "Система",
    note: "Системные правила, замки и операторский контур.",
    state: "helper",
    releaseTier: "non_core",
  },
];

const CORE_MODULES: AdminModule[] = [
  {
    href: "/admin/users",
    label: "Пользователи",
    note: "Профили, балансы, статусы, ручные операторские действия.",
    state: "live",
    releaseTier: "core",
  },
  {
    href: "/admin/bank",
    label: "Банк",
    note: "Операторский контур EFHC main/bonus и банковские операции.",
    state: "live",
    releaseTier: "core",
  },
  {
    href: "/admin/withdrawals",
    label: "Выводы",
    note: "Заявки на вывод, статусы и финальные решения оператора.",
    state: "live",
    releaseTier: "core",
  },
  {
    href: "/admin/shop",
    label: "Магазин",
    note: "Товары, витрина, пакеты и платёжный контур.",
    state: "live",
    releaseTier: "core",
  },
  {
    href: "/admin/tasks",
    label: "Задания",
    note: "Каталог заданий, подписки, проверка и начисления.",
    state: "live",
    releaseTier: "core",
  },
  {
    href: "/admin/reports",
    label: "Отчёты",
    note: "Сводки, экономические показатели и контрольные отчёты.",
    state: "live",
    releaseTier: "core",
  },
  {
    href: "/admin/referrals",
    label: "Рефералы",
    note: "Дерево приглашений, бонусы и операторская проверка.",
    state: "live",
    releaseTier: "core",
  },
  {
    href: "/admin/panels",
    label: "Панели",
    note: "Активации панелей, генерация и состояние солнечного контура.",
    state: "live",
    releaseTier: "core",
  },
];

const OPERATION_MODULES: AdminModule[] = [
  {
    href: "/admin/hub",
    label: "HUB",
    note: "Управление публичными переходами: EFHC и VIP NFT.",
    state: "live",
    releaseTier: "core",
  },
  {
    href: "/admin/templates",
    label: "Шаблоны",
    note: "Глобальные шаблоны автоответов и системных текстов.",
    state: "live",
    releaseTier: "core",
  },
  {
    href: "/admin/efhc-deposits",
    label: "Депозиты EFHC",
    note: "Входящие EFHC, replay, ручные исключения и сверка.",
    state: "live",
    releaseTier: "core",
  },
];

const SERVICE_MODULES: AdminModule[] = [
  {
    href: "/admin/diagnostics",
    label: "Диагностика",
    note: "Состояние маршрутов и служебных проверок.",
    state: "helper",
    releaseTier: "non_core",
  },
  {
    href: "/admin/logs",
    label: "Логи",
    note: "Технические журналы и служебные события.",
    state: "helper",
    releaseTier: "non_core",
  },
  {
    href: "/admin/system",
    label: "Система",
    note: "Состояние конфигурации и системных правил.",
    state: "helper",
    releaseTier: "non_core",
  },
  {
    href: "/admin/ads",
    label: "Реклама",
    note: "Рекламный контур и вспомогательные настройки.",
    state: "live",
    releaseTier: "core",
  },
  {
    href: "/admin/sale-packages",
    label: "Пакеты",
    note: "Пакеты EFHC, цены, активность и способы оплаты.",
    state: "live",
    releaseTier: "core",
  },
];

function numericFact(value: string | undefined): number {
  if (!value) return 0;
  const parsed = Number(String(value).replace(/,/g, "."));
  return Number.isFinite(parsed) ? parsed : 0;
}

export default function AdminHome() {
  const adminApiRequest = useAdminLinkedTransport();
  const t = useT();
  const [ov, setOv] = useState<Overview | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [reconcileOpen, setReconcileOpen] = useState(false);
  const [reconcile, setReconcile] = useState<Record<string, string>>({
    last_hours: "6",
  });

  const hasTelegramAuth = (() => {
    try {
      const initData = (globalThis as any)?.Telegram?.WebApp?.initData;
      return Boolean(initData && typeof initData === "string");
    } catch {
      return false;
    }
  })();

  const load = useCallback(async () => {
    setMsg(null);
    try {
      const r = await adminApiRequest<Overview>(
        ADMIN_REPORTS_OVERVIEW_PATH,
        "GET",
      );
      setOv(r);
    } catch (e: any) {
      setOv(null);
      setMsg(adminUiErrorMessage(e, t));
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function runReconcile() {
    setMsg(null);
    try {
      const lastHours = Math.max(
        1,
        Math.min(168, Number(reconcile.last_hours || "6")),
      );
      const idk = newIdempotencyKey();
      await adminApiRequest<any>(ADMIN_TON_RECONCILE_PATH, "POST", {
        idempotencyKey: idk,
        body: { last_hours: lastHours, limit: 1000 },
      });
      setMsg("Сверка TON выполнена. Сводка обновлена.");
      setReconcileOpen(false);
      await load();
    } catch (e: any) {
      setMsg(adminUiErrorMessage(e, t));
    }
  }

  const allModules = [
    ...CORE_MODULES,
    ...OPERATION_MODULES,
    ...SERVICE_MODULES,
  ];
  const topFacts = FACT_ORDER.filter(
    (key) => key in (ov?.facts || {}),
  ).slice(0, 6);
  const chartFacts = FACT_ORDER.filter(
    (key) => key in (ov?.facts || {}),
  ).slice(0, 5);

  return (
    <AdminPage
      title="Админ-панель EFHC"
      subtitle="Операторская консоль: разделы, графики, действия и контроль."
      actions={
        <>
          <Button variant="secondary" onClick={() => setReconcileOpen(true)}>
            Сверить TON
          </Button>
        </>
      }
    >
      <AdminSecurityAttentionBadge />

      {msg ? (
        <AdminSectionCard title="Статус операции" subtitle={msg}>
          <div className="flex justify-end">
            <Button variant="secondary" onClick={load}>
              Обновить сводку
            </Button>
          </div>
        </AdminSectionCard>
      ) : null}

      <AdminOverviewDashboardRuntime
        hasTelegramAuth={hasTelegramAuth}
        modules={CORE_MODULES}
        operationModules={OPERATION_MODULES}
        overview={ov}
        serviceModules={SERVICE_MODULES}
        onRefresh={() => { void load(); }}
      />

      <AdminHeroPanel
        eyebrow="EFHC Operator Console"
        title="Главный пульт управления"
        subtitle={
          "Здесь оператор видит ключевые показатели и переходит "
          + "в полноценные подразделы админ-панели. Диагностика "
          + "не смешивается с бизнес-действиями."
        }
        badges={
          <>
            <TelegramStatusBadge
              label={
                hasTelegramAuth
                  ? "Telegram initData активен"
                  : "Нужен Telegram initData"
              }
              tone={hasTelegramAuth ? "connected" : "warning"}
            />
            <TelegramStatusBadge label="Русский операторский контур" />
            <TelegramStatusBadge label="Плитки разделов" tone="primary" />
          </>
        }
      />

      <AdminObservabilityTimeseriesDashboardRuntime />

      <AdminUiKitAdoptionProofPanel />

      <AdminScreenshotQaPreparationPanel />

      <div className="grid gap-3 md:grid-cols-4">
        <AdminStatCard
          label="Рабочих разделов"
          value={String(allModules.length)}
          meta="главный контур"
          hint="Пользователи, банк, выводы, магазин, задания и отчёты."
          tone="success"
        />
        <AdminStatCard
          label="Операций"
          value={ov ? String(Object.keys(ov.counters || {}).length) : "—"}
          meta={ov?.ts || "нет сводки"}
          hint="Количество backend-счётчиков в текущей сводке."
          tone="neutral"
        />
        <AdminStatCard
          label="Фактов"
          value={ov?.facts ? String(Object.keys(ov.facts).length) : "—"}
          meta="экономическая сводка"
          hint="Панели, kWh и EFHC-балансы."
          tone="neutral"
        />
        <AdminStatCard
          label="Сессия"
          value={hasTelegramAuth ? "Готова" : "Telegram"}
          meta="backend require_admin"
          hint="Админ-доступ проверяет backend по Telegram initData."
          tone={hasTelegramAuth ? "success" : "warning"}
        />
      </div>

      <AdminSectionCard
        title="Основные подразделы"
        subtitle={
          "Каждая крупная плитка ведёт в отдельный рабочий раздел. "
          + "Это не набор непонятных кнопок, а панель приложений."
        }
      >
        <div data-admin-home-app-grid="canonical-1317">
          <AdminAppButtonGrid items={allModules} />
        </div>
      </AdminSectionCard>

      <div className="grid gap-4 lg:grid-cols-2">
        <AdminCharts
          title="Графики ключевых показателей"
          subtitle="Быстрый визуальный обзор экономики EFHC."
          items={chartFacts.length ? chartFacts.map((key) => ({
            label: FACT_LABELS[key] || key,
            value: numericFact(ov?.facts?.[key]),
          })) : [
            { label: "Сводка пока не загружена", value: 0 },
          ]}
        />
        <AdminTable
          title="Быстрые факты"
          rows={topFacts.map((key) => ({
            label: FACT_LABELS[key] || key,
            value: ov?.facts?.[key] || "—",
          }))}
        />
      </div>

      <AdminSectionCard
        title="Операторские инструменты"
        subtitle="Дополнительные рабочие разделы без смешивания с диагностикой."
      >
        <AdminAppButtonGrid items={OPERATION_MODULES} />
      </AdminSectionCard>

      <details className="efhc-admin-service-details">
        <summary>Служебные разделы и диагностика</summary>
        <div className="efhc-admin-service-details_body">
          <AdminAppButtonGrid items={SERVICE_MODULES} />
          <AdminRouteHealthStrip
            title="Проверка внутренних маршрутов"
            subtitle={
              "Служебная зона для диагностики. Она больше не занимает "
              + "главный экран админ-панели."
            }
            items={[
              {
                label: "overview",
                path: "/admin/reports/overview",
                tone: "connected",
              },
              {
                label: "ton reconcile",
                path: "/admin/ton/reconcile",
                tone: "warning",
              },
              {
                label: "shop items",
                path: "/admin/shop/items",
                tone: "connected",
              },
              {
                label: "referrals",
                path: "/admin/referrals/summary",
                tone: "connected",
              },
            ]}
          />
        </div>
      </details>

      {!ov && !msg ? (
        <TelegramEmptyState
          title="Сводка пока не загружена"
          detail="Нажмите обновить, чтобы запросить overview админ-панели."
          actionLabel={t("common.refresh")}
          onAction={() => void load()}
        />
      ) : null}


      <AdminPromptModal
        open={reconcileOpen}
        title="Сверить TON"
        submitLabel="Запустить сверку"
        fields={[
          {
            key: "last_hours",
            label: "Период проверки, часов",
            placeholder: "6",
            type: "number",
          },
        ]}
        values={reconcile}
        onChange={(key, value) => {
          setReconcile((prev) => ({ ...prev, [key]: value }));
        }}
        onClose={() => setReconcileOpen(false)}
        onSubmit={() => { void runReconcile(); }}
      />
    </AdminPage>
  );
}
