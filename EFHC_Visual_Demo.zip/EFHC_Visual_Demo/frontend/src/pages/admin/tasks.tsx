import React, { useEffect, useMemo, useState } from "react";

import { AdminActionGrid } from "../../components/admin/AdminActionGrid";
import { AdminPage } from "../../components/admin/AdminPage";
import { AdminTasksCatalogUxPanel } from "../../components/admin/AdminTasksCatalogUxPanel";
import { AdminTasksDashboardRuntime } from "../../components/admin/AdminTasksReferralsDashboardRuntime";
import { AdminTasksExecutionTracePanel } from "../../components/admin/AdminTasksExecutionTracePanel";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { TelegramInfoBlock } from "../../components/ui/telegram/TelegramInfoBlock";
import { TelegramSectionRow } from "../../components/ui/telegram/TelegramSectionRow";
import { TelegramStatusBadge } from "../../components/ui/telegram/TelegramStatusBadge";
import {
  adminPath,
  ADMIN_TASKS_PATH,
  ADMIN_TASKS_TASK_ID_SUBS_PATH,
  ADMIN_TASKS_SUBMISSIONS_SUBMISSION_ID_MODERATE_PATH,
  ADMIN_LOGS_TRANSFERS_PATH,
  ADMIN_TASKS_REFRESH_STATUSES_PATH,
} from "../../lib/api/generated/adminSeams";
import { adminSafeLoadError, adminUiErrorMessage } from "../../lib/adminError";
import { useAdminLinkedTransport } from "../../queries/useAdminLinkedTransport";

type AdminTaskItem = {
  id: number;
  title: string;
  description: string | null;
  is_active: boolean;
  bonus_efhc?: string;
  kind: string;
  created_at: string;
  updated_at: string;
};

type AdminTasksListOut = {
  items: AdminTaskItem[];
  next_cursor: string | null;
};

type SubmissionStatus = "PENDING" | "APPROVED" | "REJECTED" | string;

type AdminSubmissionItem = {
  id: number;
  task_id: number;
  tg_id: number;
  status: SubmissionStatus;
  proof_text: string | null;
  proof_url: string | null;
  submitted_at: string;
  reviewed_at: string | null;
  bonus_efhc?: string | null;
  moderator_tg_id: number | null;
  moderator_note: string | null;
};

type AdminSubmissionsOut = {
  items: AdminSubmissionItem[];
  next_cursor: string | null;
};

type AdminTaskTraceItem = {
  id: number;
  tg_id: number;
  amount: string;
  direction: string;
  balance_type: string;
  reason: string;
  idempotency_key: string;
  created_at: string;
};

type AdminTaskTraceOut = {
  ok: boolean;
  items: AdminTaskTraceItem[];
  next_cursor: string | null;
};

function makeIdempotencyKey(prefix: string): string {
  const random =
    typeof crypto !== "undefined" && "randomUUID" in crypto
      ? crypto.randomUUID()
      : `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
  return `${prefix}:${random}`;
}

function statusTone(
  status: SubmissionStatus,
):
  | "primary"
  | "connected"
  | "warning"
  | "neutral"
  | "inactive"
  | "active"
  | "vip" {
  const raw = String(status || "PENDING").toUpperCase();
  if (raw === "APPROVED") return "connected";
  if (raw === "REJECTED") return "warning";
  return "primary";
}

function looksLikeImage(url: string): boolean {
  return /\.(png|jpe?g|webp|gif)$/i.test(url);
}

export default function AdminTasksPage() {
  const adminApiRequest = useAdminLinkedTransport();
  const [msg, setMsg] = useState<string | null>(null);
  const [loadingTasks, setLoadingTasks] = useState(false);
  const [loadingSubs, setLoadingSubs] = useState(false);
  const [tasksError, setTasksError] = useState<string | null>(null);
  const [subsError, setSubsError] = useState<string | null>(null);
  const [tasks, setTasks] = useState<AdminTaskItem[]>([]);
  const [taskCursor, setTaskCursor] = useState<string | null>(null);
  const [selectedTaskId, setSelectedTaskId] = useState<number | null>(null);
  const [selectedStatus, setSelectedStatus] = useState<string>("PENDING");
  const [subs, setSubs] = useState<AdminSubmissionItem[]>([]);
  const [subsCursor, setSubsCursor] = useState<string | null>(null);
  const [busySubmissionId, setBusySubmissionId] = useState<number | null>(null);
  const [moderatorNotes, setModeratorNotes] = useState<Record<number, string>>(
    {},
  );

  const [traceItems, setTraceItems] = useState<AdminTaskTraceItem[]>([]);
  const [traceCursor, setTraceCursor] = useState<string | null>(null);
  const [traceError, setTraceError] = useState<string | null>(null);
  const [loadingTrace, setLoadingTrace] = useState(false);

  const selectedTask = useMemo(
    () => tasks.find((task) => task.id === selectedTaskId) || null,
    [tasks, selectedTaskId],
  );

  async function loadTasks(cursor?: string | null): Promise<void> {
    setLoadingTasks(true);
    setTasksError(null);
    try {
      const query = new URLSearchParams();
      query.set("limit", "25");
      if (cursor) query.set("cursor", cursor);
      const out = await adminApiRequest<AdminTasksListOut>(
        `${ADMIN_TASKS_PATH}?${query.toString()}`,
        "GET",
      );
      setTasks((prev) => (cursor ? [...prev, ...out.items] : out.items));
      setTaskCursor(out.next_cursor || null);
      if (!cursor && out.items.length > 0) {
        setSelectedTaskId(out.items[0].id);
      }
    } catch (error) {
      setTasksError(adminSafeLoadError(error));
    } finally {
      setLoadingTasks(false);
    }
  }

  async function loadSubmissions(
    taskId: number,
    cursor?: string | null,
    statusFilter?: string,
  ): Promise<void> {
    setLoadingSubs(true);
    setSubsError(null);
    try {
      const query = new URLSearchParams();
      query.set("limit", "25");
      if (cursor) query.set("cursor", cursor);
      const normalized = statusFilter || selectedStatus;
      if (normalized && normalized !== "ALL") {
        query.set("status", normalized);
      }
      const out = await adminApiRequest<AdminSubmissionsOut>(
        `${adminPath(ADMIN_TASKS_TASK_ID_SUBS_PATH, {
          task_id: taskId,
        })}?${query.toString()}`,
        "GET",
      );
      const nextItems = out.items || [];
      setSubs((prev) => (cursor ? [...prev, ...nextItems] : nextItems));
      if (!cursor) {
        setModeratorNotes(
          Object.fromEntries(
            nextItems.map((item) => [item.id, item.moderator_note || ""]),
          ),
        );
      }
      setSubsCursor(out.next_cursor || null);
    } catch (error) {
      setSubsError(adminSafeLoadError(error));
    } finally {
      setLoadingSubs(false);
    }
  }

  async function moderateSubmission(
    submissionId: number,
    approve: boolean,
  ): Promise<void> {
    if (!selectedTaskId) return;
    setBusySubmissionId(submissionId);
    setMsg(null);
    try {
      const payload = {
        approve,
        moderator_note: moderatorNotes[submissionId] || null,
      };
      await adminApiRequest<AdminSubmissionItem>(
        adminPath(ADMIN_TASKS_SUBMISSIONS_SUBMISSION_ID_MODERATE_PATH, {
          submission_id: submissionId,
        }),
        "POST",
        {
          body: payload,
          idempotencyKey: makeIdempotencyKey(
            approve ? "task-approve" : "task-reject",
          ),
        },
      );
      setMsg(
        approve
          ? `Заявка #${submissionId} одобрена.`
          : `Заявка #${submissionId} отклонена.`,
      );
      await loadSubmissions(selectedTaskId, null, selectedStatus);
      void loadTaskTrace();
    } catch (error) {
      setMsg(adminUiErrorMessage(error));
    } finally {
      setBusySubmissionId(null);
    }
  }

  async function loadTaskTrace(cursor?: string | null): Promise<void> {
    setLoadingTrace(true);
    setTraceError(null);
    try {
      const query = new URLSearchParams();
      query.set("limit", "25");
      query.set("reason", "task_bonus");
      if (cursor) query.set("cursor", cursor);
      const out = await adminApiRequest<AdminTaskTraceOut>(
        `${ADMIN_LOGS_TRANSFERS_PATH}?${query.toString()}`,
        "GET",
      );
      const nextItems = out.items || [];
      setTraceItems((prev) => (cursor ? [...prev, ...nextItems] : nextItems));
      setTraceCursor(out.next_cursor || null);
    } catch (error) {
      setTraceError(adminSafeLoadError(error));
    } finally {
      setLoadingTrace(false);
    }
  }

  async function runRefresh(): Promise<void> {
    setMsg(null);
    try {
      const res = await adminApiRequest<{ detail?: string }>(
        ADMIN_TASKS_REFRESH_STATUSES_PATH,
        "POST",
      );
      setMsg(res?.detail || "Синхронизация статусов выполнена");
    } catch (error) {
      setMsg(adminUiErrorMessage(error));
    }
  }

  useEffect(() => {
    void loadTasks();
    void loadTaskTrace();
  }, []);

  useEffect(() => {
    if (!selectedTaskId) return;
    void loadSubmissions(selectedTaskId, null, selectedStatus);
  }, [selectedTaskId, selectedStatus]);

  return (
    <AdminPage
      title="Задачи"
      subtitle={
        "Основной операционный контур: очередь модерации заявок, " +
        "быстрые approve/reject и ручная синхронизация статусов."
      }
      backHref="/admin"
      surfaceBadges={[
        { label: "Задания", tone: "neutral" },
        { label: "Модерация", tone: "connected" },
      ]}
      infoBlock={{
        title: "Операторская модерация заданий",
        description:
          "Страница содержит живое ядро модерации заявок и " +
          "вспомогательные обзорные блоки для оператора. " +
          "Разметка нужна, чтобы не путать рабочие действия с обзором.",
      }}
    >
      <AdminTasksDashboardRuntime
        tasks={tasks}
        submissions={subs}
        traces={traceItems}
        selectedTaskId={selectedTaskId}
        selectedTaskTitle={selectedTask?.title || null}
        selectedStatus={selectedStatus}
        loadingTasks={loadingTasks}
        loadingSubmissions={loadingSubs}
        loadingTrace={loadingTrace}
        tasksError={tasksError}
        submissionsError={subsError}
        traceError={traceError}
        updatedAt={new Date().toISOString()}
        onRefreshTasks={() => void loadTasks()}
        onRefreshSubmissions={() => {
          if (selectedTaskId) {
            void loadSubmissions(selectedTaskId, null, selectedStatus);
          }
        }}
        onRefreshTrace={() => void loadTaskTrace()}
      />

      <AdminTasksCatalogUxPanel
        tasks={tasks}
        submissions={subs}
        selectedTaskId={selectedTaskId}
        selectedStatus={selectedStatus}
        loadingTasks={loadingTasks}
        loadingSubmissions={loadingSubs}
        tasksError={tasksError}
        submissionsError={subsError}
        operationMessage={msg}
        taskCursor={taskCursor}
        submissionsCursor={subsCursor}
        onSelectTask={setSelectedTaskId}
        onStatusChange={setSelectedStatus}
        onRefreshTasks={() => void loadTasks()}
        onRefreshSubmissions={() => {
          if (selectedTaskId) {
            void loadSubmissions(selectedTaskId, null, selectedStatus);
          }
        }}
        onRefreshStatuses={() => void runRefresh()}
      />

      <AdminTasksExecutionTracePanel
        traces={traceItems}
        loading={loadingTrace}
        error={traceError}
        cursor={traceCursor}
        selectedTaskTitle={selectedTask?.title || null}
        onRefresh={() => void loadTaskTrace()}
        onLoadMore={() => {
          if (traceCursor) {
            void loadTaskTrace(traceCursor);
          }
        }}
      />

      <div className="grid gap-4 xl:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]">
        <Card title="Боевые задания">
          <div className="space-y-3">
            <TelegramInfoBlock title="Назначение панели">
              Сначала выбирается задание, затем справа открывается очередь
              заявок по нему. Это не техническая заглушка, а рабочая поверхность
              модерации для Blitz-Launch.
            </TelegramInfoBlock>

            {tasksError ? (
              <TelegramInfoBlock title="Ошибка списка заданий">
                {tasksError}
              </TelegramInfoBlock>
            ) : null}

            <div className="space-y-2">
              {tasks.map((task) => (
                <TelegramSectionRow
                  key={task.id}
                  title={`#${task.id} · ${task.title}`}
                  subtitle={
                    `${task.bonus_efhc} EFHC · ${task.kind}` +
                    (task.description ? ` · ${task.description}` : "")
                  }
                  compact
                  onClick={() => setSelectedTaskId(task.id)}
                  rightSlot={
                    <TelegramStatusBadge
                      label={task.is_active ? "Активно" : "Неактивно"}
                      tone={task.is_active ? "connected" : "inactive"}
                    />
                  }
                  className={
                    selectedTaskId === task.id
                      ? "border-[color:var(--tg-button)]/60"
                      : ""
                  }
                />
              ))}
            </div>

            {loadingTasks ? (
              <div className="text-xs efhc-text-muted">Загрузка заданий…</div>
            ) : null}

            {taskCursor ? (
              <Button
                variant="secondary"
                onClick={() => void loadTasks(taskCursor)}
              >
                Загрузить ещё задания
              </Button>
            ) : null}
          </div>
        </Card>

        <Card title="Поверхность модерации заявок">
          <div className="space-y-3">
            <TelegramInfoBlock
              title={
                selectedTask
                  ? `Очередь по задаче #${selectedTask.id}`
                  : "Очередь модерации"
              }
            >
              {selectedTask
                ? `Проверка заявок по «${selectedTask.title}». Одобрение идёт идемпотентно через банк.`
                : "Выберите задание слева, чтобы открыть очередь заявок."}
            </TelegramInfoBlock>

            <div className="flex flex-wrap gap-2">
              {[
                { key: "PENDING", label: "Ожидает" },
                { key: "APPROVED", label: "Одобрено" },
                { key: "REJECTED", label: "Отклонено" },
                { key: "ALL", label: "Все" },
              ].map((item) => (
                <Button
                  key={item.key}
                  variant={
                    selectedStatus === item.key ? "primary" : "secondary"
                  }
                  onClick={() => setSelectedStatus(item.key)}
                >
                  {item.label}
                </Button>
              ))}
              <Button
                variant="secondary"
                onClick={() => {
                  if (selectedTaskId) {
                    void loadSubmissions(selectedTaskId, null, selectedStatus);
                  }
                }}
                disabled={!selectedTaskId}
              >
                Обновить очередь
              </Button>
              <Button variant="secondary" onClick={() => void runRefresh()}>
                Обновить статусы
              </Button>
            </div>

            {subsError ? (
              <TelegramInfoBlock title="Ошибка списка заявок">
                {subsError}
              </TelegramInfoBlock>
            ) : null}

            {!selectedTaskId ? (
              <TelegramInfoBlock title="Нужно выбрать задание">
                Без выбранного задания очередь модерации не открывается.
              </TelegramInfoBlock>
            ) : null}

            {selectedTaskId && subs.length === 0 && !loadingSubs ? (
              <TelegramInfoBlock title="Заявок пока нет">
                Для текущего фильтра новых заявок не найдено.
              </TelegramInfoBlock>
            ) : null}

            <div className="space-y-3">
              {subs.map((item) => (
                <div key={item.id} className="rounded-2xl border p-3 space-y-3">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="text-sm font-semibold">
                        Заявка #{item.id} · tg_id {item.tg_id}
                      </div>
                      <div className="text-xs efhc-text-muted">
                        создана {item.submitted_at}
                        {item.bonus_efhc
                          ? ` · бонус ${item.bonus_efhc} EFHC`
                          : ""}
                      </div>
                    </div>
                    <TelegramStatusBadge
                      label={String(item.status)}
                      tone={statusTone(item.status)}
                    />
                  </div>

                  <TelegramInfoBlock title="Карточка доказательства">
                    <div className="space-y-3">
                      <div className="grid gap-2 sm:grid-cols-2">
                        <div className="rounded-2xl border p-3">
                          <div className="text-xs efhc-text-muted">создана</div>
                          <div className="mt-1 text-sm">
                            {item.submitted_at}
                          </div>
                        </div>
                        <div className="rounded-2xl border p-3">
                          <div className="text-xs efhc-text-muted">
                            проверка / модератор
                          </div>
                          <div className="mt-1 text-sm">
                            {item.reviewed_at || "ещё не проверялась"}
                            {item.moderator_tg_id
                              ? ` · tg_id ${item.moderator_tg_id}`
                              : ""}
                          </div>
                        </div>
                      </div>

                      {item.proof_text ? (
                        <div className="rounded-2xl border p-3 text-sm whitespace-pre-wrap">
                          {item.proof_text}
                        </div>
                      ) : null}

                      {item.proof_url ? (
                        <>
                          {looksLikeImage(item.proof_url) ? (
                            <img
                              src={item.proof_url}
                              alt={`proof-${item.id}`}
                              className="max-h-72 w-full rounded-2xl object-contain border bg-[var(--tg-secondary-bg)]"
                            />
                          ) : null}
                          <div className="rounded-2xl border p-3 break-all text-sm">
                            {item.proof_url}
                          </div>
                          <a
                            href={item.proof_url}
                            target="_blank"
                            rel="noreferrer"
                            className="underline break-all text-sm"
                          >
                            Открыть proof
                          </a>
                        </>
                      ) : (
                        <div className="rounded-2xl border p-3 text-sm">
                          В заявке нет `proof_url`. Модератору нужно принять
                          решение по текущим данным и описанию задания.
                        </div>
                      )}
                    </div>
                  </TelegramInfoBlock>

                  <div className="space-y-2">
                    <div className="text-xs efhc-text-muted">
                      Комментарий модератора / причина решения
                    </div>
                    <textarea
                      value={moderatorNotes[item.id] || ""}
                      onChange={(event) =>
                        setModeratorNotes((prev) => ({
                          ...prev,
                          [item.id]: event.target.value,
                        }))
                      }
                      rows={3}
                      className="w-full rounded-2xl border bg-[var(--tg-secondary-bg)] p-3 text-sm outline-none"
                      placeholder="Введите причину отказа или пояснение к решению"
                    />
                    {item.moderator_note ? (
                      <div className="rounded-2xl border p-3 text-sm whitespace-pre-wrap">
                        Сохранённый комментарий: {item.moderator_note}
                      </div>
                    ) : null}
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <Button
                      onClick={() => void moderateSubmission(item.id, true)}
                      disabled={
                        busySubmissionId === item.id ||
                        item.status === "APPROVED"
                      }
                    >
                      Одобрить
                    </Button>
                    <Button
                      variant="secondary"
                      onClick={() => void moderateSubmission(item.id, false)}
                      disabled={
                        busySubmissionId === item.id ||
                        item.status === "REJECTED"
                      }
                    >
                      Отклонить
                    </Button>
                  </div>
                </div>
              ))}
            </div>

            {loadingSubs ? (
              <div className="text-xs efhc-text-muted">Загрузка заявок…</div>
            ) : null}

            {subsCursor && selectedTaskId ? (
              <Button
                variant="secondary"
                onClick={() =>
                  void loadSubmissions(
                    selectedTaskId,
                    subsCursor,
                    selectedStatus,
                  )
                }
              >
                Загрузить ещё заявки
              </Button>
            ) : null}
          </div>
        </Card>
      </div>

      <AdminActionGrid
        title="Служебные переходы"
        subtitle="Модуль заданий работает через очередь модерации, а не через пустой технический экран."
        items={[
          {
            href: "/admin/logs",
            label: "Открыть логи",
            note: "Журнал idempotency, suspicious и task-related событий.",
          },
          {
            href: "/admin/reports",
            label: "Открыть отчёты",
            note: "Сводки и обзорные факты по admin-контуру.",
          },
          {
            href: "/admin/withdrawals",
            label: "Открыть withdrawals",
            note: "Соседний операторский контур вывода и банковских действий.",
          },
        ]}
      />
    </AdminPage>
  );
}
