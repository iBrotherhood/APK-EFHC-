import React from "react";

import { AdminLogsEventsDashboardRuntime } from "../../components/admin/AdminLogsEventsDashboardRuntime";
import { AdminPage } from "../../components/admin/AdminPage";
import { AdminSectionCard } from "../../components/admin/AdminSectionCard";
import { TelegramSectionRow } from "../../components/ui/telegram/TelegramSectionRow";

export default function AdminLogsPage() {
  return (
    <AdminPage
      title="Логи"
      subtitle="Операторская страница контроля runtime-событий и безопасных логов."
      backHref="/admin"
      surfaceBadges={[
        { label: "Логи", tone: "neutral" },
        { label: "Read-only", tone: "connected" },
      ]}
      infoBlock={{
        title: "Logs / Events Dashboard",
        description:
          "Dashboard показывает только безопасный read-only snapshot событий. " +
          "Raw payload, debug JSON и секреты не выводятся.",
      }}
    >
      <AdminLogsEventsDashboardRuntime />

      <AdminSectionCard
        title="Команды для локальной проверки"
        subtitle="Использовать без удаления volume, чтобы не потерять локальную БД."
      >
        <div className="grid gap-2">
          <TelegramSectionRow
            compact
            title="Docker runtime"
            subtitle="docker compose logs -f backend frontend"
          />
          <TelegramSectionRow
            compact
            title="Backend только"
            subtitle="docker compose logs -f backend"
          />
          <TelegramSectionRow
            compact
            title="Frontend только"
            subtitle="docker compose logs -f frontend"
          />
          <TelegramSectionRow
            compact
            title="Безопасная остановка"
            subtitle="docker compose down — без флага -v"
          />
        </div>
      </AdminSectionCard>
    </AdminPage>
  );
}
