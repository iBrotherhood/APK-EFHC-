export { default } from "../features/browser-shop/BrowserShopPage";
