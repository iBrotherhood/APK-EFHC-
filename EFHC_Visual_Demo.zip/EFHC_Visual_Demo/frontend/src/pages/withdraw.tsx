import React, { useContext, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/router";

import { LayoutContext } from "../components/Layout";
import { Button } from "../components/ui/Button";
import { SurfaceFactsStrip } from "../components/ui/SurfaceFactsStrip";
import { Card } from "../components/ui/Card";
import { EmptyState } from "../components/ui/EmptyState";
import {
  WithdrawStatusTimeline,
} from "../components/withdraw/WithdrawStatusTimeline";
import { TelegramStatusBadge } from "../components/ui/telegram/TelegramStatusBadge";
import { TelegramInfoBlock } from "../components/ui/telegram/TelegramInfoBlock";
import type { SyncSnapshot } from "../hooks/useSnapshot";
import { useWalletsMe } from "../hooks/useWalletsMe";
import { publicApiErrorMessage } from "../lib/publicError";
import { cmp8, format8, formatD8ToHuman } from "../lib/format";
import { newIdempotencyKey } from "../lib/idempotency";
import { hapticMedium, hapticSelection } from "../lib/telegram";
import { useAuthOwnerGlobalId } from "../auth/AuthSessionProvider";
import { useT } from "../hooks/useT";
import {
  balanceHistoryReasonLabel,
  balanceTypeLabel,
  withdrawOutcomeKindLabel,
  withdrawStatusLabel,
} from "../lib/humanLabels";
import {
  useCancelWithdrawRequest,
  useCreateWithdrawRequest,
  useWalletBalanceHistory,
  useWithdrawDetail,
  useWithdrawOutcome,
  useWithdrawalsPage,
} from "../queries/useWithdrawals";

// Guard marker: Latest withdraw outcome

function statusTone(status: string) {
  if (status === "PAID") return "connected" as const;
  if (status === "PENDING") return "warning" as const;
  return "neutral" as const;
}

function formatDate(value: string): string {
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return value;
  return parsed.toLocaleString();
}

function maskWallet(addr: string): string {
  if (addr.length < 14) return addr;
  return `${addr.slice(0, 6)}…${addr.slice(-6)}`;
}

function isValidD8(raw: string): boolean {
  const value = raw.trim();
  if (!value) return false;
  if (value.includes("e") || value.includes("E")) return false;
  if (value.includes("-")) return false;
  return /^\d+(\.\d{0,8})?$/.test(value);
}

export default function WithdrawPage(props: {
  tg_id: number | null;
  snap: SyncSnapshot | null;
}) {
  const tg_id = props.tg_id;
  const t = useT();
  const globalId = useAuthOwnerGlobalId();
  const router = useRouter();
  const mainBalance = format8(props.snap?.profile?.main_balance || "0");
  const mainBalanceHuman = formatD8ToHuman(mainBalance);
  const walletsMe = useWalletsMe(tg_id);
  const walletConnected = Boolean(walletsMe.data?.is_connected);
  const { confirm, openWalletConnect, settings, toast } =
    useContext(LayoutContext);
  const requestsRef = useRef<HTMLDivElement | null>(null);
  const historyRef = useRef<HTMLDivElement | null>(null);

  const [amount, setAmount] = useState(mainBalance);
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const withdrawalsQ = useWithdrawalsPage({ tg_id, statusFilter });
  const items = useMemo(
    () => withdrawalsQ.data?.pages.flatMap((page) => page.items) || [],
    [withdrawalsQ.data],
  );
  const detailQ = useWithdrawDetail(selectedId);
  const historyQ = useWalletBalanceHistory(tg_id);
  const createWithdrawMutation = useCreateWithdrawRequest(tg_id);
  const cancelWithdrawMutation = useCancelWithdrawRequest(tg_id);
  const latestFinalId = useMemo(
    () => items.find((item) =>
      ["PAID", "REJECTED", "CANCELED"].includes(item.status),
    )?.id || null,
    [items],
  );
  const outcomeQ = useWithdrawOutcome(latestFinalId);
  const detail = detailQ.data || null;
  const latestOutcome = outcomeQ.data || null;
  const historyItems = historyQ.data || [];
  const loading = withdrawalsQ.isLoading || withdrawalsQ.isFetching;
  const detailLoading = detailQ.isLoading || detailQ.isFetching;
  const latestOutcomeLoading = outcomeQ.isLoading || outcomeQ.isFetching;
  const historyLoading = historyQ.isLoading || historyQ.isFetching;
  const error = withdrawalsQ.error
    ? publicApiErrorMessage(withdrawalsQ.error, t)
    : createWithdrawMutation.error
      ? publicApiErrorMessage(createWithdrawMutation.error, t)
      : null;
  const detailError = detailQ.error
    ? publicApiErrorMessage(detailQ.error, t)
    : cancelWithdrawMutation.error
      ? publicApiErrorMessage(cancelWithdrawMutation.error, t)
      : null;
  const historyError = historyQ.error
    ? publicApiErrorMessage(historyQ.error, t)
    : null;
  const cursor = withdrawalsQ.hasNextPage
    ? withdrawalsQ.data?.pages.at(-1)?.next_cursor || null
    : null;
  const createBusy = createWithdrawMutation.isPending;
  const cancelBusyId = cancelWithdrawMutation.isPending
    ? cancelWithdrawMutation.variables?.requestId || null
    : null;

  useEffect(() => {
    setAmount(mainBalance);
  }, [mainBalance]);

  const withdrawMinOk = useMemo(
    () => cmp8(mainBalance, "10.00000000") >= 0,
    [mainBalance],
  );
  const withdrawAmountOk = useMemo(() => {
    if (!isValidD8(amount)) return false;
    const normalized = format8(amount);
    return (
      cmp8(normalized, "10.00000000") >= 0 && cmp8(normalized, mainBalance) <= 0
    );
  }, [amount, mainBalance]);

  const primaryWallet = useMemo(
    () =>
      walletsMe.data?.wallets.find((wallet) => wallet.is_primary) ||
      walletsMe.data?.wallets.find((wallet) => wallet.is_active) ||
      null,
    [walletsMe.data?.wallets],
  );
  const pendingCount = useMemo(
    () => items.filter((item) => item.status === "PENDING").length,
    [items],
  );
  const latestRequest = useMemo(() => items[0] || null, [items]);

  const statusLabel = (status: string): string =>
    withdrawStatusLabel(status, t);

  const requestTitle = (id: number): string =>
    t("withdraw.request_number").replace("{id}", String(id));

  const historyReasonLabel = (reason: string): string =>
    balanceHistoryReasonLabel(reason, t);

  useEffect(() => {
    if (items.length === 0) {
      setSelectedId(null);
      return;
    }
    if (!items.some((item) => item.id === selectedId)) {
      setSelectedId(items[0].id);
    }
  }, [items, selectedId]);

  async function refreshWithdrawSurface() {
    await Promise.all([
      withdrawalsQ.refetch(),
      historyQ.refetch(),
      selectedId ? detailQ.refetch() : Promise.resolve(),
      latestFinalId ? outcomeQ.refetch() : Promise.resolve(),
    ]);
  }

  async function returnToMoneyCenter(
    section: "wallet" | "history" = "history",
  ): Promise<void> {
    try {
      if (typeof window !== "undefined") {
        window.sessionStorage.setItem("EFHC_RETURN_PROFILE_SECTION", section);
      }
    } catch {
      // noop
    }
    await router.push(`/web-profile?section=${section}`);
  }

  async function createWithdraw() {
    if (!globalId) return;
    if (!walletConnected) {
      openWalletConnect();
      return;
    }
    if (!withdrawAmountOk || !withdrawMinOk) return;
    const ok = await confirm(
      "withdraw",
      t("withdraw.confirm_create_title"),
      t("withdraw.confirm_create_detail"),
    );
    if (!ok) return;
    try {
      const out = await createWithdrawMutation.mutateAsync({
        amount: format8(amount),
        idempotencyKey: newIdempotencyKey(),
      });
      toast(t("withdraw.toast_created"), "success");
      setSelectedId(out.id);
      await withdrawalsQ.refetch();
      await historyQ.refetch();
    } catch {
      // The mutation error is rendered through the safe public error helper.
    }
  }

  async function cancelWithdraw(requestId: number) {
    const ok = await confirm(
      "withdraw",
      t("withdraw.confirm_cancel_title"),
      t("withdraw.confirm_cancel_detail"),
    );
    if (!ok) return;
    try {
      const out = await cancelWithdrawMutation.mutateAsync({
        requestId,
        idempotencyKey: newIdempotencyKey(),
      });
      toast(t("withdraw.toast_canceled"), "success");
      setSelectedId(out.id);
      await withdrawalsQ.refetch();
      await historyQ.refetch();
    } catch {
      // The mutation error is rendered through the safe public error helper.
    }
  }



  return (
    <div
      className="space-y-4 efhc-withdraw-trust-shell"
      data-public-visual-trust="hub-browser-shop-withdraw-ads"
      data-public-surface="withdraw"
      data-withdraw-runtime="react-query-create-cancel-history"
    >
      <SurfaceFactsStrip
        title={t("withdraw.money_center_context")}
        description={t("withdraw.page_detail")}
        items={[
          { label: t("withdraw.available_balance"), tone: "connected" },
          {
            label: t("withdraw.wallet_status"),
            tone: walletConnected ? "connected" : "warning",
          },
          {
            label: t("withdraw.my_requests"),
            tone: pendingCount > 0 ? "warning" : "neutral",
          },
        ]}
      />
      <section
        className="efhc-withdraw-trust-rail"
        aria-label="Withdraw trust flow"
      >
        <span className={walletConnected ? "is-active" : ""}>
          {t("withdraw.wallet")}
        </span>
        <span className={withdrawAmountOk ? "is-active" : ""}>
          {t("withdraw.amount_label")}
        </span>
        <span className={pendingCount > 0 ? "is-active" : ""}>
          {t("withdraw.my_requests")}
        </span>
        <span className={latestRequest ? "is-active" : ""}>
          {t("withdraw.latest_outcome")}
        </span>
      </section>

      <section
        className="efhc-withdraw-process-preview"
        data-withdraw-process-preview="verification-decision-settlement"
      >
        <strong>{t("withdraw.timeline_process_title")}</strong>
        <WithdrawStatusTimeline status="PENDING" />
      </section>

      <Card title={t("withdraw.money_center_context")}>
        <div className="space-y-3 text-sm">
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4 efhc-withdraw-metric-grid">
            <div className="rounded-2xl border p-3 efhc-withdraw-metric-card">
              <div className="text-xs text-[color:var(--tg-hint)]">
                {t("withdraw.wallet")}
              </div>
              <div className="mt-1 flex items-center gap-2">
                <TelegramStatusBadge
                  label={
                    walletConnected
                      ? t("withdraw.connected")
                      : t("withdraw.not_connected")
                  }
                  tone={walletConnected ? "connected" : "warning"}
                />
              </div>
              <div className="mt-1 text-xs text-[color:var(--tg-hint)]">
                {primaryWallet
                  ? maskWallet(primaryWallet.wallet_address)
                  : t("withdraw.wallet_connect_detail")}
              </div>
            </div>
            <div className="rounded-2xl border p-3 efhc-withdraw-metric-card">
              <div className="text-xs text-[color:var(--tg-hint)]">
                {t("withdraw.available_balance")}
              </div>
              <div className="mt-1 text-lg font-bold tabular-nums">
                {mainBalanceHuman} EFHC
              </div>
            </div>
            <div className="rounded-2xl border p-3 efhc-withdraw-metric-card">
              <div className="text-xs text-[color:var(--tg-hint)]">
                {t("withdraw.pending_requests")}
              </div>
              <div className="mt-1 text-lg font-bold tabular-nums">
                {pendingCount}
              </div>
            </div>
            <div className="rounded-2xl border p-3 efhc-withdraw-metric-card">
              <div className="text-xs text-[color:var(--tg-hint)]">
                {t("withdraw.latest_status")}
              </div>
              <div className="mt-1 flex items-center gap-2">
                <TelegramStatusBadge
                  label={
                    latestRequest
                      ? statusLabel(latestRequest.status)
                      : t("withdraw.no_requests")
                  }
                  tone={
                    latestRequest ? statusTone(latestRequest.status) : "neutral"
                  }
                />
              </div>
              <div className="mt-1 text-xs text-[color:var(--tg-hint)]">
                {latestRequest
                  ? `${requestTitle(latestRequest.id)} · ${latestRequest.amount} EFHC`
                  : t("withdraw.first_request_hint")}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {!walletConnected ? (
              <Button variant="secondary" onClick={() => openWalletConnect()}>
                {t("withdraw.connect_wallet")}
              </Button>
            ) : null}
            <Button
              variant="secondary"
              onClick={() =>
                requestsRef.current?.scrollIntoView({
                  behavior: "smooth",
                  block: "start",
                })
              }
            >
              {t("withdraw.to_requests")}
            </Button>
            <Button
              variant="secondary"
              onClick={() =>
                historyRef.current?.scrollIntoView({
                  behavior: "smooth",
                  block: "start",
                })
              }
            >
              {t("withdraw.to_efhc_history")}
            </Button>
            <Button
              variant="secondary"
              onClick={() => void returnToMoneyCenter("history")}
            >
              {t("withdraw.return_money_center")}
            </Button>
            <Button href="/exchange" variant="secondary">
              {t("withdraw.to_exchange")}
            </Button>
          </div>
        </div>
      </Card>

      {latestOutcome || latestOutcomeLoading ? (
        <Card title={t("withdraw.latest_outcome")}>
          <div className="space-y-3 text-sm">
            {latestOutcomeLoading ? (
              <div className="text-[color:var(--tg-hint)]">
                {t("withdraw.refreshing_latest_outcome")}
              </div>
            ) : null}
            {latestOutcome ? (
              <>
                <div className="flex items-center gap-2">
                  <TelegramStatusBadge
                    label={withdrawOutcomeKindLabel(
                      latestOutcome.outcome_kind,
                      t,
                    )}
                    tone={
                      latestOutcome.outcome_kind === "success"
                        ? "connected"
                        : "warning"
                    }
                  />
                  <span className="text-xs text-[color:var(--tg-hint)]">
                    {requestTitle(latestOutcome.request_id)}
                  </span>
                </div>
                {latestOutcome.top_zone_enabled && latestOutcome.promo ? (
                  <TelegramInfoBlock
                    title={
                      latestOutcome.promo.title || t("withdraw.promo_zone")
                    }
                    description={
                      latestOutcome.promo.body || t("withdraw.promo_fallback")
                    }
                  />
                ) : null}
                <div className="rounded-2xl border p-3">
                  <div className="text-xs text-[color:var(--tg-hint)]">
                    {t("withdraw.comment")}
                  </div>
                  <div className="mt-1">{latestOutcome.comment.text}</div>
                </div>
              </>
            ) : null}
          </div>
        </Card>
      ) : null}

      <Card title={t("withdraw.title")}>
        <div className="space-y-3 text-sm">
          <div className="flex flex-wrap gap-2">
            {[
              ["all", t("withdraw.filter_all")],
              ["PENDING", t("withdraw.status_pending")],
              ["PAID", t("withdraw.status_paid")],
              ["CANCELED", t("withdraw.status_canceled")],
            ].map(([value, label]) => (
              <Button
                key={value}
                variant={statusFilter === value ? "primary" : "secondary"}
                onClick={() => {
                  setStatusFilter(value);
                }}
              >
                {label}
              </Button>
            ))}
          </div>
          <div className="text-[color:var(--tg-hint)]">
            {t("withdraw.page_detail")}
          </div>
          <div className="flex flex-wrap gap-2">
            <span className="text-xs text-[color:var(--tg-hint)]">
              {t("withdraw.filter_label")}:{" "}
              {statusFilter === "all"
                ? t("withdraw.all_statuses")
                : statusLabel(statusFilter)}
            </span>
            <Button href="/exchange" variant="secondary">
              {t("withdraw.back_to_exchange")}
            </Button>
            <Button
              variant="secondary"
              onClick={() => {
                hapticSelection(settings.haptics_enabled);
                void refreshWithdrawSurface();
              }}
            >
              {t("withdraw.refresh_requests")}
            </Button>
          </div>
        </div>
      </Card>

      <Card title={t("withdraw.create_request")}>
        <div className="space-y-3">
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="rounded-2xl border p-3">
              <div className="text-xs text-[color:var(--tg-hint)]">
                {t("withdraw.available_to_withdraw")}
              </div>
              <div className="mt-1 text-lg font-bold tabular-nums">
                {mainBalanceHuman} EFHC
              </div>
            </div>
            <div className="rounded-2xl border p-3">
              <div className="text-xs text-[color:var(--tg-hint)]">
                {t("withdraw.wallet_status")}
              </div>
              <div className="mt-1 flex items-center gap-2">
                <TelegramStatusBadge
                  label={
                    walletConnected
                      ? t("withdraw.connected")
                      : t("withdraw.not_connected")
                  }
                  tone={walletConnected ? "connected" : "warning"}
                />
                {!walletConnected ? (
                  <Button
                    variant="secondary"
                    onClick={() => openWalletConnect()}
                  >
                    {t("withdraw.connect_wallet")}
                  </Button>
                ) : null}
              </div>
            </div>
          </div>

          <div>
            <div className="text-sm text-[color:var(--tg-hint)]">
              {t("withdraw.efhc_amount")}
            </div>
            <div className="mt-2 flex items-center gap-2">
              <input
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className={
                  "w-full rounded-xl bg-[var(--tg-secondary-bg)] " +
                  "px-3 py-2 tabular-nums outline-none " +
                  "border border-[color:var(--tg-hint)]"
                }
                inputMode="decimal"
                data-withdraw-amount-input="efhcm-main-only"
              />
              <Button
                variant="secondary"
                onClick={() => {
                  hapticMedium(settings.haptics_enabled);
                  setAmount(mainBalance);
                }}
                disabled={!withdrawMinOk}
              >
                {t("withdraw.max")}
              </Button>
            </div>
          </div>

          {!withdrawMinOk ? (
            <div className="text-sm text-[color:var(--tg-hint)]">
              {t("withdraw.min_hint")}
            </div>
          ) : null}
          {!walletConnected ? (
            <div className="text-sm text-[color:var(--tg-hint)]">
              {t("withdraw.wallet_required_hint")}
            </div>
          ) : null}
          {error ? <div className="text-sm text-red-600">{error}</div> : null}

          <Button
            data-withdraw-action="create"
            onClick={() => void createWithdraw()}
            disabled={
              createBusy ||
              !walletConnected ||
              !withdrawAmountOk ||
              !withdrawMinOk
            }
          >
            {createBusy ? t("withdraw.creating") : t("withdraw.create_request")}
          </Button>
        </div>
      </Card>

      <div ref={requestsRef} className="grid gap-4 lg:grid-cols-[1.1fr,0.9fr]">
        <Card title={t("withdraw.my_requests")}>
          <div className="space-y-3">
            {loading && items.length === 0 ? (
              <EmptyState
                title={t("withdraw.loading_requests")}
                detail={t("withdraw.reading_history")}
              />
            ) : null}
            {!loading && items.length === 0 ? (
              <EmptyState
                title={t("withdraw.no_requests_yet")}
                detail={t("withdraw.create_first_request")}
              />
            ) : null}
            {items.map((item) => (
              <div
                key={item.id}
                className="rounded-2xl border p-3 space-y-2 efhc-withdraw-request-card"
                data-withdraw-request-id={item.id}
                data-withdraw-request-status={item.status}
              >
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div>
                    <div className="font-semibold">
                      {requestTitle(item.id)}
                    </div>
                    <div className="text-xs text-[color:var(--tg-hint)]">
                      {t("withdraw.created_at")}: {formatDate(item.created_at)}
                    </div>
                  </div>
                  <TelegramStatusBadge
                    label={statusLabel(item.status)}
                    tone={statusTone(item.status)}
                  />
                </div>
                <div className="text-sm tabular-nums">{item.amount} EFHC</div>
                <div className="flex flex-wrap gap-2">
                  <Button
                    variant="secondary"
                    onClick={() => setSelectedId(item.id)}
                  >
                    {t("withdraw.open_details")}
                  </Button>
                  {item.status === "PENDING" ? (
                    <Button
                      variant="secondary"
                      disabled={cancelBusyId === item.id}
                      data-withdraw-action="cancel"
                      data-withdraw-cancel-id={item.id}
                      onClick={() => void cancelWithdraw(item.id)}
                    >
                      {cancelBusyId === item.id
                        ? t("withdraw.canceling")
                        : t("common.cancel")}
                    </Button>
                  ) : null}
                </div>
              </div>
            ))}
            {cursor ? (
              <Button
                variant="secondary"
                onClick={() => void withdrawalsQ.fetchNextPage()}
              >
                {t("common.load_more")}
              </Button>
            ) : null}
          </div>
        </Card>

        <Card title={t("withdraw.request_details")}>
          <div className="space-y-3">
            {detailLoading ? (
              <EmptyState title={t("withdraw.loading_details")} />
            ) : null}
            {!detailLoading && !detail ? (
              <EmptyState
                title={t("withdraw.no_request_selected")}
                detail={t("withdraw.no_request_selected_detail")}
              />
            ) : null}
            {detailError ? (
              <div className="text-sm text-red-600">{detailError}</div>
            ) : null}
            {detail ? (
              <>
                <div className="flex items-center justify-between gap-2">
                  <div className="font-semibold">
                    {requestTitle(detail.id)}
                  </div>
                  <TelegramStatusBadge
                    label={statusLabel(detail.status)}
                    tone={statusTone(detail.status)}
                  />
                </div>
                <WithdrawStatusTimeline
                  status={detail.status}
                  holdDone={detail.hold_done}
                  refundDone={detail.refund_done}
                />
                <div className="grid gap-2 text-sm">
                  <div>
                    {t("withdraw.amount_label")}: {detail.amount} EFHC
                  </div>
                  <div>
                    {t("withdraw.created_at")}: {formatDate(detail.created_at)}
                  </div>
                  <div>
                    {t("withdraw.updated_at")}: {formatDate(detail.updated_at)}
                  </div>
                  <div>
                    {t("withdraw.hold_label")}:{" "}
                    {detail.hold_done
                      ? t("withdraw.done")
                      : t("withdraw.pending")}
                  </div>
                  <div>
                    {t("withdraw.refund_label")}:{" "}
                    {detail.refund_done
                      ? t("withdraw.done")
                      : t("withdraw.not_applied")}
                  </div>
                  <div>
                    {t("withdraw.next_step_label")}:{" "}
                    {detail.status === "PENDING"
                      ? t("withdraw.next_pending")
                      : detail.status === "CANCELED"
                        ? t("withdraw.next_canceled")
                        : detail.status === "PAID"
                          ? t("withdraw.next_paid")
                          : t("withdraw.next_watch")}
                  </div>
                </div>
                {detail.status === "PENDING" ? (
                  <Button
                    variant="secondary"
                    disabled={cancelBusyId === detail.id}
                    data-withdraw-action="cancel-detail"
                    data-withdraw-cancel-id={detail.id}
                    onClick={() => void cancelWithdraw(detail.id)}
                  >
                    {cancelBusyId === detail.id
                      ? t("withdraw.canceling")
                      : t("withdraw.cancel_request")}
                  </Button>
                ) : null}
              </>
            ) : null}
          </div>
        </Card>
      </div>

      <Card title={t("withdraw.latest_operations")}>
        <div ref={historyRef} className="space-y-3 text-sm">
          <div className="text-[color:var(--tg-hint)]">
            {t("withdraw.history_context")}
          </div>
          {historyError ? (
            <div className="text-sm text-red-600">{historyError}</div>
          ) : null}
          {historyLoading && historyItems.length === 0 ? (
            <EmptyState
              title={t("withdraw.loading_history")}
              detail={t("withdraw.reading_balance_movements")}
            />
          ) : null}
          {!historyLoading && historyItems.length === 0 ? (
            <EmptyState
              title={t("withdraw.history_empty")}
              detail={t("withdraw.history_empty_detail")}
            />
          ) : null}
          {historyItems.map((item) => {
            const balanceLabel = balanceTypeLabel(item.balance_type, t);
            const directionLabel = item.direction === "credit"
              ? t("withdraw.credit")
              : t("withdraw.debit");
            const rowLabel = [
              historyReasonLabel(item.reason),
              directionLabel,
              balanceLabel,
            ].join(" · ");
            return (
              <div
                key={item.id}
                className="rounded-2xl border p-3 space-y-1 efhc-withdraw-history-row"
                data-withdraw-history-balance-type-label="semantic"
                aria-label={rowLabel}
              >
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div className="font-semibold">
                    {historyReasonLabel(item.reason)}
                  </div>
                  <TelegramStatusBadge
                    label={directionLabel}
                    tone={
                      item.direction === "credit" ? "connected" : "warning"
                    }
                  />
                </div>
                <div
                  className="text-xs text-[color:var(--tg-hint)]"
                  data-withdraw-history-balance-type-raw-hidden="true"
                >
                  <span data-withdraw-history-balance-type="localized">
                    {balanceLabel}
                  </span>
                  <span aria-hidden="true"> · </span>
                  <span>{formatDate(item.created_at)}</span>
                </div>
                <div className="tabular-nums">{item.amount_efhc} EFHC</div>
              </div>
            );
          })}
          <Button variant="secondary" onClick={() => void historyQ.refetch()}>
            {t("withdraw.refresh_history")}
          </Button>
        </div>
      </Card>
    </div>
  );
}
