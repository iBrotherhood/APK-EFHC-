import React from "react";
import { ReferralListPage } from "../../components/referrals/ReferralListPage";

export default function ReferralsInactivePage(props: { tg_id: number | null }) {
  return <ReferralListPage parent_tg_id={props.tg_id} tab="inactive" />;
}
