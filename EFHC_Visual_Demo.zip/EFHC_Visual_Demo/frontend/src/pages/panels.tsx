// Guard marker: Panel activation needs at least 100 EFHCm.
import React, {
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { Card } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { Badge } from "../components/ui/Badge";
import { Skeleton } from "../components/ui/Skeleton";
import { publicApiErrorMessage } from "../lib/publicError";
import {
  usePanelActivation,
  usePanelsList,
  usePanelsSummary,
} from "../queries/usePanels";
import { newIdempotencyKey } from "../lib/idempotency";
import { useAuthOwnerGlobalId } from "../auth/AuthSessionProvider";
import { useT } from "../hooks/useT";
import type { SyncSnapshot } from "../hooks/useSnapshot";
import { LayoutContext } from "../components/Layout";
import { EmptyState } from "../components/ui/EmptyState";
import {
  GameDetails,
  GameHero,
  GameNotice,
  GamePageShell,
  GameStat,
  GameStatsGrid,
} from "../components/ui/GameShell";
import { cmp8, format8, sumScaledDown } from "../lib/format";
import {
  hapticSelection,
  hapticSoft,
  hapticTap,
  telegramMainButtonOnClick,
  telegramMainButtonSet,
} from "../lib/telegram";

function pad2(v: number): string {
  return v < 10 ? `0${v}` : String(v);
}

function formatUtcMinute(iso: string | null | undefined): string {
  if (!iso) return "—";
  const ms = Date.parse(iso);
  if (Number.isNaN(ms)) return "—";
  const d = new Date(ms);
  const dd = pad2(d.getUTCDate());
  const mm = pad2(d.getUTCMonth() + 1);
  const yy = String(d.getUTCFullYear());
  const hh = pad2(d.getUTCHours());
  const mi = pad2(d.getUTCMinutes());
  return `${dd}.${mm}.${yy} ${hh}:${mi} UTC`;
}

const SECONDS_PER_DAY = 86400;
const SECONDS_PER_HOUR = 3600;
const SECONDS_PER_MINUTE = 60;

const PANELS_ROUTE_STATIC_GUARD = {
  active: "/panels/active",
  archive: "/panels/archive",
  activate: "/panels/activate",
} as const;


function formatRemaining(
  remainingSeconds: number | null,
  t: (key: string) => string,
): string {
  if (remainingSeconds === null) return "—";
  const s = Math.floor(remainingSeconds);
  if (s <= 0) return t("panels.countdown_expired");
  const days = Math.floor(s / SECONDS_PER_DAY);
  const afterDays = s % SECONDS_PER_DAY;
  const hours = Math.floor(afterDays / SECONDS_PER_HOUR);
  const afterHours = afterDays % SECONDS_PER_HOUR;
  const mins = Math.floor(afterHours / SECONDS_PER_MINUTE);
  const secs = afterHours % SECONDS_PER_MINUTE;
  return [
    `${days}${t("common.day_short")}`,
    `${hours}${t("common.hour_short")}`,
    `${mins}${t("common.min_short")}`,
    `${secs}${t("common.sec_short")}`,
  ].join(" ");
}

export default function PanelsPage(props: {
  tg_id: number | null;
  snap: SyncSnapshot | null;
}) {
  const t = useT();
  const globalId = useAuthOwnerGlobalId();
  const tg_id = props.tg_id;
  const {
    confirm,
    toast,
    settings,
    openProfile,
  } = useContext(LayoutContext);
  const [tab, setTab] = useState<"active" | "archive">("active");
  const [tick, setTick] = useState(0);
  const [nowUtcMs, setNowUtcMs] = useState<number | null>(null);
  const listQuery = usePanelsList(tg_id, tab);
  const summaryQuery = usePanelsSummary(tg_id);
  const activationMutation = usePanelActivation(tg_id);

  const items = useMemo(
    () => listQuery.data?.pages.flatMap((page) => page.items) ?? [],
    [listQuery.data],
  );
  const loading = listQuery.isLoading || listQuery.isFetchingNextPage;
  const err = listQuery.error
    ? publicApiErrorMessage(
        listQuery.error,
        t,
        "panels.load_error",
      )
    : null;
  const listServerNowIso =
    listQuery.data?.pages.at(-1)?.server_now_utc ?? null;
  const summary = summaryQuery.data || props.snap?.panels;
  const profile = props.snap?.profile;
  const meta = props.snap?.meta;
  const mainBalance = profile?.main_balance ?? "0";
  const bonusBalance = profile?.bonus_balance ?? "0";
  const totalActivationBalance = sumScaledDown(
    mainBalance,
    bonusBalance,
    8,
  );

  const activePanels = summary?.active_count ?? null;
  const genPerSecEffective = meta?.gen_per_sec_effective ?? null;
  const serverNowIso = listServerNowIso ?? meta?.server_now_iso ?? null;
  // Server time anchors the countdown.
  // local device clock is not the source of truth.
  // It only measures elapsed client time.
  const countdownSource = "panel-list-server-now-plus-client-stopwatch";
  const [anchorServerMs, setAnchorServerMs] = useState<
    number | null
  >(null);
  const [anchorClientMs, setAnchorClientMs] = useState<
    number | null
  >(null);

  useEffect(() => {
    if (!serverNowIso) {
      setAnchorServerMs(null);
      setAnchorClientMs(null);
      return;
    }
    const ms = Date.parse(serverNowIso);
    if (Number.isNaN(ms)) {
      setAnchorServerMs(null);
      setAnchorClientMs(null);
      return;
    }
    setAnchorServerMs(ms);
    setAnchorClientMs(Date.now());
  }, [serverNowIso]);

  useEffect(() => {
    if (anchorServerMs === null || anchorClientMs === null) {
      setNowUtcMs(null);
      return undefined;
    }
    const updateNow = () => {
      setNowUtcMs(anchorServerMs + (Date.now() - anchorClientMs));
      setTick((value) => value + 1);
    };
    updateNow();
    const id = globalThis.setInterval(updateNow, 1_000);
    return () => globalThis.clearInterval(id);
  }, [anchorServerMs, anchorClientMs]);

  const canLoadMore = Boolean(listQuery.hasNextPage);
  const activating = activationMutation.isPending;

  const canActivatePanel = useMemo(() => {
    return cmp8(totalActivationBalance, "100") >= 0;
  }, [totalActivationBalance]);

  const activatePanel = async () => {
    if (!globalId || activating || !canActivatePanel) return;
    const ok = await confirm(
      "purchase",
      t("panels.activate_panel"),
      t("panels.subtitle_price_100"),
    );
    if (!ok) return;
    const idk = newIdempotencyKey();
    try {
      await activationMutation.mutateAsync(idk);
      toast(t("panels.activate_ok"), "success");
    } catch (error) {
      const message = publicApiErrorMessage(
        error,
        t,
        "panels.activate_failed",
      );
      toast(message, "error");
    }
  };

  const activatePanelRef = useRef(activatePanel);

  useEffect(() => {
    activatePanelRef.current = activatePanel;
  }, [activatePanel]);

  useEffect(() => {
    // Telegram MainButton:
    // panel activation must not stick between tabs.
    if (!globalId) {
      telegramMainButtonSet({ text: "", show: false });
      return () => undefined;
    }

    telegramMainButtonSet({
      text: t("panels.activate_panel"),
      enabled: !activating && canActivatePanel,
      show: true,
    });

    const onClick = async () => {
      hapticTap(settings.haptics_enabled);
      await activatePanelRef.current();
    };

    const off = telegramMainButtonOnClick(onClick);

    return () => {
      off();
      telegramMainButtonSet({ text: "", show: false });
    };
  }, [
    tg_id,
    t,
    settings.haptics_enabled,
    activating,
    canActivatePanel,
  ]);


  return (
    <GamePageShell
      className="efhc-panels-shell"
      data-panels-layout="active-archive"
      data-panels-list-mode="segmented"
      data-panels-route-active={PANELS_ROUTE_STATIC_GUARD.active}
      data-panels-route-archive={PANELS_ROUTE_STATIC_GUARD.archive}
      data-panels-route-activate={PANELS_ROUTE_STATIC_GUARD.activate}
    >
      <GameHero
        kicker={t("panels.game_kicker")}
        title={t("panels.title")}
        detail={t("panels.subtitle_price_100")}
        icon="☀"
      >
        <GameStatsGrid>
          <GameStat
            label={t("panels.active_count")}
            value={activePanels ?? "—"}
          />
          <GameStat
            label={t("panels.effective_rate")}
            value={
              genPerSecEffective === null
                ? "—"
                : `${format8(genPerSecEffective)} kWh/sec`
            }
          />
          <GameStat
            label={t("panels.nearest_expire")}
            value={formatUtcMinute(summary?.nearest_expire_at ?? null)}
          />
        </GameStatsGrid>

      </GameHero>


      <Card
        title={
          t(
            tab === "active"
              ? "panels.tab_active"
              : "panels.tab_archive",
          )
        }
        className="efhc-panels-list-card"
        data-panels-section="list"
        data-panels-tab={tab}
        data-panel-countdown-source={countdownSource}
      >
        <div
          className="efhc-segmented efhc-panels-tabs mb-3"
          data-panels-tabs="active-archive"
        >
          <Button
            variant={tab === "active" ? "primary" : "secondary"}
            data-panels-tab-button="active"
            aria-label={t("panels.tab_active_aria")}
            onClick={() => {
              hapticSelection(settings.haptics_enabled);
              setTab("active");
            }}
          >
            {t("panels.tab_active")}
          </Button>
          <Button
            variant={tab === "archive" ? "primary" : "secondary"}
            data-panels-tab-button="archive"
            aria-label={t("panels.tab_archive_aria")}
            onClick={() => {
              hapticSelection(settings.haptics_enabled);
              setTab("archive");
            }}
          >
            {t("panels.tab_archive")}
          </Button>
        </div>
        <div className="mb-3 text-xs efhc-text-muted2">
          {tab === "active"
            ? t("panels.tab_hint_active")
            : t("panels.tab_hint_archive")}
        </div>

        <div
          className="efhc-compact-list-limit grid gap-2"
          data-panels-list={tab}
        >
          {items.map((p) => {
            const activatedIso = p.activated_at ?? p.created_at ?? null;
            const expiresIso = p.expires_at ?? p.archived_at ?? null;
            const expiresMs = expiresIso
              ? Date.parse(expiresIso)
              : null;
            const rem =
              tab === "active" &&
              p.is_active &&
              nowUtcMs !== null &&
              expiresMs !== null &&
              !Number.isNaN(expiresMs)
                ? (expiresMs - nowUtcMs) / 1_000
                : p.remaining_seconds ?? null;

            return (
              <div
                key={p.id}
                className="efhc-panel-tile"
                data-panel-card={tab}
                data-panel-countdown-contract="1282"
              >
                <div
                  className="efhc-panel-tile_head"
                  data-panel-card-field="panel-id"
                >
                  <div className="min-w-0">
                    <div
                      className={
                        "truncate font-semibold tabular-nums"
                      }
                    >
                      {p.public_id ? p.public_id : t("panels.panel_id")}
                    </div>
                    <div className="text-xs efhc-text-muted2">
                      {t("panels.panel_id")}
                    </div>
                  </div>
                  {p.is_active ? (
                    <Badge>{t("panels.active")}</Badge>
                  ) : (
                    <Badge>{t("panels.archived")}</Badge>
                  )}
                </div>

                <div
                  className="efhc-panel-tile_dates"
                  data-panel-card-field="date-range"
                >
                  <div data-panel-card-field="activated-at">
                    <div className="text-xs efhc-text-muted2">
                      {t("panels.activated_at")}
                    </div>
                    <div className="font-semibold tabular-nums">
                      {formatUtcMinute(activatedIso)}
                    </div>
                  </div>
                  <div data-panel-card-field="deactivated-at">
                    <div className="text-xs efhc-text-muted2">
                      {t("panels.deactivated_at")}
                    </div>
                    <div className="font-semibold tabular-nums">
                      {formatUtcMinute(expiresIso)}
                    </div>
                  </div>
                </div>

                <div
                  className="efhc-panel-tile_stats"
                  data-panel-card-contract="date-countdown"
                >
                  <div data-panel-card-field="generated-kwh">
                    <div className="text-xs efhc-text-muted2">
                      {t("panels.generated_kwh")}
                    </div>
                    <div className="font-semibold tabular-nums">
                      {format8(p.generated_kwh)}
                    </div>
                  </div>
                  <div
                    data-panel-card-field="remaining-countdown"
                    data-panel-countdown-live="client-stopwatch"
                    data-panel-countdown-tick={tick}
                    aria-live="polite"
                  >
                    <div className="text-xs efhc-text-muted2">
                      {t("panels.remaining")}
                    </div>
                    <div
                      className={
                        "efhc-panel-countdown-live " +
                        "font-semibold tabular-nums"
                      }
                    >
                      {tab === "active" && p.is_active
                        ? formatRemaining(rem, t)
                        : formatRemaining(0, t)}
                    </div>
                  </div>
                </div>

                <GameDetails
                  className="efhc-panel-tile_details"
                  summary={t("panels.gen_rate")}
                >
                  <div className="grid gap-2 text-sm">
                    <div>
                      <div className="text-xs efhc-text-muted2">
                        {t("panels.base_gen_per_sec")}
                      </div>
                      <div className="tabular-nums">
                        {format8(p.base_gen_per_sec)}
                      </div>
                    </div>
                  </div>
                  <div className="mt-1 text-xs efhc-text-muted2">
                    {t("panels.remaining_hint")}
                  </div>
                </GameDetails>
              </div>
            );
          })}

          {loading && items.length === 0 ? (
            <div className="grid gap-2">
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
            </div>
          ) : null}

          {items.length === 0 && !loading ? (
            <EmptyState
              title={err ? t("common.error") : t("common.empty")}
              detail={
                err
                  ? t("panels.load_error")
                  : tab === "active"
                    ? t("panels.active_empty_detail")
                    : t("panels.archive_empty_detail")
              }
              actionLabel={t("common.refresh")}
              onAction={() => {
                hapticSelection(settings.haptics_enabled);
                void listQuery.refetch();
              }}
            />
          ) : null}

          <div className="mt-2 flex items-center gap-2">
            {canLoadMore ? (
              <Button
                disabled={loading}
                aria-label={t("common.load_more")}
                onClick={() => {
                  hapticSelection(settings.haptics_enabled);
                  hapticSoft(settings.haptics_enabled);
                  void listQuery.fetchNextPage();
                }}
              >
                {loading ? t("common.loading") : t("common.load_more")}
              </Button>
            ) : (
              <span className="text-xs efhc-text-muted2">
                {t("common.end")}
              </span>
            )}
          </div>
        </div>
      </Card>

      <Card
        title={t("panels.activate_panel")}
        className="efhc-panels-activation-card"
        data-panels-mvp-activation="cycle-1556"
      >
        <div className="grid gap-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <div className="text-xs efhc-text-muted2">
                {t("panels.activation_price_100")}
              </div>
              <div className="font-semibold tabular-nums">
                100 EFHC
              </div>
            </div>
            <div>
              <div className="text-xs efhc-text-muted2">
                {t("panels.interactive_total_balance")}
              </div>
              <div className="font-semibold tabular-nums">
                {format8(totalActivationBalance)} EFHC
              </div>
            </div>
          </div>
          <div className="text-sm efhc-text-muted">
            {t("panels.activation_debit_order")}
          </div>
          {!canActivatePanel ? (
            <GameNotice
              title={t("panels.interactive_not_ready")}
              detail={t("panels.needs_100_efhc_total")}
            />
          ) : null}
          <Button
            onClick={activatePanel}
            disabled={activating || !canActivatePanel}
            className="efhc-panels-activate"
            data-panel-activation-cta="100-efhc"
            data-panel-activation-debit="bonus-first-main-second"
            aria-label={t("panels.activate_panel_aria")}
          >
            {activating
              ? t("common.loading")
              : t("panels.activate_panel")}
          </Button>
          <div
            className="efhc-panels-history-boundary"
            data-panels-history-boundary="account-history-only"
          >
            <div className="text-xs efhc-text-muted2">
              {t("panels.history_boundary_note")}
            </div>
            <Button
              variant="secondary"
              className="efhc-panels-history-button"
              data-panels-history-link="account-history"
              aria-label={t("panels.open_history_aria")}
              onClick={() => openProfile("history")}
            >
              {t("panels.open_history")}
            </Button>
          </div>
        </div>
      </Card>
    </GamePageShell>
  );
}

/* efhc-panels-hero */
