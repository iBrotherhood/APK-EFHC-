import { apiRequest } from "../lib/api";
import {
  SHOPFRONT_ACCESS_KEY_PATH,
  SHOPFRONT_BOOTSTRAP_PATH,
  SHOPFRONT_CATALOG_PATH,
  SHOPFRONT_CREATE_INTENT_PATH,
  SHOPFRONT_INTENT_STATUS_PATH,
  type BrowserShopBootstrapResponse,
  type BrowserShopCatalogItem,
  type BrowserShopCreateIntentRequest,
  type BrowserShopCreateIntentResponse,
  type PaymentIntentStatusResponse,
  type ShopfrontAccessResponse,
} from "../lib/api/generated/economicUserSeams";
import {
  ensureBrowserShopCreateIntentRequest,
  parseBrowserShopBootstrapResponse,
  parseBrowserShopCatalogResponse,
  parseBrowserShopCreateIntentResponse,
  parsePaymentIntentStatusResponse,
  parseShopfrontAccessResponse,
} from "../lib/api/generated/economicUserSeamValidators";


export async function createBrowserShopAccessKey(): Promise<
  ShopfrontAccessResponse
> {
  const raw = await apiRequest<unknown>(
    SHOPFRONT_ACCESS_KEY_PATH,
    "POST",
  );
  return parseShopfrontAccessResponse(raw);
}

function tokenSuffix(token: string): string {
  return token ? `?token=${encodeURIComponent(token)}` : "";
}

export async function getBrowserShopBootstrap(
  token: string,
): Promise<BrowserShopBootstrapResponse> {
  const raw = await apiRequest<unknown>(
    `${SHOPFRONT_BOOTSTRAP_PATH}${tokenSuffix(token)}`,
    "GET",
  );
  return parseBrowserShopBootstrapResponse(raw);
}

export async function getBrowserShopCatalog(): Promise<
  BrowserShopCatalogItem[]
> {
  const raw = await apiRequest<unknown>(SHOPFRONT_CATALOG_PATH, "GET");
  return parseBrowserShopCatalogResponse(raw).items || [];
}

export async function getBrowserShopIntentStatus(args: {
  token: string;
  intentId: number;
}): Promise<PaymentIntentStatusResponse> {
  const query = new URLSearchParams({
    token: args.token,
    intent_id: String(args.intentId),
  });
  const raw = await apiRequest<unknown>(
    `${SHOPFRONT_INTENT_STATUS_PATH}?${query.toString()}`,
    "GET",
  );
  return parsePaymentIntentStatusResponse(raw);
}

export async function createBrowserShopIntent(
  request: BrowserShopCreateIntentRequest,
): Promise<BrowserShopCreateIntentResponse> {
  const body = ensureBrowserShopCreateIntentRequest(request);
  const raw = await apiRequest<unknown>(
    SHOPFRONT_CREATE_INTENT_PATH,
    "POST",
    { body },
  );
  return parseBrowserShopCreateIntentResponse(raw);
}
