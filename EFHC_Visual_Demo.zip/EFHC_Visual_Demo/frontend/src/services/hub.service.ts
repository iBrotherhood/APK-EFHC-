import { z } from "zod";

import { apiRequest } from "../lib/api";

export const HUB_EFHC_HANDOFF_PATH = "/hub/efhc-handoff" as const;

const hubEfhcHandoffSchema = z.object({
  redirect_url: z.string().url(),
  expires_at: z.string().min(1),
  transport: z.literal("external_url"),
  mode: z.literal("signed_token"),
});

export type HubEfhcHandoff = z.infer<typeof hubEfhcHandoffSchema>;

export async function createHubEfhcHandoff(): Promise<HubEfhcHandoff> {
  const raw = await apiRequest<unknown>(HUB_EFHC_HANDOFF_PATH, "POST");
  return hubEfhcHandoffSchema.parse(raw);
}
