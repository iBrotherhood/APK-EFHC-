import React, { useEffect, useState } from "react";
import { useRouter } from "next/router";
import {
  DEMO_TABLES,
  readRuntimeSettings,
  readTable,
  resetDemoDatabase,
  updateRuntimeSettings,
} from "./database";
import { type DemoFaultMode, type DemoScenario } from "./runtime";

const routes = [
  ["Энергия", "/"], ["App", "/app"], ["Панели", "/panels"],
  ["Обмен", "/exchange"], ["Задания", "/tasks"], ["Реклама", "/ads"],
  ["Рефералы", "/referrals"], ["Активные рефералы", "/referrals/active"],
  ["Неактивные рефералы", "/referrals/inactive"], ["Ранги", "/ranks"],
  ["Вывод", "/withdraw"], ["Профиль", "/web-profile"], ["Hub", "/hub"],
  ["Магазин", "/browser-shop"], ["FAQ", "/faq"],
  ["Admin", "/admin"], ["Пользователи", "/admin/users"],
  ["Банк", "/admin/bank"], ["Депозиты", "/admin/efhc-deposits"],
  ["Выводы Admin", "/admin/withdrawals"], ["Панели Admin", "/admin/panels"],
  ["Рефералы Admin", "/admin/referrals"], ["Реклама Admin", "/admin/ads"],
  ["Магазин Admin", "/admin/shop"], ["Пакеты продаж", "/admin/sale-packages"],
  ["Задания Admin", "/admin/tasks"], ["Hub Admin", "/admin/hub"],
  ["Шаблоны", "/admin/templates"], ["Отчёты", "/admin/reports"],
  ["Логи", "/admin/logs"], ["Диагностика", "/admin/diagnostics"],
  ["Система", "/admin/system"], ["404", "/404"], ["500", "/500"],
];

export function DemoControlCenter() {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [scenario, setScenario] = useState<DemoScenario>("active");
  const [fault, setFault] = useState<DemoFaultMode>("normal");
  const [counts, setCounts] = useState<Record<string, number>>({});
  const refresh = async () => {
    const settings = await readRuntimeSettings();
    setScenario(settings.scenario); setFault(settings.fault_mode);
    const entries = await Promise.all(DEMO_TABLES.map(async (table) => [table, (await readTable(table)).length] as const));
    setCounts(Object.fromEntries(entries));
  };
  useEffect(() => { if (open) void refresh(); }, [open]);
  const applyScenario = async (next: DemoScenario) => { setScenario(next); await resetDemoDatabase(next); window.location.reload(); };
  const applyFault = async (next: DemoFaultMode) => { setFault(next); await updateRuntimeSettings({ fault_mode: next }); window.location.reload(); };
  return (
    <>
      <div className="efhc-demo-ribbon">DEMO · OFFLINE · LOCAL DATA</div>
      <button className="efhc-demo-fab" onClick={() => setOpen(true)} aria-label="Открыть управление демо">DEMO</button>
      {open ? <div className="efhc-demo-overlay" onClick={() => setOpen(false)}>
        <section className="efhc-demo-panel" onClick={(event) => event.stopPropagation()}>
          <header><div><b>EFHC Demo Control Center</b><small>Локальная IndexedDB · production API отключён</small></div><button onClick={() => setOpen(false)}>×</button></header>
          <div className="efhc-demo-grid">
            <label>Сценарий<select value={scenario} onChange={(e) => void applyScenario(e.target.value as DemoScenario)}><option value="active">Активный пользователь</option><option value="vip">VIP-пользователь</option><option value="new_user">Новый пользователь</option><option value="risk">Риск и ошибки</option><option value="dense">Насыщенные таблицы</option></select></label>
            <label>Ответ backend<select value={fault} onChange={(e) => void applyFault(e.target.value as DemoFaultMode)}><option value="normal">Нормально</option><option value="slow">Медленно</option><option value="error">Ошибка API</option><option value="empty">Пустые таблицы</option></select></label>
          </div>
          <h3>Быстрый переход</h3><div className="efhc-demo-routes">{routes.map(([title, path]) => <button key={path} onClick={() => { setOpen(false); void router.push(path); }}>{title}</button>)}</div>
          <h3>Локальные таблицы</h3><div className="efhc-demo-counts">{DEMO_TABLES.map((table) => <span key={table}><b>{table}</b>{counts[table] ?? "…"}</span>)}</div>
          <footer><button onClick={() => void refresh()}>Обновить счётчики</button><button className="danger" onClick={() => void applyScenario("active")}>Полный сброс</button></footer>
        </section>
      </div> : null}
    </>
  );
}
