/**
 * Offline mirror of the immutable EFHC backend economic canon.
 * Source of truth: EFHC_Bot_v172_50/backend/app/core/system_locks.py,
 * services/panels_service.py, services/referral_service.py,
 * services/withdraw_service.py and standards/finance_rules.py.
 *
 * All EFHC and kWh arithmetic is fixed-point d8 and truncates toward zero,
 * exactly matching Python Decimal.quantize(..., ROUND_DOWN).
 */

export const EFHC_BACKEND_CANON = Object.freeze({
  sourceRelease: "EFHC_Bot_v172_50",
  decimals: 8,
  rounding: "ROUND_DOWN",
  zeroD8: "0.00000000",
  generationPerSecondBaseKwh: "0.00000692",
  generationPerSecondVipKwh: "0.00000741",
  exchangeRateKwhToEfhc: "1.00000000",
  schedulerTickSeconds: 600,
  panelPriceEfhc: "100.00000000",
  panelLifetimeDays: 180,
  maxActivePanels: 1000,
  minimumWithdrawEfhc: "10.00000000",
  referralDirectBonusEfhcb: "0.10000000",
  referralDirectBonusMaxActive: 10_000,
  referralBonusAsset: "EFHCb",
  referralLevels: [
    { level: 1, requiredActive: 10, bonusEfhcb: "1.00000000" },
    { level: 2, requiredActive: 100, bonusEfhcb: "10.00000000" },
    { level: 3, requiredActive: 1000, bonusEfhcb: "100.00000000" },
    { level: 4, requiredActive: 3000, bonusEfhcb: "300.00000000" },
    { level: 5, requiredActive: 10_000, bonusEfhcb: "1000.00000000" },
  ],
  purchaseDebitOrder: ["bonus", "main"] as const,
  withdrawBalance: "main" as const,
  reverseExchangeAllowed: false,
  p2pTransfersAllowed: false,
  automaticNftDeliveryAllowed: false,
  userNegativeBalanceAllowed: false,
  bankNegativeBalanceAllowed: true,
});

const SCALE = 100_000_000n;
export type DecimalInput = string | number | bigint | null | undefined;

function expandScientific(raw: string): string {
  const match = raw.match(/^([+-]?)(\d*\.?\d*)[eE]([+-]?\d+)$/);
  if (!match) return raw;
  const sign = match[1];
  const mantissa = match[2];
  const exponent = Number(match[3]);
  if (!Number.isInteger(exponent) || Math.abs(exponent) > 10_000) {
    throw new Error(`DEMO_DECIMAL_INVALID_EXPONENT:${raw}`);
  }
  const [whole = "0", fraction = ""] = mantissa.split(".");
  const digits = `${whole || "0"}${fraction}`.replace(/^0+(?=\d)/, "") || "0";
  const decimalIndex = (whole || "0").length + exponent;
  if (decimalIndex <= 0) return `${sign}0.${"0".repeat(-decimalIndex)}${digits}`;
  if (decimalIndex >= digits.length) return `${sign}${digits}${"0".repeat(decimalIndex - digits.length)}`;
  return `${sign}${digits.slice(0, decimalIndex)}.${digits.slice(decimalIndex)}`;
}

export function parseD8(value: DecimalInput): bigint {
  if (typeof value === "bigint") return value * SCALE;
  if (value === null || value === undefined || value === "") return 0n;
  if (typeof value === "number" && !Number.isFinite(value)) {
    throw new Error(`DEMO_DECIMAL_NOT_FINITE:${String(value)}`);
  }
  let raw = expandScientific(String(value).trim());
  const match = raw.match(/^([+-]?)(\d+)(?:\.(\d*))?$/);
  if (!match) throw new Error(`DEMO_DECIMAL_INVALID:${raw}`);
  const negative = match[1] === "-";
  const whole = BigInt(match[2]);
  const fractionRaw = match[3] || "";
  // ROUND_DOWN in Decimal means toward zero. Discard all digits after d8.
  const fraction = (fractionRaw.slice(0, 8) + "00000000").slice(0, 8);
  const units = whole * SCALE + BigInt(fraction);
  return negative ? -units : units;
}

export function formatD8(units: bigint): string {
  const negative = units < 0n;
  const absolute = negative ? -units : units;
  const whole = absolute / SCALE;
  const fraction = String(absolute % SCALE).padStart(8, "0");
  return `${negative ? "-" : ""}${whole}.${fraction}`;
}

export function d8(value: DecimalInput): string {
  return formatD8(parseD8(value));
}

export function addD8(...values: DecimalInput[]): string {
  return formatD8(values.reduce<bigint>((sum, value) => sum + parseD8(value), 0n));
}

export function subD8(left: DecimalInput, right: DecimalInput): string {
  return formatD8(parseD8(left) - parseD8(right));
}

export function multiplyD8(left: DecimalInput, right: DecimalInput): string {
  return formatD8((parseD8(left) * parseD8(right)) / SCALE);
}

export function multiplyD8ByInt(value: DecimalInput, multiplier: number | bigint): string {
  if (typeof multiplier === "number" && !Number.isSafeInteger(multiplier)) {
    throw new Error(`DEMO_INTEGER_MULTIPLIER_INVALID:${String(multiplier)}`);
  }
  return formatD8(parseD8(value) * BigInt(multiplier));
}

export function compareD8(left: DecimalInput, right: DecimalInput): number {
  const a = parseD8(left);
  const b = parseD8(right);
  return a === b ? 0 : a < b ? -1 : 1;
}

export function minD8(left: DecimalInput, right: DecimalInput): string {
  return compareD8(left, right) <= 0 ? d8(left) : d8(right);
}

export function maxD8(left: DecimalInput, right: DecimalInput): string {
  return compareD8(left, right) >= 0 ? d8(left) : d8(right);
}

export function assertNonNegativeD8(value: DecimalInput, label: string): string {
  const normalized = d8(value);
  if (compareD8(normalized, EFHC_BACKEND_CANON.zeroD8) < 0) {
    throw new Error(`DEMO_NEGATIVE_BALANCE_FORBIDDEN:${label}:${normalized}`);
  }
  return normalized;
}

export function calculateGenerationD8(deltaSeconds: number, isVip: boolean): string {
  if (!Number.isSafeInteger(deltaSeconds) || deltaSeconds <= 0) {
    return EFHC_BACKEND_CANON.zeroD8;
  }
  const rate = isVip
    ? EFHC_BACKEND_CANON.generationPerSecondVipKwh
    : EFHC_BACKEND_CANON.generationPerSecondBaseKwh;
  return multiplyD8ByInt(rate, deltaSeconds);
}

export function effectiveGenerationRateD8(activePanels: number, isVip: boolean): string {
  if (!Number.isSafeInteger(activePanels) || activePanels <= 0) {
    return EFHC_BACKEND_CANON.zeroD8;
  }
  const rate = isVip
    ? EFHC_BACKEND_CANON.generationPerSecondVipKwh
    : EFHC_BACKEND_CANON.generationPerSecondBaseKwh;
  return multiplyD8ByInt(rate, activePanels);
}

export function exchangeKwhToEfhcD8(amountKwh: DecimalInput): string {
  const amount = assertNonNegativeD8(amountKwh, "exchange_kwh");
  return multiplyD8(amount, EFHC_BACKEND_CANON.exchangeRateKwhToEfhc);
}

export function splitBonusThenMainD8(input: {
  bonusBalance: DecimalInput;
  mainBalance: DecimalInput;
  amount: DecimalInput;
}): {
  bonusPart: string;
  mainPart: string;
  bonusAfter: string;
  mainAfter: string;
} {
  const bonus = assertNonNegativeD8(input.bonusBalance, "bonus_balance");
  const main = assertNonNegativeD8(input.mainBalance, "main_balance");
  const amount = d8(input.amount);
  if (compareD8(amount, EFHC_BACKEND_CANON.zeroD8) <= 0) {
    throw new Error("DEMO_AMOUNT_MUST_BE_POSITIVE");
  }
  if (compareD8(addD8(bonus, main), amount) < 0) {
    throw new Error("DEMO_INSUFFICIENT_BONUS_PLUS_MAIN");
  }
  const bonusPart = minD8(bonus, amount);
  const mainPart = subD8(amount, bonusPart);
  return {
    bonusPart,
    mainPart,
    bonusAfter: assertNonNegativeD8(subD8(bonus, bonusPart), "bonus_after"),
    mainAfter: assertNonNegativeD8(subD8(main, mainPart), "main_after"),
  };
}

export function nextSchedulerEtaSeconds(epochSeconds: number): number {
  if (!Number.isSafeInteger(epochSeconds) || epochSeconds < 0) return 0;
  const remainder = epochSeconds % EFHC_BACKEND_CANON.schedulerTickSeconds;
  return remainder === 0 ? 0 : EFHC_BACKEND_CANON.schedulerTickSeconds - remainder;
}

export function referralLevelForActive(activeReferrals: number): number {
  let level = 0;
  for (const step of EFHC_BACKEND_CANON.referralLevels) {
    if (activeReferrals >= step.requiredActive) level = step.level;
  }
  return level;
}

export function referralLevelSteps() {
  let cumulativeLevelBonus: string = EFHC_BACKEND_CANON.zeroD8;
  return EFHC_BACKEND_CANON.referralLevels.map((step) => {
    cumulativeLevelBonus = addD8(cumulativeLevelBonus, step.bonusEfhcb);
    const directBonusTotal = multiplyD8ByInt(
      EFHC_BACKEND_CANON.referralDirectBonusEfhcb,
      step.requiredActive,
    );
    return {
      level: step.level,
      required_active: step.requiredActive,
      level_bonus: step.bonusEfhcb,
      direct_bonus_total: directBonusTotal,
      cumulative_level_bonus: cumulativeLevelBonus,
      cumulative_total_reward: addD8(directBonusTotal, cumulativeLevelBonus),
    };
  });
}
