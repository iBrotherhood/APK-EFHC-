export const SIMULATOR_MODE =
  process.env.NEXT_PUBLIC_EFHC_RUNTIME_MODE === "offline_simulator";

export const DEMO_TG_ID = 777000001;
export const DEMO_GLOBAL_ID = "0000000001";
export const DEMO_USERNAME = "Master Demo";
export const DEMO_SEED = "EFHC-DEMO-SEED-001";

export type DemoScenario =
  | "active"
  | "vip"
  | "new_user"
  | "risk"
  | "dense";

export type DemoFaultMode = "normal" | "slow" | "error" | "empty";

export function isSimulatorRuntime(): boolean {
  return SIMULATOR_MODE;
}
