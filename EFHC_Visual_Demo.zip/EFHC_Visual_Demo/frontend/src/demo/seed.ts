import {
  DEMO_GLOBAL_ID,
  DEMO_SEED,
  DEMO_TG_ID,
  DEMO_USERNAME,
  type DemoScenario,
} from "./runtime";

export type DemoRow = Record<string, unknown> & { id: string | number };
export type DemoSeed = Record<string, DemoRow[]>;

function iso(daysAgo: number, hour = 12): string {
  const base = new Date("2026-08-02T07:00:00.000Z");
  base.setUTCDate(base.getUTCDate() - daysAgo);
  base.setUTCHours(hour, 0, 0, 0);
  return base.toISOString();
}

function userRows(count: number): DemoRow[] {
  const names = [
    "Master", "SolarFox", "GreenPulse", "EnergyNomad", "AvatarOne",
    "EcoPilot", "VoltRiver", "SunKeeper", "WattHero", "NovaGrid",
    "WindCode", "TerraLight", "PowerSeed", "KwhMaker", "EfhcCitizen",
  ];
  return Array.from({ length: count }, (_, index) => ({
    id: index + 1,
    global_id: String(index + 1).padStart(10, "0"),
    tg_id: DEMO_TG_ID + index,
    username: index === 0 ? DEMO_USERNAME : `${names[index % names.length]}${index + 1}`,
    is_vip: index % 7 === 0,
    is_active: index % 9 !== 0,
    main_balance: (1250 + index * 73.25).toFixed(8),
    bonus_balance: (85 + index * 4.5).toFixed(8),
    available_kwh: (340 + index * 17.125).toFixed(8),
    total_generated_kwh: (2100 + index * 289.75).toFixed(8),
    gen_per_sec_base: (0.0025 + (index % 5) * 0.0004).toFixed(8),
    gen_per_sec_vip: (index % 7 === 0 ? 0.00125 : 0).toFixed(8),
    ton_wallet: index % 3 === 0 ? `EQD_demo_user_wallet_${String(index + 1).padStart(8, "0")}` : null,
    last_seen_at: iso(index % 12, 7 + (index % 12)),
    created_at: iso(90 - Math.min(index, 80)),
    updated_at: iso(index % 6),
  }));
}

function panelRows(count: number): DemoRow[] {
  return Array.from({ length: count }, (_, index) => {
    const active = index % 6 !== 5;
    return {
      id: index + 1,
      public_id: `PNL-${String(index + 1).padStart(6, "0")}`,
      user_tg_id: DEMO_TG_ID + (index % 12),
      activated_at: iso(30 - (index % 25), 9),
      created_at: iso(31 - (index % 25), 8),
      expires_at: active ? iso(-60 - (index % 30), 9) : iso(2 + (index % 8), 9),
      archived_at: active ? null : iso(index % 4, 10),
      remaining_seconds: active ? 5_184_000 - index * 3_600 : 0,
      base_gen_per_sec: (0.0005 + (index % 5) * 0.0001).toFixed(8),
      generated_kwh: (55 + index * 13.875).toFixed(8),
      is_active: active,
    };
  });
}

function transactionRows(count: number): DemoRow[] {
  const reasons = [
    "panel_generation", "exchange_kwh_to_efhc", "task_reward",
    "referral_bonus", "efhc_external_deposit", "shop_purchase",
  ];
  return Array.from({ length: count }, (_, index) => ({
    id: index + 1,
    tg_id: DEMO_TG_ID + (index % 8),
    amount_efhc: (5 + (index % 17) * 2.25).toFixed(8),
    direction: index % 6 === 5 ? "debit" : "credit",
    balance_type: index % 4 === 2 ? "bonus" : "main",
    reason: reasons[index % reasons.length],
    created_at: iso(index % 45, 7 + (index % 12)),
  }));
}

function referralRows(count: number): DemoRow[] {
  return Array.from({ length: count }, (_, index) => ({
    id: index + 1,
    inviter_tg_id: DEMO_TG_ID,
    child_tg_id: DEMO_TG_ID + index + 10,
    tg_id: DEMO_TG_ID + index + 10,
    username: `GreenPartner${index + 1}`,
    joined_at: iso(40 - (index % 35)),
    invited_at: iso(42 - (index % 35)),
    activated_at: index % 4 === 0 ? null : iso(38 - (index % 35)),
    is_active: index % 4 !== 0,
    total_generated_kwh: (20 + index * 44.125).toFixed(8),
    panels_count: index % 4,
  }));
}

export function buildDemoSeed(scenario: DemoScenario = "active"): DemoSeed {
  const dense = scenario === "dense";
  const isNew = scenario === "new_user";
  const vip = scenario === "vip";
  const risk = scenario === "risk";
  const users = userRows(dense ? 120 : 24);
  const owner = users[0];
  Object.assign(owner, {
    global_id: DEMO_GLOBAL_ID,
    tg_id: DEMO_TG_ID,
    username: DEMO_USERNAME,
    is_vip: vip,
    is_active: true,
    main_balance: isNew ? "0.00000000" : vip ? "12850.50000000" : "1250.75000000",
    bonus_balance: isNew ? "0.00000000" : "185.25000000",
    available_kwh: isNew ? "0.00000000" : "640.87500000",
    total_generated_kwh: isNew ? "0.00000000" : vip ? "15450.12500000" : "4250.12500000",
    gen_per_sec_base: isNew ? "0.00000000" : "0.00350000",
    gen_per_sec_vip: vip ? "0.00175000" : "0.00000000",
  });

  const panels = isNew ? [] : panelRows(dense ? 80 : vip ? 16 : 9);
  const transactions = isNew ? [] : transactionRows(dense ? 180 : 35);
  const referrals = isNew ? [] : referralRows(dense ? 140 : 18);
  const tasks: DemoRow[] = [
    { id: 1, code: "daily_energy", title: "Собрать энергию", description: "Откройте энергетическую панель", bonus_efhc: "2.00000000", is_active: true, kind: "daily", meta: {}, created_at: iso(90), updated_at: iso(1) },
    { id: 2, code: "watch_ad", title: "Просмотреть энерго-рекламу", description: "Демо-таймер 5 секунд", bonus_efhc: "5.00000000", is_active: true, kind: "ad", meta: {}, created_at: iso(80), updated_at: iso(2) },
    { id: 3, code: "invite_friend", title: "Пригласить участника", description: "Пригласите нового пользователя", bonus_efhc: "10.00000000", is_active: true, kind: "referral", meta: {}, created_at: iso(70), updated_at: iso(3) },
    { id: 4, code: "connect_wallet", title: "Подключить TON-кошелёк", description: "В симуляторе операция локальная", bonus_efhc: "3.00000000", is_active: true, kind: "wallet", meta: {}, created_at: iso(60), updated_at: iso(4) },
    { id: 5, code: "exchange_energy", title: "Обменять энергию", description: "Обменяйте kWh на EFHC", bonus_efhc: "7.50000000", is_active: true, kind: "exchange", meta: {}, created_at: iso(50), updated_at: iso(5) },
  ];
  const userTasks: DemoRow[] = tasks.map((task, index) => ({
    id: index + 1,
    task_id: task.id,
    tg_id: DEMO_TG_ID,
    status: index === 0 ? "APPROVED" : index === 1 ? "PENDING" : index === 2 ? "REJECTED" : "PENDING",
    progress: { current: index === 0 ? 1 : 0, target: 1 },
    bonus_efhc: task.bonus_efhc,
    can_claim: index !== 0,
    next_available_at: null,
    proof_text: index % 2 === 0 ? `Демо-подтверждение по заданию ${task.id}` : null,
    proof_url: index % 2 === 1 ? `/assets/efhc/responsive/efhc_coin_128.avif` : null,
    submitted_at: iso(8 - index, 10 + index),
    reviewed_at: index === 0 || index === 2 ? iso(7 - index, 12 + index) : null,
    moderator_tg_id: index === 0 || index === 2 ? DEMO_TG_ID : null,
    moderator_note: index === 0 ? "Проверено в демо-режиме" : index === 2 ? "Недостаточно подтверждения" : null,
  }));
  const wallets: DemoRow[] = isNew ? [] : [
    { id: 1, tg_id: DEMO_TG_ID, wallet_address: "EQD_demo_primary_wallet_0000000000000001", wallet_app: "Tonkeeper", is_primary: true, is_active: true, created_at: iso(28) },
    { id: 2, tg_id: DEMO_TG_ID, wallet_address: "UQD_demo_secondary_wallet_00000000000002", wallet_app: "MyTonWallet", is_primary: false, is_active: true, created_at: iso(15) },
  ];
  const withdrawals: DemoRow[] = isNew ? [] : Array.from({ length: dense ? 80 : 12 }, (_, index) => ({
    id: index + 1,
    tg_id: DEMO_TG_ID + (index % 5),
    amount: (25 + index * 7.5).toFixed(8),
    amount_efhc: (25 + index * 7.5).toFixed(8),
    status: risk && index === 0 ? "failed" : ["pending", "approved", "rejected", "paid"][index % 4],
    external_address: `EQD_demo_payout_${String(index + 1).padStart(8, "0")}`,
    tx_hash: index % 4 === 3 ? `demo_tx_${String(index + 1).padStart(6, "0")}` : null,
    created_at: iso(index + 1),
    updated_at: iso(index),
    processed_at: index % 4 === 0 ? null : iso(index),
    error_message: risk && index === 0 ? "DEMO_PROVIDER_TIMEOUT" : null,
    idempotency_key: `demo-withdraw-${index + 1}`,
    hold_done: true,
    refund_done: index % 4 === 2,
    payout_ref: index % 4 === 3 ? `PAYOUT-${index + 1}` : null,
    is_vip: index % 3 === 0,
    payout_asset: "EFHC",
    tonconnect_transport_kind: "jetton_transfer",
    jetton_master_address: "EQD_EFHC_DEMO_JETTON_MASTER",
    jetton_decimals: 8,
    fee_message_ton_amount: "0.050000000",
  }));
  const shopItems: DemoRow[] = [
    { id: 1, sku: "panel_starter", code: "panel_starter", title: "Стартовая солнечная панель", description: "Базовая панель генерации", item_type: "EFHC_PACKAGE", quantity_efhc: "100.00000000", price_efhc: "100.00000000", price_ton: "1.25000000", price_usdt: null, pay_currencies: ["TON"], image_url: null, status: "live", active: true, ton_enabled: true, usdt_enabled: false, is_active: true, created_at: iso(120), updated_at: iso(1), history_count: 2, history_tail: [], methods: { EFHC: { price: "100.00000000" }, TON: { price: "1.25000000" } } },
    { id: 2, sku: "panel_pro", code: "panel_pro", title: "Панель Pro", description: "Усиленная генерация", item_type: "EFHC_PACKAGE", quantity_efhc: "500.00000000", price_efhc: "500.00000000", price_ton: "5.75000000", price_usdt: "25.00000000", pay_currencies: ["TON", "USDT"], image_url: null, status: "live", active: true, ton_enabled: true, usdt_enabled: true, is_active: true, created_at: iso(110), updated_at: iso(2), history_count: 3, history_tail: [], methods: { EFHC: { price: "500.00000000" }, TON: { price: "5.75000000" }, USDT: { price: "25.00000000" } } },
    { id: 3, sku: "vip_30", code: "vip_30", title: "VIP на 30 дней", description: "Повышенная генерация и статус", item_type: "VIP", quantity_efhc: null, price_efhc: "250.00000000", price_ton: "2.75000000", price_usdt: null, pay_currencies: ["TON"], image_url: null, status: "live", active: true, ton_enabled: true, usdt_enabled: false, is_active: true, created_at: iso(100), updated_at: iso(3), history_count: 1, history_tail: [], methods: { EFHC: { price: "250.00000000" }, TON: { price: "2.75000000" } } },
    { id: 4, sku: "skin_gold", code: "skin_gold", title: "Золотой энергетический скин", description: "Визуальное оформление", item_type: "SKIN", quantity_efhc: null, price_efhc: "75.00000000", price_ton: null, price_usdt: null, pay_currencies: [], image_url: null, status: "draft", active: false, ton_enabled: false, usdt_enabled: false, is_active: false, created_at: iso(90), updated_at: iso(4), history_count: 1, history_tail: [], methods: { EFHC: { price: "75.00000000" } } },
  ];
  const shopOrders: DemoRow[] = isNew ? [] : Array.from({ length: dense ? 70 : 8 }, (_, index) => ({
    id: index + 1,
    type: "shop",
    sku: shopItems[index % shopItems.length].sku,
    quantity: 1 + (index % 2),
    status: ["created", "paid", "fulfilled", "failed"][index % 4],
    user_tg_id: DEMO_TG_ID + (index % 4),
    tx_hash: index % 4 > 0 ? `shop_demo_tx_${index + 1}` : null,
    debited_bonus_efhc: index % 2 ? "25.00000000" : "0.00000000",
    debited__main__efhc: index % 2 ? "75.00000000" : "100.00000000",
    idempotency_key: `shop-order-${index + 1}`,
    created_at: iso(index + 2),
    updated_at: iso(index + 1),
  }));
  const hubLinks: DemoRow[] = [
    { id: 1, code: "energy", title: "Energy", subtitle: "Главная энергетическая панель", url: "/", target_kind: "internal", open_mode: "same", sort_order: 1, is_active: true, icon_key: "energy", created_at: iso(100), updated_at: iso(1) },
    { id: 2, code: "shop", title: "EFHC Shop", subtitle: "Панели, VIP и скины", url: "/browser-shop", target_kind: "internal", open_mode: "same", sort_order: 2, is_active: true, icon_key: "shop", created_at: iso(100), updated_at: iso(1) },
    { id: 3, code: "federation", title: "Federation of Avatars", subtitle: "Экосистема проекта", url: "https://example.invalid", target_kind: "external", open_mode: "external", sort_order: 3, is_active: true, icon_key: "hub", created_at: iso(100), updated_at: iso(1) },
  ];
  const adminEvents: DemoRow[] = Array.from({ length: dense ? 120 : 24 }, (_, index) => ({
    id: `event-${index + 1}`,
    type: ["user", "panel", "withdrawal", "deposit", "security"][index % 5],
    severity: ["info", "success", "warning", "danger"][index % 4],
    title: ["Пользователь создан", "Панель активирована", "Вывод обработан", "Депозит подтверждён", "Проверка безопасности"][index % 5],
    description: `Демонстрационное системное событие ${index + 1}`,
    ts: iso(index % 30, 6 + (index % 15)),
    route: "/admin/logs",
    source: "local_demo_engine",
  }));
  const skins: DemoRow[] = Array.from({ length: 6 }, (_, index) => ({
    id: index + 1,
    skin_id: index + 1,
    title: ["Eco Initiate", "Solar Rise", "Green Grid", "Golden Current", "Avatar Energy", "Humanity Light"][index],
    price_efhc: (index * 50).toFixed(8),
    asset_path: `/skins/${Math.min(index + 1, 1)}.webp`,
    purchased_at: index < 3 ? iso(20 - index) : null,
    is_unlocked: index < 4,
    is_active: index === 1,
  }));
  const settings: DemoRow[] = [
    { id: "runtime", scenario, fault_mode: "normal", seed: DEMO_SEED, revision: 1 },
  ];
  const templates: DemoRow[] = [
    { id: "withdraw_approved", key: "withdraw_approved", locale: "ru", text: "Ваша заявка на вывод одобрена.", updated_at: iso(1) },
    { id: "withdraw_rejected", key: "withdraw_rejected", locale: "ru", text: "Заявка отклонена. Проверьте данные кошелька.", updated_at: iso(2) },
  ];
  return {
    settings, users, panels, transactions, tasks, user_tasks: userTasks,
    referrals, wallets, withdrawals, shop_items: shopItems,
    shop_orders: shopOrders, hub_links: hubLinks, admin_events: adminEvents,
    skins, templates,
  };
}
