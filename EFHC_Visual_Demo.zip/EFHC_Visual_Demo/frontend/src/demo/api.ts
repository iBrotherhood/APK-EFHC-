import type { ApiRequestOptions, HttpMethod } from "../lib/api";
import {
  deleteRow,
  getRow,
  putRow,
  readRuntimeSettings,
  readTable,
} from "./database";
import { DEMO_GLOBAL_ID, DEMO_TG_ID, DEMO_USERNAME } from "./runtime";

type Row = Record<string, any> & { id: string | number };
const d8 = (value: unknown) => Number(value || 0).toFixed(8);
const now = () => new Date().toISOString();
const clean = (path: string) => path.split("?", 1)[0].replace(/^\/api(?=\/)/, "").replace(/\/$/, "") || "/";
const query = (path: string) => new URL(path, "https://demo.local").searchParams;


function emptyDemoResponse(path: string): unknown {
  if (["/auth/session", "/auth/logout", "/auth/telegram/session", "/auth/ton/proof"].includes(path)) {
    return { global_id: DEMO_GLOBAL_ID, tg_id: DEMO_TG_ID, provider: "offline_simulator", roles: ["user", "admin"] };
  }
  if (path === "/health") return { ok: true, status: "ok" };
  if (path === "/health/db") return { ok: true, db: { ok: true }, schema: { ok: true, status: "ok", missing: [] } };
  if (path === "/health/runtime") return { ok: true, backend: { ok: true }, db: { ok: true }, watcher: { ok: true, status: "offline_ready" } };
  if (path === "/admin/shop/items" || path === "/admin/withdrawals") return [];
  if (path === "/admin/panels") return { ok: true, items: [] };
  if (path === "/admin/bank/balance") return { ok: true, balance: "0.00000000", currency: "EFHC", updated_at: now() };
  if (path === "/admin/logs/transfers") return { ok: true, items: [], next_cursor: null };
  if (path === "/admin/ads/providers") return { ok: true, items: [] };
  if (path.startsWith("/admin/reports/")) return { ok: true, ts: now(), counters: {}, facts: {}, notes: "Пустой демо-сценарий" };
  if (path === "/sync/me") return {
    profile: {
      global_id: DEMO_GLOBAL_ID,
      tg_id: DEMO_TG_ID,
      username: DEMO_USERNAME,
      main_balance: "0.00000000",
      bonus_balance: "0.00000000",
      available_kwh: "0.00000000",
      total_generated_kwh: "0.00000000",
      gen_per_sec_base: "0.00000000",
      gen_per_sec_vip: "0.00000000",
      is_vip: false,
      has_activ: false,
    },
    panels: { active_count: 0, total_generated_by_panels: "0.00000000", nearest_expire_at: null },
    exchange_preview: { ok: true, available_kwh: "0.00000000", max_exchangeable_kwh: "0.00000000", rate_kwh_to_efhc: "1.00000000", detail: "EMPTY_DEMO" },
    meta: { server_now_iso: now(), gen_per_sec_effective: "0.00000000", next_scheduler_eta_sec: 15, fallback_task_id: null },
  };
  if (path === "/wallets/me") return { is_connected: false, wallets: [] };
  if (path === "/shopfront/catalog") return { items: [] };
  if (path === "/shopfront/bootstrap") return { mode: "offline_empty", tg_linked: true, tg_id: DEMO_TG_ID, wallet_linked: false, wallets: [], available_modules: [] };
  if (path === "/referrals/stats/me") return { bonus_balance: "0.00000000", referrals_bonus_total: "0.00000000", total_referrals: 0, active_referrals: 0, inactive_referrals: 0, level: 0, progress: 0, level_steps: [], referral_code: "EFHC-DEMO-EMPTY", referral_link: "" };
  if (path.startsWith("/ranks/")) return path.includes("my-plus-top") ? { snapshot_at: now(), me: null, top: [], next_cursor: null } : { snapshot_at: now(), items: [], next_cursor: null };
  if (path === "/exchange/preview") return { ok: true, available_kwh: "0.00000000", max_exchangeable_kwh: "0.00000000", rate_kwh_to_efhc: "1.00000000", detail: "EMPTY_DEMO" };
  if (path === "/user/me/panels-summary") return { active_count: 0, total_generated_by_panels: "0.00000000", nearest_expire_at: null };
  return { items: [], next_cursor: null, ok: true };
}

async function delayForFault(): Promise<void> {
  const settings = await readRuntimeSettings();
  if (settings.fault_mode === "slow") await new Promise((resolve) => setTimeout(resolve, 900));
  if (settings.fault_mode === "error") throw new Error("DEMO_SIMULATED_BACKEND_ERROR");
}

async function owner(): Promise<Row> {
  const users = await readTable("users");
  const found = users.find((item) => Number(item.tg_id) === DEMO_TG_ID);
  if (!found) throw new Error("DEMO_OWNER_NOT_FOUND");
  return found;
}

async function ownerPanels(): Promise<Row[]> {
  const rows = await readTable("panels");
  return rows.filter((item) => Number(item.user_tg_id) === DEMO_TG_ID);
}

function paginate(rows: Row[], path: string, limitDefault = 100) {
  const params = query(path);
  const limit = Math.max(1, Math.min(200, Number(params.get("limit") || limitDefault)));
  const offset = Math.max(0, Number(params.get("cursor") || 0));
  const items = rows.slice(offset, offset + limit);
  const next = offset + limit < rows.length ? String(offset + limit) : null;
  return { items, next_cursor: next };
}

async function snapshot() {
  const profile = await owner();
  const panels = await ownerPanels();
  const active = panels.filter((item) => item.is_active);
  const totalPanels = active.reduce((sum, item) => sum + Number(item.generated_kwh || 0), 0);
  const rate = Number(profile.gen_per_sec_base || 0) + Number(profile.gen_per_sec_vip || 0);
  return {
    profile: {
      ...profile,
      global_id: DEMO_GLOBAL_ID,
      tg_id: DEMO_TG_ID,
      username: profile.username || DEMO_USERNAME,
      has_activ: active.length > 0,
      lifetime_generated_kwh: profile.total_generated_kwh,
    },
    panels: {
      active_count: active.length,
      total_generated_by_panels: d8(totalPanels),
      nearest_expire_at: active.map((item) => item.expires_at).filter(Boolean).sort()[0] || null,
    },
    exchange_preview: {
      ok: true,
      available_kwh: d8(profile.available_kwh),
      max_exchangeable_kwh: d8(profile.available_kwh),
      rate_kwh_to_efhc: "1.00000000",
      detail: "EFHC offline simulator",
    },
    meta: {
      server_now_iso: now(),
      gen_per_sec_effective: d8(rate),
      next_scheduler_eta_sec: 15,
      fallback_task_id: null,
    },
  };
}

async function report(domain: string) {
  const users = await readTable("users");
  const panels = await readTable("panels");
  const withdrawals = await readTable("withdrawals");
  const transactions = await readTable("transactions");
  const bankRow = await getRow("settings", "bank");
  const bankBalance = d8(bankRow?.balance ?? 250000);
  const usersMain = d8(users.reduce((sum, row) => sum + Number(row.main_balance || 0), 0));
  const usersBonus = d8(users.reduce((sum, row) => sum + Number(row.bonus_balance || 0), 0));
  const usersTotal = d8(Number(usersMain) + Number(usersBonus));
  const activePanels = panels.filter((row) => Boolean(row.is_active));
  const archivedPanels = panels.filter((row) => !row.is_active);
  const generated = d8(users.reduce((sum, row) => sum + Number(row.total_generated_kwh || 0), 0));
  const exchanged = d8(transactions.filter((row) => row.reason === "exchange_kwh_to_efhc").reduce((sum, row) => sum + Number(row.amount_efhc || 0), 0));
  const panelPaid = d8(panels.length * 100);
  const facts: Record<string, string> = {
    users_total__main__efhc: usersMain,
    users_total_bonus_efhc: usersBonus,
    users_total_efhc: usersTotal,
    users_total_generated_kwh: generated,
    users_total_exchanged_kwh: exchanged,
    panels_total_active: String(activePanels.length),
    panels_total_archived: String(archivedPanels.length),
    panels_total_bought: String(panels.length),
    panels_total_paid_efhc: panelPaid,
    panels_total_paid__main__efhc: d8(Number(panelPaid) * 0.8),
    panels_total_paid_bonus_efhc: d8(Number(panelPaid) * 0.2),
    bank_balance_efhc: bankBalance,
    bank_users_balance_diff_efhc: d8(Number(bankBalance) - Number(usersTotal)),
    bank_users_balance_match: Number(bankBalance) >= Number(usersTotal) ? "OK" : "ATTENTION",
  };
  const counters: Record<string, number> = {
    users_total: users.length,
    users_active: users.filter((row) => Boolean(row.is_active)).length,
    users_vip: users.filter((row) => Boolean(row.is_vip)).length,
    panels_total: panels.length,
    panels_active: activePanels.length,
    panels_archived: archivedPanels.length,
    withdrawals_total: withdrawals.length,
    withdrawals_pending: withdrawals.filter((row) => row.status === "pending").length,
    transfers_total: transactions.length,
  };
  const snapshotMap: Record<string, Record<string, number | string>> = {
    overview: { users: users.length, active_panels: activePanels.length, pending_withdrawals: counters.withdrawals_pending, efhc_bank: bankBalance },
    users: { total: users.length, active: counters.users_active, vip: counters.users_vip },
    panels: { total: panels.length, active: activePanels.length, archived: archivedPanels.length, generated_kwh: generated },
    withdrawals: { total: withdrawals.length, pending: counters.withdrawals_pending, approved: withdrawals.filter((row) => row.status === "approved").length, paid: withdrawals.filter((row) => row.status === "paid").length },
    deposits: { total: transactions.filter((row) => row.reason === "efhc_external_deposit").length, confirmed: 15, pending: 2, failed: 1 },
    bank: { balance: bankBalance, transfers: transactions.length },
  };
  return {
    ok: true,
    ts: now(),
    counters,
    facts,
    notes: "Локальный детерминированный snapshot EFHC Offline Simulator",
    data_kind: "local_demo_snapshot",
    synthetic: true,
    domain,
    range_hours: 168,
    generated_at: now(),
    snapshot: snapshotMap[domain] || snapshotMap.overview,
    trend: Array.from({ length: 14 }, (_, index) => ({ bucket: new Date(Date.now() - (13 - index) * 86400000).toISOString(), value: 40 + index * 7 + (index % 3) * 5 })),
    empty_reason: null,
  };
}

async function adminUsers(path: string): Promise<{ items: Row[]; next_cursor: null; total: number }> {
  const rows = await readTable("users");
  const wallets = await readTable("wallets");
  const q = (query(path).get("q") || "").toLowerCase();
  const items = rows
    .filter((row) => !q || String(row.username || "").toLowerCase().includes(q) || String(row.tg_id).includes(q) || String(row.global_id).includes(q))
    .map((row) => ({
      ...row,
      ton_wallet: wallets.find((wallet) => Number(wallet.tg_id) === Number(row.tg_id) && wallet.is_primary)?.wallet_address || row.ton_wallet || null,
      last_seen_at: row.last_seen_at || row.updated_at || row.created_at,
      updated_at: row.updated_at || row.created_at || now(),
    }));
  return { items, next_cursor: null, total: items.length };
}

async function nextId(table: Parameters<typeof readTable>[0]): Promise<number> {
  const rows = await readTable(table);
  return Math.max(0, ...rows.map((row) => Number(row.id) || 0)) + 1;
}

async function addTransaction(input: Record<string, unknown>): Promise<Row> {
  const row: Row = {
    id: await nextId("transactions"),
    tg_id: Number(input.tg_id ?? DEMO_TG_ID),
    amount_efhc: d8(input.amount_efhc ?? input.amount ?? 0),
    amount: d8(input.amount ?? input.amount_efhc ?? 0),
    direction: String(input.direction ?? "user_credit"),
    balance_type: String(input.balance_type ?? "main"),
    reason: String(input.reason ?? "demo_operation"),
    idempotency_key: String(input.idempotency_key ?? `demo-${Date.now()}`),
    created_at: String(input.created_at ?? now()),
  };
  await putRow("transactions", row);
  return row;
}

async function readBankBalance(): Promise<number> {
  const row = await getRow("settings", "bank");
  return Number(row?.balance ?? 250000);
}

async function writeBankBalance(balance: number): Promise<void> {
  await putRow("settings", { id: "bank", balance: d8(balance), updated_at: now() });
}

function mapPanel(row: Row): Row {
  return { ...row, tg_id: Number(row.tg_id ?? row.user_tg_id), user_tg_id: Number(row.user_tg_id ?? row.tg_id) };
}

function mapTransfer(row: Row) {
  const rawDirection = String(row.direction || "credit");
  const direction = rawDirection.startsWith("user_") || rawDirection.startsWith("bank_")
    ? rawDirection
    : rawDirection === "debit" ? "user_debit" : "user_credit";
  return {
    id: Number(row.id),
    tg_id: Number(row.tg_id || DEMO_TG_ID),
    amount: d8(row.amount ?? row.amount_efhc),
    amount_efhc: d8(row.amount_efhc ?? row.amount),
    direction,
    balance_type: String(row.balance_type || "main"),
    reason: String(row.reason || "demo_operation"),
    idempotency_key: String(row.idempotency_key || `demo-${row.id}`),
    created_at: String(row.created_at || now()),
  };
}

async function adminWithdrawals(path: string) {
  let rows = await readTable("withdrawals");
  const status = query(path).get("status") || query(path).get("status_filter");
  if (status && status !== "all") rows = rows.filter((row) => row.status === status);
  return rows.map((row) => ({
    id: Number(row.id), tg_id: Number(row.tg_id), amount_efhc: d8(row.amount_efhc || row.amount), status: String(row.status),
    external_address: row.external_address || null, tx_hash: row.tx_hash || null, created_at: String(row.created_at),
    processed_at: row.processed_at || null, error_message: row.error_message || null, is_vip: Boolean(row.is_vip),
    payout_asset: String(row.payout_asset || "EFHC"), tonconnect_transport_kind: row.tonconnect_transport_kind || null,
    jetton_master_address: row.jetton_master_address || null, jetton_decimals: row.jetton_decimals ?? 8,
    fee_message_ton_amount: row.fee_message_ton_amount || "0.050000000",
  }));
}

export async function demoApiRequest<T>(path: string, method: HttpMethod, opts: ApiRequestOptions = {}): Promise<T> {
  await delayForFault();
  const runtime = await readRuntimeSettings();
  const p = clean(path);
  const body = (opts.body || {}) as Record<string, any>;
  if (runtime.fault_mode === "empty" && method === "GET") {
    return (emptyDemoResponse(p) as unknown) as T;
  }

  if (["/auth/session", "/auth/logout", "/auth/telegram/session", "/auth/ton/proof"].includes(p)) {
    return ({ global_id: DEMO_GLOBAL_ID, user_id: DEMO_GLOBAL_ID, tg_id: DEMO_TG_ID, username: DEMO_USERNAME, provider: "offline_simulator", provider_subject: String(DEMO_TG_ID), session_id: "demo-session-0001", roles: ["user", "admin"], is_admin: true } as unknown) as T;
  }
  if (p === "/sync/me" && method === "POST") return (await snapshot()) as T;
  if (p === "/user/me/panels-summary" && method === "GET") return ((await snapshot()).panels as unknown) as T;
  if ((p === "/panels/active" || p === "/panels/archive") && method === "GET") {
    const active = p.endsWith("active");
    const rows = (await ownerPanels()).filter((row) => Boolean(row.is_active) === active);
    const page = paginate(rows, path);
    return ({ ...page, server_now_utc: now() } as unknown) as T;
  }
  if (p === "/panels/activate" && method === "POST") {
    const rows = await readTable("panels");
    const id = Math.max(0, ...rows.map((row) => Number(row.id))) + 1;
    const row = { id, public_id: `PNL-${String(id).padStart(6, "0")}`, user_tg_id: DEMO_TG_ID, activated_at: now(), created_at: now(), expires_at: new Date(Date.now() + 90 * 86400000).toISOString(), archived_at: null, remaining_seconds: 90 * 86400, base_gen_per_sec: "0.00050000", generated_kwh: "0.00000000", is_active: true };
    await putRow("panels", row);
    return ({ panel: { id, public_id: row.public_id, activated_at: row.activated_at, expires_at: row.expires_at }, server_now_utc: now() } as unknown) as T;
  }
  if (p === "/exchange/preview" && method === "GET") return ((await snapshot()).exchange_preview as unknown) as T;
  if (p === "/exchange/convert" && method === "POST") {
    const profile = await owner();
    const amount = Math.max(0, Math.min(Number(body.amount_kwh || 0), Number(profile.available_kwh || 0)));
    profile.available_kwh = d8(Number(profile.available_kwh) - amount);
    profile.main_balance = d8(Number(profile.main_balance) + amount);
    await putRow("users", profile);
    const txs = await readTable("transactions");
    const id = Math.max(0, ...txs.map((row) => Number(row.id))) + 1;
    await putRow("transactions", { id, tg_id: DEMO_TG_ID, amount_efhc: d8(amount), direction: "credit", balance_type: "main", reason: "exchange_kwh_to_efhc", created_at: now() });
    return ({ ok: true, exchanged_kwh: d8(amount), credited_efhc: d8(amount), new_available_kwh: profile.available_kwh, new__main__balance: profile.main_balance, log_id: id, detail: "DEMO_EXCHANGE_COMPLETED" } as unknown) as T;
  }
  if (p === "/tasks/catalog" && method === "GET") return ({ items: await readTable("tasks") } as unknown) as T;
  if (p === "/tasks/my" && method === "GET") return ({ items: await readTable("user_tasks") } as unknown) as T;
  if (p === "/tasks/claim" && method === "POST") {
    const tasks = await readTable("tasks"); const mine = await readTable("user_tasks");
    const task = tasks.find((row) => Number(row.id) === Number(body.task_id));
    const userTask = mine.find((row) => Number(row.task_id) === Number(body.task_id));
    const profile = await owner(); const bonus = Number(task?.bonus_efhc || 0);
    profile.bonus_balance = d8(Number(profile.bonus_balance) + bonus); await putRow("users", profile);
    if (userTask) await putRow("user_tasks", { ...userTask, status: "claimed", can_claim: false });
    return ({ ok: true, tg_id: DEMO_TG_ID, task_id: Number(body.task_id), bonus_efhc: d8(bonus), bonus_balance: profile.bonus_balance, main_balance: profile.main_balance, detail: "DEMO_TASK_CLAIMED" } as unknown) as T;
  }
  if (p === "/ads/slot" && method === "GET") return ({ token: `demo-ad-${Date.now()}`, min_view_sec: 5 } as unknown) as T;
  if (p === "/ads/callback/builtin_timer" && method === "POST") {
    const profile = await owner();
    profile.bonus_balance = d8(Number(profile.bonus_balance || 0) + 5);
    profile.updated_at = now();
    await putRow("users", profile);
    await addTransaction({ tg_id: DEMO_TG_ID, amount: 5, direction: "user_credit", balance_type: "bonus", reason: "ad_reward" });
    return ({ ok: true, bonus_efhc: "5.00000000", bonus_balance: profile.bonus_balance, replayed: false, detail: "DEMO_AD_REWARD" } as unknown) as T;
  }
  if (p === "/referrals/stats/me" && method === "GET") {
    const refs = await readTable("referrals"); const active = refs.filter((row) => row.is_active).length; const total = refs.length;
    const levels = [10, 25, 50, 100, 200]; const level = levels.filter((n) => active >= n).length; const next = level < 5 ? level + 1 : null;
    const profile = await owner();
    return ({ bonus_balance: d8(profile.bonus_balance), referrals_bonus_total: d8(active * 2.5), total_referrals: total, active_referrals: active, inactive_referrals: total - active, level, current_level_min: level ? levels[level - 1] : 0, next_level: next, next_level_min: next ? levels[next - 1] : null, refs_to_next: next ? Math.max(0, levels[next - 1] - active) : 0, progress: next ? Math.min(1, active / levels[next - 1]) : 1, unit_bonus_per_active: "2.50000000", max_active_for_unit_bonus: 200, bonus_asset: "EFHCb", full_cycle_direct_bonus: "500.00000000", full_cycle_level_bonus: "750.00000000", full_cycle_total_bonus: "1250.00000000", level_steps: levels.map((required, index) => ({ level: index + 1, required_active: required, level_bonus: d8((index + 1) * 25), direct_bonus_total: d8(required * 2.5), cumulative_level_bonus: d8(((index + 1) * (index + 2) / 2) * 25), cumulative_total_reward: d8(required * 2.5 + ((index + 1) * (index + 2) / 2) * 25) })), referral_code: "EFHC-MASTER-DEMO", referral_link: "https://t.me/efhc_bot?start=EFHC-MASTER-DEMO" } as unknown) as T;
  }
  if ((p === "/referrals/active/me" || p === "/referrals/inactive/me") && method === "GET") {
    const active = p.includes("/active/"); const rows = (await readTable("referrals")).filter((row) => Boolean(row.is_active) === active);
    return (paginate(rows, path) as unknown) as T;
  }
  if ((p === "/ranks/my-plus-top/me" || p === "/ranks/top/me") && method === "GET") {
    const users = (await readTable("users")).sort((a, b) => Number(b.total_generated_kwh) - Number(a.total_generated_kwh));
    const items = users.map((row, index) => ({ tg_id: Number(row.tg_id), username: row.username || null, total_generated_kwh: d8(row.total_generated_kwh), rank_pos: index + 1, is_vip: Boolean(row.is_vip), active_referrals: index % 18 }));
    if (p.includes("my-plus-top")) return ({ snapshot_at: now(), me: items.find((row) => row.tg_id === DEMO_TG_ID) || items[0], top: items.slice(0, 100), next_cursor: null } as unknown) as T;
    return ({ snapshot_at: now(), items: items.slice(0, 100), next_cursor: null } as unknown) as T;
  }
  if (p === "/wallets/me" && method === "GET") {
    const wallets = (await readTable("wallets")).filter((row) => Number(row.tg_id) === DEMO_TG_ID);
    return ({ is_connected: wallets.length > 0, wallets } as unknown) as T;
  }
  if (/^\/wallets\/[^/]+\/make-primary$/.test(p) && method === "POST") {
    const id = Number(p.split("/")[2]); const wallets = await readTable("wallets");
    for (const wallet of wallets.filter((row) => Number(row.tg_id) === DEMO_TG_ID)) await putRow("wallets", { ...wallet, is_primary: Number(wallet.id) === id });
    return ({ ok: true } as unknown) as T;
  }
  if (/^\/wallets\/[^/]+$/.test(p) && method === "DELETE") { await deleteRow("wallets", Number(p.split("/")[2])); return ({ ok: true } as unknown) as T; }
  if (p === "/wallets/balance-history" && method === "GET") {
    const rows = (await readTable("transactions")).filter((row) => Number(row.tg_id) === DEMO_TG_ID).sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)));
    return (paginate(rows, path, 20) as unknown) as T;
  }
  if ((p === "/withdraw/list" || p === "/withdraw/list/me") && method === "GET") {
    let rows = (await readTable("withdrawals")).filter((row) => Number(row.tg_id) === DEMO_TG_ID);
    const status = query(path).get("status_filter"); if (status && status !== "all") rows = rows.filter((row) => row.status === status);
    const mapped = rows.map((row) => ({ id: Number(row.id), tg_id: Number(row.tg_id), amount: d8(row.amount || row.amount_efhc), status: String(row.status), created_at: String(row.created_at), updated_at: String(row.updated_at) }));
    return (paginate(mapped, path) as unknown) as T;
  }
  if (p === "/withdraw/request" && method === "POST") {
    const rows = await readTable("withdrawals"); const id = Math.max(0, ...rows.map((row) => Number(row.id))) + 1;
    const row = { id, tg_id: DEMO_TG_ID, amount: d8(body.amount), amount_efhc: d8(body.amount), status: "pending", created_at: now(), updated_at: now(), idempotency_key: opts.idempotencyKey || `demo-${id}`, hold_done: true, refund_done: false, payout_ref: null };
    await putRow("withdrawals", row); return (row as unknown) as T;
  }
  if (/^\/withdraw\/\d+$/.test(p) && method === "GET") { return ((await getRow("withdrawals", Number(p.split("/")[2]))) as unknown) as T; }
  if (/^\/withdraw\/\d+\/cancel$/.test(p) && method === "POST") {
    const id = Number(p.split("/")[2]); const row = await getRow("withdrawals", id); if (!row) throw new Error("DEMO_WITHDRAW_NOT_FOUND");
    const updated = { ...row, status: "cancelled", updated_at: now(), refund_done: true }; await putRow("withdrawals", updated); return (updated as unknown) as T;
  }
  if (/^\/v1\/me\/withdraw-outcomes\/\d+$/.test(p) && method === "GET") {
    const id = Number(p.split("/").pop()); return ({ request_id: id, tg_id: DEMO_TG_ID, outcome_kind: "approved", locale: "ru", comment: { text: "Демонстрационная заявка обработана.", template_key: "withdraw_approved", source: "local_demo_engine", locale: "ru", manual_override_used: false, auto_translated: false }, promo: { enabled: true, key: "demo-energy", title: "Продолжайте генерацию", body: "Активируйте дополнительную панель.", cta_label: "Панели", cta_url: "/panels", source: "local_demo_engine" }, top_zone_enabled: true, metadata: { simulator: true } } as unknown) as T;
  }
  if (p === "/skins/catalog" && method === "GET") { const rows = await readTable("skins"); return ({ items: rows.map((r) => ({ skin_id: r.skin_id, title: r.title, price_efhc: r.price_efhc, asset_path: r.asset_path })) } as unknown) as T; }
  if (p === "/skins/my" && method === "GET") { const rows = await readTable("skins"); return ({ active_skin_id: Number(rows.find((r) => r.is_active)?.skin_id || 1), owned: rows.filter((r) => r.purchased_at).map((r) => ({ skin_id: Number(r.skin_id), purchased_at: String(r.purchased_at) })) } as unknown) as T; }
  if (p === "/skins/switcher" && method === "GET") { const rows = await readTable("skins"); const active = Number(rows.find((r) => r.is_active)?.skin_id || 1); return ({ current_level: 4, available_skin_ids: rows.filter((r) => r.is_unlocked).map((r) => Number(r.skin_id)), active_skin_id: active, items: rows.map((r) => ({ skin_id: Number(r.skin_id), title: String(r.title), asset_path: String(r.asset_path), is_unlocked: Boolean(r.is_unlocked), is_active: Boolean(r.is_active) })) } as unknown) as T; }
  if (/^\/skins\/(buy|activate|switcher\/activate)\/\d+$/.test(p) && method === "POST") { const id = Number(p.split("/").pop()); const rows = await readTable("skins"); for (const row of rows) await putRow("skins", { ...row, purchased_at: Number(row.skin_id) === id ? row.purchased_at || now() : row.purchased_at, is_unlocked: Number(row.skin_id) === id ? true : row.is_unlocked, is_active: p.includes("activate") ? Number(row.skin_id) === id : row.is_active }); return ({ ok: true } as unknown) as T; }
  if (p === "/shopfront/access-key" && method === "POST") return ({ redirect_url: "https://appassets.androidplatform.net/browser-shop/?token=demo", expires_at: new Date(Date.now() + 3600000).toISOString(), transport: "external_url", mode: "signed_token" } as unknown) as T;
  if (p === "/hub/shop-truth" && method === "GET") {
    const wallets = await readTable("wallets"); const linked = wallets.length > 0;
    const flow = { handoff_configured: true, handoff_mode: "connected", wallet_linked: linked, wallet_sync_required: !linked, wallet_ready: linked, wallet_blocked: false, action_allowed: true, action_denied: false, readiness_state: linked ? "ready" : "wallet_required", primary_cta: linked ? "open_shop" : "connect_wallet", active_intent: null, active_order_id: null, active_order_status: null, product_state: "catalog", next_action: linked ? "choose_product" : "connect_wallet", return_path: "/hub", canonical_center: "browser_shop", next_step: linked ? "create_intent" : "sync_wallet", blocker_codes: [], browser_shop_path: "/browser-shop", truth_label: "shop_hub_truth_layer" };
    return ({ handoff_configured: true, handoff_mode: "connected", wallet_linked: linked, wallet_sync_required: !linked, active_wallet_address: wallets.find((r) => r.is_primary)?.wallet_address || null, bot_open_url: null, telegram_sync_url: null, wallet_sync_url: null, flow_truth: flow } as unknown) as T;
  }
  if (p === "/shopfront/bootstrap" && method === "GET") { const wallets = await readTable("wallets"); return ({ mode: "handoff_bound", tg_linked: true, tg_id: DEMO_TG_ID, wallet_linked: wallets.length > 0, active_wallet_address: wallets.find((r) => r.is_primary)?.wallet_address || null, wallets, wallet_sync_required: false, bot_open_url: null, telegram_sync_url: null, wallet_sync_url: null, storefront_mode: "browser_shop_mvp", access_mode: "telegram_handoff", future_game_entry_enabled: true, available_modules: ["panels", "vip", "skins"], usdt_checkout_mode: "demo", flow_truth: null, active_payment: null, intent_history: [] } as unknown) as T; }
  if (p === "/shopfront/catalog" && method === "GET") { const rows = (await readTable("shop_items")).filter((r) => r.is_active); return ({ items: rows.map((r) => ({ sku: r.sku, title: r.title, description: r.description || null, item_type: r.item_type, ton_enabled: Boolean(r.ton_enabled), usdt_enabled: Boolean(r.usdt_enabled), methods: r.methods || null })) } as unknown) as T; }
  if (p === "/shopfront/create-intent" && method === "POST") { const orders = await readTable("shop_orders"); const id = Math.max(0, ...orders.map((r) => Number(r.id))) + 1; const item = (await readTable("shop_items")).find((r) => r.sku === body.sku); await putRow("shop_orders", { id, type: "shop", sku: body.sku, quantity: body.quantity || 1, status: "created", user_tg_id: DEMO_TG_ID, tx_hash: null, created_at: now(), updated_at: now() }); return ({ tg_id: DEMO_TG_ID, intent_id: id, order_id: id, item_type: item?.item_type || "item", pay_method: body.pay_method || "EFHC", amount: d8(item?.price_efhc || 0), memo: `EFHC-DEMO-${id}`, to_wallet: "EQD_DEMO_SHOP_RECEIVER", tonconnect_tx: null, expires_at: new Date(Date.now() + 1800000).toISOString() } as unknown) as T; }
  if (p === "/shopfront/intent-status" && method === "GET") { const id = Number(query(path).get("intent_id") || 1); return ({ id, purpose: "shop_purchase", asset: "EFHC", amount_asset_d8: "100.00000000", efhc_amount_d8: "100.00000000", status: "created", payload: `EFHC-DEMO-${id}`, to_address: "EQD_DEMO_SHOP_RECEIVER", created_at: now(), expires_at: new Date(Date.now() + 1800000).toISOString(), flow_truth: null } as unknown) as T; }
  if (p === "/hub/efhc-handoff" && method === "POST") return ({ redirect_url: "https://appassets.androidplatform.net/hub/", expires_at: new Date(Date.now() + 3600000).toISOString(), transport: "external_url", mode: "signed_token" } as unknown) as T;
  if (p === "/deposit/direct-open" && method === "POST") return ({ purpose: "direct_efhc_jetton_deposit", asset: "EFHC", receiver_owner_address: "EQD_DEMO_RECEIVER", jetton_master_address: "EQD_EFHC_DEMO_JETTON_MASTER", jetton_decimals: 8, forward_payload_text: `EFHC:${DEMO_TG_ID}`, fee_message_ton_amount: "0.050000000", forward_ton_amount: "0.010000000", memo_binding: "tg_id" } as unknown) as T;
  if (p === "/wallets/tonconnect/proof-payload" && method === "GET") return ({ payload: "efhc-demo-proof", expires_at: new Date(Date.now() + 300000).toISOString() } as unknown) as T;
  if ((p === "/wallets/tonconnect/check-proof" || p === "/wallets/connect") && method === "POST") {
    let wallets = (await readTable("wallets")).filter((row) => Number(row.tg_id) === DEMO_TG_ID);
    let wallet = wallets[0];
    if (!wallet) {
      wallet = { id: await nextId("wallets"), tg_id: DEMO_TG_ID, wallet_address: String(body.wallet_address || body.address || "EQD_demo_primary_wallet_0000000000000001"), wallet_app: String(body.wallet_app || "Tonkeeper Demo"), is_primary: true, is_active: true, created_at: now() };
      await putRow("wallets", wallet);
    }
    return ({ wallet_id: Number(wallet.id), wallet_address: String(wallet.wallet_address), is_connected: true } as unknown) as T;
  }
  if (p === "/shopfront/profile" && method === "GET") return ((await owner()) as unknown) as T;
  if (p === "/health" && method === "GET") return ({ ok: true, status: "ok", runtime: "offline_simulator", network_access: false, checked_at: now() } as unknown) as T;
  if (p === "/health/db" && method === "GET") return ({ ok: true, db: { ok: true, engine: "indexeddb", error: null }, schema: { ok: true, status: "ok", missing: [], schema: "efhc-offline-simulator-v1" } } as unknown) as T;
  if (p === "/health/runtime" && method === "GET") return ({ ok: true, backend: { ok: true }, db: { ok: true, error: null }, watcher: { ok: true, status: "offline_ready", task_name: "local_demo_clock", last_heartbeat: now(), heartbeat_age_sec: 0, stale_after_sec: 120, error: null } } as unknown) as T;

  // Admin API
  if (p === "/admin/users/search" && method === "GET") return (await adminUsers(path)) as T;
  if (/^\/admin\/users\/\d+$/.test(p) && method === "GET") {
    const tg = Number(p.split("/").pop());
    const response = await adminUsers(`/admin/users/search?q=${tg}`);
    return ((response.items.find((row) => Number(row.tg_id) === tg) || null) as unknown) as T;
  }
  if (/^\/admin\/users\/\d+\/(vip|active)$/.test(p) && method === "PATCH") {
    const parts = p.split("/");
    const tg = Number(parts[3]);
    const key = parts[4] === "vip" ? "is_vip" : "is_active";
    const row = (await readTable("users")).find((item) => Number(item.tg_id) === tg);
    if (!row) throw new Error("DEMO_USER_NOT_FOUND");
    const updated = { ...row, [key]: Boolean(body[key] ?? body.value ?? true), updated_at: now() };
    await putRow("users", updated);
    return (updated as unknown) as T;
  }
  if (/^\/admin\/users\/\d+\/wallet\/reset$/.test(p) && method === "POST") {
    const tg = Number(p.split("/")[3]);
    const wallets = await readTable("wallets");
    for (const wallet of wallets.filter((item) => Number(item.tg_id) === tg)) await deleteRow("wallets", wallet.id);
    const user = (await readTable("users")).find((item) => Number(item.tg_id) === tg);
    if (user) await putRow("users", { ...user, ton_wallet: null, updated_at: now() });
    return ({ ok: true, reset: true, tg_id: tg } as unknown) as T;
  }
  if (p === "/admin/transfer" && method === "POST") {
    const tg = Number(body.tg_id);
    const user = (await readTable("users")).find((item) => Number(item.tg_id) === tg);
    if (!user) throw new Error("DEMO_USER_NOT_FOUND");
    const field = body.balance === "bonus" ? "bonus_balance" : "main_balance";
    const amount = Math.max(0, Number(body.amount || 0));
    const delta = body.direction === "debit" ? -amount : amount;
    user[field] = d8(Math.max(0, Number(user[field] || 0) + delta));
    user.updated_at = now();
    await putRow("users", user);
    const tx = await addTransaction({ tg_id: tg, amount, direction: body.direction === "debit" ? "user_debit" : "user_credit", balance_type: body.balance || "main", reason: body.reason || "admin_correction", idempotency_key: opts.idempotencyKey });
    return ({ ok: true, transfer_id: `demo-transfer-${tx.id}`, status: "completed", user, transaction: mapTransfer(tx) } as unknown) as T;
  }
  if (p === "/admin/bank/balance" && method === "GET") return ({ bank_name: "EFHC Demo Bank", efhc_main: d8(await readBankBalance()) } as unknown) as T;
  if ((p === "/admin/bank/mint" || p === "/admin/bank/burn") && method === "POST") {
    const before = await readBankBalance();
    const amount = Math.max(0, Number(body.amount || 0));
    const after = p.endsWith("mint") ? before + amount : Math.max(0, before - amount);
    await writeBankBalance(after);
    await addTransaction({ tg_id: DEMO_TG_ID, amount, direction: p.endsWith("mint") ? "bank_credit" : "bank_debit", balance_type: "bank", reason: body.reason || (p.endsWith("mint") ? "bank_mint" : "bank_burn"), idempotency_key: opts.idempotencyKey });
    return ({ ok: true, bank_balance_after: d8(after) } as unknown) as T;
  }
  if (p === "/admin/panels" && method === "GET") {
    let rows = (await readTable("panels")).map(mapPanel);
    const tg = query(path).get("tg_id");
    const active = query(path).get("is_active");
    if (tg) rows = rows.filter((row) => Number(row.tg_id) === Number(tg));
    if (active !== null) rows = rows.filter((row) => Boolean(row.is_active) === (active === "true"));
    return ({ ok: true, items: rows } as unknown) as T;
  }
  if (/^\/admin\/panels\/\d+\/(activate|deactivate)$/.test(p) && ["POST", "PATCH"].includes(method)) {
    const parts = p.split("/");
    const id = Number(parts[3]);
    const row = await getRow("panels", id);
    if (!row) throw new Error("DEMO_PANEL_NOT_FOUND");
    const activating = parts[4] === "activate";
    const updated = { ...row, is_active: activating, archived_at: activating ? null : now(), activated_at: activating ? now() : row.activated_at, updated_at: now() };
    await putRow("panels", updated);
    return ({ ok: true, panel: mapPanel(updated) } as unknown) as T;
  }
  if (p === "/admin/withdrawals" && method === "GET") return ((await adminWithdrawals(path)) as unknown) as T;
  if (p === "/admin/withdrawals/repair-consistency" && method === "POST") return ({ ok: true, auto_fixed_hold: 1, auto_fixed_refund: 1 } as unknown) as T;
  if (/^\/admin\/withdrawals\/\d+\/outcome-preview$/.test(p) && method === "GET") {
    const id = Number(p.split("/")[3]);
    return ({ request_id: id, withdrawal_status: "pending", preview_mode: "demo", bundle: { request_id: id, tg_id: DEMO_TG_ID, outcome_kind: "approved", locale: "ru", comment: { text: "Предпросмотр результата в симуляторе", template_key: "withdraw_approved", source: "local_demo_engine", locale: "ru", manual_override_used: false, auto_translated: false }, promo: { enabled: false }, top_zone_enabled: true, metadata: { demo: true } } } as unknown) as T;
  }
  if (/^\/admin\/withdrawals\/\d+\/(approve|reject)$/.test(p) && method === "POST") {
    const parts = p.split("/"); const id = Number(parts[3]); const row = await getRow("withdrawals", id);
    if (!row) throw new Error("DEMO_WITHDRAW_NOT_FOUND");
    const status = parts[4] === "approve" ? "approved" : "rejected";
    const updated = { ...row, status, processed_at: now(), updated_at: now(), tx_hash: status === "approved" ? body.tx_hash || `demo-approved-${id}` : null, error_message: status === "rejected" ? body.reason || "DEMO_REJECTED" : null };
    await putRow("withdrawals", updated);
    return ({ ok: true, result: updated } as unknown) as T;
  }
  if (p === "/admin/referrals/summary" && method === "GET") {
    const refs = await readTable("referrals");
    return ({ items: [{ inviter_tg_id: DEMO_TG_ID, active_count: refs.filter((row) => row.is_active).length, inactive_count: refs.filter((row) => !row.is_active).length, total_bonus_efhc: d8(refs.filter((row) => row.is_active).length * 2.5), last_invited_at: refs.map((row) => String(row.invited_at)).sort().at(-1) || null }], next_cursor: null } as unknown) as T;
  }
  if (p === "/admin/ads/providers" && method === "GET") return ({ items: [{ id: "builtin_timer", title: "Встроенный демо-таймер", enabled: true, status: "healthy", reward_efhc: "5.00000000" }, { id: "partner_demo", title: "Партнёрская сеть Demo", enabled: false, status: "disabled", reward_efhc: "8.00000000" }] } as unknown) as T;
  if (p === "/admin/tasks" && method === "GET") return ({ ...paginate(await readTable("tasks"), path, 25) } as unknown) as T;
  if (/^\/admin\/tasks\/\d+\/subs$/.test(p) && method === "GET") {
    const taskId = Number(p.split("/")[3]);
    const status = query(path).get("status");
    let rows = (await readTable("user_tasks")).filter((row) => Number(row.task_id) === taskId);
    if (status && status !== "ALL") rows = rows.filter((row) => String(row.status).toUpperCase() === status.toUpperCase());
    const mapped = rows.map((row) => ({ id: Number(row.id), task_id: Number(row.task_id), tg_id: Number(row.tg_id), status: String(row.status).toUpperCase(), proof_text: row.proof_text || null, proof_url: row.proof_url || null, submitted_at: row.submitted_at || now(), reviewed_at: row.reviewed_at || null, bonus_efhc: row.bonus_efhc || null, moderator_tg_id: row.moderator_tg_id || null, moderator_note: row.moderator_note || null }));
    return ({ ...paginate(mapped, path, 25) } as unknown) as T;
  }
  if (/^\/admin\/tasks\/\d+$/.test(p) && ["GET", "PATCH", "DELETE"].includes(method)) {
    const id = Number(p.split("/").pop()); const row = await getRow("tasks", id);
    if (method === "DELETE") { await deleteRow("tasks", id); return ({ ok: true } as unknown) as T; }
    if (method === "PATCH" && row) { const updated = { ...row, ...body, updated_at: now() }; await putRow("tasks", updated); return (updated as unknown) as T; }
    return ((row || null) as unknown) as T;
  }
  if (p === "/admin/tasks/refresh-statuses" && method === "POST") return ({ ok: true, refreshed: (await readTable("user_tasks")).length, detail: "Локальные статусы заданий синхронизированы" } as unknown) as T;
  if (/^\/admin\/tasks\/submissions\/\d+\/moderate$/.test(p) && method === "POST") {
    const id = Number(p.split("/")[4]); const row = await getRow("user_tasks", id);
    if (!row) throw new Error("DEMO_SUBMISSION_NOT_FOUND");
    const approved = Boolean(body.approve);
    const updated = { ...row, status: approved ? "APPROVED" : "REJECTED", reviewed_at: now(), moderator_tg_id: DEMO_TG_ID, moderator_note: body.moderator_note || null };
    await putRow("user_tasks", updated);
    if (approved) {
      const user = (await readTable("users")).find((item) => Number(item.tg_id) === Number(row.tg_id));
      if (user) { user.bonus_balance = d8(Number(user.bonus_balance || 0) + Number(row.bonus_efhc || 0)); user.updated_at = now(); await putRow("users", user); }
      await addTransaction({ tg_id: row.tg_id, amount: row.bonus_efhc, direction: "user_credit", balance_type: "bonus", reason: "task_bonus", idempotency_key: opts.idempotencyKey });
    }
    return (updated as unknown) as T;
  }
  if (p === "/admin/shop/items" && method === "GET") return ((await readTable("shop_items")) as unknown) as T;
  if (p === "/admin/shop/items/upsert" && method === "POST") {
    const items = await readTable("shop_items");
    const code = String(body.code || body.sku || "demo-item");
    const existing = items.find((row) => String(row.code || row.sku) === code);
    const id = Number(existing?.id || await nextId("shop_items"));
    const status = String(body.status || existing?.status || "draft");
    const item = { ...(existing || {}), id, sku: code, code, title: String(body.title || existing?.title || code), description: body.description ?? existing?.description ?? null, item_type: String(body.item_type || existing?.item_type || "EFHC_PACKAGE"), quantity_efhc: body.quantity_efhc ?? existing?.quantity_efhc ?? null, image_url: body.image_url ?? existing?.image_url ?? null, price_ton: body.price_ton ?? existing?.price_ton ?? null, price_usdt: body.price_usdt ?? existing?.price_usdt ?? null, pay_currencies: body.pay_currencies ?? existing?.pay_currencies ?? [], status, is_active: status === "live", active: status === "live", ton_enabled: Boolean(body.price_ton ?? existing?.price_ton), usdt_enabled: Boolean(body.price_usdt ?? existing?.price_usdt), methods: { TON: body.price_ton ? { price: body.price_ton } : undefined, USDT: body.price_usdt ? { price: body.price_usdt } : undefined }, created_at: existing?.created_at || now(), updated_at: now(), history_count: Number(existing?.history_count || 0) + 1, history_tail: existing?.history_tail || [] };
    await putRow("shop_items", item);
    return (item as unknown) as T;
  }
  if (p === "/admin/shop/items/status" && method === "POST") {
    const code = String(body.code || ""); const item = (await readTable("shop_items")).find((row) => String(row.code || row.sku) === code);
    if (!item) throw new Error("DEMO_SHOP_ITEM_NOT_FOUND");
    const status = String(body.status || "draft"); const updated = { ...item, status, is_active: status === "live", active: status === "live", updated_at: now() };
    await putRow("shop_items", updated); return (updated as unknown) as T;
  }
  if (p === "/admin/shop/items/delete" && method === "POST") {
    const code = String(body.code || ""); const item = (await readTable("shop_items")).find((row) => String(row.code || row.sku) === code);
    if (item) await deleteRow("shop_items", item.id); return ({ ok: true, code } as unknown) as T;
  }
  if (p === "/admin/shop/items/set-price" && method === "POST") return ({ ok: true } as unknown) as T;
  if (p === "/admin/shop/orders" && method === "GET") return ({ ...paginate(await readTable("shop_orders"), path, 100) } as unknown) as T;
  if (/^\/admin\/shop\/order\/legacy\/\d+$/.test(p) && method === "GET") {
    const id = Number(p.split("/").pop()); const row = await getRow("shop_orders", id);
    if (!row) throw new Error("DEMO_SHOP_ORDER_NOT_FOUND");
    return ({ order_id: Number(row.id), tg_id: Number(row.user_tg_id), status: String(row.status), type: String(row.type || "shop"), tx_hash: row.tx_hash || null, memo: row.memo || `EFHC-DEMO-${row.id}` } as unknown) as T;
  }
  if (/^\/admin\/shop\/orders\/user\/legacy\/\d+$/.test(p) && method === "GET") {
    const tg = Number(p.split("/").pop()); const rows = (await readTable("shop_orders")).filter((row) => Number(row.user_tg_id) === tg);
    return (rows.map((row) => ({ order_id: Number(row.id), tg_id: Number(row.user_tg_id), status: String(row.status), type: String(row.type || "shop"), tx_hash: row.tx_hash || null, memo: row.memo || `EFHC-DEMO-${row.id}` })) as unknown) as T;
  }
  if (/^\/admin\/shop\/orders\/\d+\/force-fulfill$/.test(p) && method === "POST") {
    const id = Number(p.split("/")[4]); const row = await getRow("shop_orders", id);
    if (!row) throw new Error("DEMO_SHOP_ORDER_NOT_FOUND");
    const updated = { ...row, status: "fulfilled", updated_at: now(), fulfillment_reason: body.reason || "manual force fulfill" };
    await putRow("shop_orders", updated); return ({ ok: true, status: "fulfilled", order: updated } as unknown) as T;
  }
  if (p === "/admin/hub/links" && method === "GET") return ({ items: await readTable("hub_links"), next_cursor: null } as unknown) as T;
  if (p === "/admin/hub/links" && method === "POST") { const id = await nextId("hub_links"); const row = { id, ...body, created_at: now(), updated_at: now() }; await putRow("hub_links", row); return (row as unknown) as T; }
  if (/^\/admin\/hub\/links\/\d+$/.test(p) && method === "PATCH") { const id = Number(p.split("/").pop()); const row = await getRow("hub_links", id); const updated = { ...(row || { id }), ...body, updated_at: now() }; await putRow("hub_links", updated); return (updated as unknown) as T; }
  if (/^\/admin\/hub\/links\/\d+\/toggle$/.test(p) && method === "POST") { const id = Number(p.split("/")[4]); const row = await getRow("hub_links", id); const updated = { ...(row || { id }), is_active: Boolean(body.is_active), updated_at: now() }; await putRow("hub_links", updated); return (updated as unknown) as T; }
  if (p === "/admin/hub/links/reorder" && method === "POST") { for (const item of body.items || []) { const row = await getRow("hub_links", Number(item.id)); if (row) await putRow("hub_links", { ...row, sort_order: Number(item.sort_order), updated_at: now() }); } return ({ ok: true } as unknown) as T; }
  if (p === "/admin/templates" && method === "GET") return ({ items: await readTable("templates"), next_cursor: null } as unknown) as T;
  if (/^\/admin\/templates\/.+/.test(p) && ["GET", "PUT", "PATCH"].includes(method)) { const key = decodeURIComponent(p.split("/").pop() || ""); const row = await getRow("templates", key); if (method === "GET") return ((row || null) as unknown) as T; const updated = { id: key, key, ...(row || {}), ...body, updated_at: now() }; await putRow("templates", updated); return (updated as unknown) as T; }
  if (p === "/admin/efhc-deposits/runtime-summary" && method === "GET") return ({ ok: true, total: 18, pending: 2, confirmed: 15, failed: 1, last_processed_at: now(), items: (await readTable("transactions")).filter((row) => row.reason === "efhc_external_deposit").slice(0, 12).map(mapTransfer) } as unknown) as T;
  if (p === "/admin/efhc-deposits/process" && method === "POST") return ({ ok: true, processed: 3, confirmed: 2, failed: 1 } as unknown) as T;
  if (/^\/admin\/efhc-deposits\/reprocess\/.+/.test(p) && method === "POST") return ({ ok: true, status: "confirmed", tx_hash: decodeURIComponent(p.split("/").pop() || "") } as unknown) as T;
  if (p === "/admin/logs/transfers" && method === "GET") {
    let rows = (await readTable("transactions")).map(mapTransfer).sort((a, b) => b.created_at.localeCompare(a.created_at));
    const reason = query(path).get("reason"); if (reason) rows = rows.filter((row) => row.reason.includes(reason));
    return ({ ok: true, ...paginate(rows, path, 80) } as unknown) as T;
  }
  if (p === "/admin/observability/events" && method === "GET") return ({ ok: true, data_kind: "raw", source: "local_demo_engine", items: await readTable("admin_events") } as unknown) as T;
  if (p === "/admin/observability/health" && method === "GET") return ({ ok: true, status: "healthy", severity: "success", database: "indexeddb", runtime: "offline_simulator", source: "local_demo_engine", checks: [{ key: "local_database", ok: true }, { key: "production_network", ok: false, expected: false }] } as unknown) as T;
  if (p === "/admin/observability/summary" && method === "GET") return ({ ok: true, data_kind: "raw", generated_at: now(), source: "local_demo_engine", metrics: [{ key: "users", label: "Пользователи", value: String((await readTable("users")).length), unit: "count", source: "users", data_kind: "raw" }, { key: "panels", label: "Панели", value: String((await readTable("panels")).length), unit: "count", source: "panels", data_kind: "raw" }, { key: "transactions", label: "Операции", value: String((await readTable("transactions")).length), unit: "count", source: "transactions", data_kind: "raw" }] } as unknown) as T;
  if (p === "/admin/observability/timeseries" && method === "GET") { const metric = query(path).get("metric") || "users_created"; return ({ ok: true, data_kind: "local_demo_timeseries", synthetic: true, metric, bucket: query(path).get("bucket") || "day", range_hours: Number(query(path).get("range_hours") || 168), unit: "count", source: "local_demo_engine", points: Array.from({ length: 14 }, (_, index) => ({ ts: new Date(Date.now() - (13-index)*86400000).toISOString(), value: String(10 + index * 3), label: `D${index+1}` })), empty_reason: null } as unknown) as T; }
  if (p.startsWith("/admin/reports/") && method === "GET") return ((await report(p.split("/").pop() || "overview")) as unknown) as T;
  if (p === "/admin/ton/reconcile" && method === "POST") return ({ ok: true, checked: 12, repaired: 1, skipped: 11 } as unknown) as T;
  if (p === "/admin/sale-packages" && method === "GET") return ({ items: [{ id: 1, code: "starter", title: "Starter", price_efhc: "100.00000000", is_active: true }, { id: 2, code: "pro", title: "Pro", price_efhc: "500.00000000", is_active: true }], next_cursor: null } as unknown) as T;
  if (p.startsWith("/admin/sale-packages/") && ["POST", "PATCH", "DELETE"].includes(method)) return ({ ok: true, package: body } as unknown) as T;

  throw new Error(`DEMO_API_ROUTE_NOT_IMPLEMENTED:${method}:${p}`);
}
