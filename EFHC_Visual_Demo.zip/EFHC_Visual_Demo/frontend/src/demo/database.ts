import {
  assertDemoSeedIntegrity,
  buildDemoSeed,
  type DemoRow,
  type DemoSeed,
} from "./seed";
import { type DemoFaultMode, type DemoScenario } from "./runtime";

const DB_NAME = "efhc-offline-simulator-v1";
export const DEMO_DATABASE_SCHEMA = "efhc-offline-simulator-v2";
const DB_VERSION = 2;
export const DEMO_TABLES = [
  "settings", "users", "panels", "transactions", "tasks", "user_tasks",
  "referrals", "wallets", "withdrawals", "shop_items", "shop_orders",
  "hub_links", "admin_events", "skins", "templates", "sale_packages",
  "ad_events",
] as const;
export type DemoTable = (typeof DEMO_TABLES)[number];

type IndexSpec = {
  name: string;
  keyPath: string | string[];
  unique?: boolean;
};

const TABLE_INDEXES: Partial<Record<DemoTable, IndexSpec[]>> = {
  users: [
    { name: "by_global_id", keyPath: "global_id", unique: true },
    { name: "by_tg_id", keyPath: "tg_id", unique: true },
    { name: "by_username", keyPath: "username" },
  ],
  panels: [
    { name: "by_public_id", keyPath: "public_id", unique: true },
    { name: "by_user_tg_id", keyPath: "user_tg_id" },
  ],
  transactions: [
    { name: "by_tg_id", keyPath: "tg_id" },
    { name: "by_created_at", keyPath: "created_at" },
    { name: "by_reason", keyPath: "reason" },
  ],
  tasks: [
    { name: "by_code", keyPath: "code", unique: true },
  ],
  user_tasks: [
    { name: "by_task_id", keyPath: "task_id" },
    { name: "by_tg_id", keyPath: "tg_id" },
    { name: "by_status", keyPath: "status" },
    { name: "by_task_and_user", keyPath: ["task_id", "tg_id"], unique: true },
  ],
  referrals: [
    { name: "by_inviter_tg_id", keyPath: "inviter_tg_id" },
    { name: "by_child_tg_id", keyPath: "child_tg_id", unique: true },
  ],
  wallets: [
    { name: "by_tg_id", keyPath: "tg_id" },
    { name: "by_wallet_address", keyPath: "wallet_address", unique: true },
  ],
  withdrawals: [
    { name: "by_tg_id", keyPath: "tg_id" },
    { name: "by_status", keyPath: "status" },
    { name: "by_created_at", keyPath: "created_at" },
  ],
  shop_items: [
    { name: "by_sku", keyPath: "sku", unique: true },
    { name: "by_status", keyPath: "status" },
  ],
  shop_orders: [
    { name: "by_user_tg_id", keyPath: "user_tg_id" },
    { name: "by_status", keyPath: "status" },
    { name: "by_sku", keyPath: "sku" },
  ],
  hub_links: [
    { name: "by_code", keyPath: "code", unique: true },
    { name: "by_sort_order", keyPath: "sort_order" },
  ],
  admin_events: [
    { name: "by_type", keyPath: "type" },
    { name: "by_severity", keyPath: "severity" },
    { name: "by_ts", keyPath: "ts" },
  ],
  skins: [
    { name: "by_skin_id", keyPath: "skin_id", unique: true },
  ],
  templates: [
    { name: "by_key", keyPath: "key", unique: true },
    { name: "by_locale", keyPath: "locale" },
  ],
  sale_packages: [
    { name: "by_code", keyPath: "code", unique: true },
  ],
  ad_events: [
    { name: "by_token", keyPath: "token", unique: true },
    { name: "by_tg_id", keyPath: "tg_id" },
    { name: "by_created_at", keyPath: "created_at" },
  ],
};

function requestResult<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("DEMO_IDB_REQUEST_FAILED"));
  });
}

function txDone(tx: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error ?? new Error("DEMO_IDB_TRANSACTION_FAILED"));
    tx.onabort = () => reject(tx.error ?? new Error("DEMO_IDB_TRANSACTION_ABORTED"));
  });
}

function ensureIndexes(store: IDBObjectStore, table: DemoTable): void {
  for (const index of TABLE_INDEXES[table] ?? []) {
    if (!store.indexNames.contains(index.name)) {
      store.createIndex(index.name, index.keyPath, { unique: Boolean(index.unique) });
    }
  }
}

async function openRaw(): Promise<IDBDatabase> {
  if (typeof indexedDB === "undefined") throw new Error("DEMO_INDEXEDDB_UNAVAILABLE");
  const request = indexedDB.open(DB_NAME, DB_VERSION);
  request.onupgradeneeded = () => {
    const db = request.result;
    const tx = request.transaction;
    if (!tx) throw new Error("DEMO_INDEXEDDB_UPGRADE_TRANSACTION_MISSING");
    for (const name of DEMO_TABLES) {
      const store = db.objectStoreNames.contains(name)
        ? tx.objectStore(name)
        : db.createObjectStore(name, { keyPath: "id" });
      ensureIndexes(store, name);
    }
  };
  return requestResult(request);
}

async function seedDatabase(db: IDBDatabase, seed: DemoSeed): Promise<void> {
  assertDemoSeedIntegrity(seed);
  const tx = db.transaction([...DEMO_TABLES], "readwrite");
  for (const table of DEMO_TABLES) {
    const store = tx.objectStore(table);
    store.clear();
    for (const row of seed[table] ?? []) store.put(row);
  }
  await txDone(tx);
}

let readyPromise: Promise<IDBDatabase> | null = null;

async function migrateDatabaseData(db: IDBDatabase, runtime: DemoRow): Promise<void> {
  const currentVersion = Number(runtime.database_version || 1);
  if (currentVersion >= DB_VERSION) return;

  const scenario = (runtime.scenario as DemoScenario) || "active";
  const defaults = buildDemoSeed(scenario);

  const countTx = db.transaction("sale_packages", "readonly");
  const salePackageCount = await requestResult(
    countTx.objectStore("sale_packages").count(),
  );
  await txDone(countTx);

  const writeTx = db.transaction(
    ["settings", "sale_packages", "ad_events"],
    "readwrite",
  );
  if (salePackageCount === 0) {
    const salePackages = writeTx.objectStore("sale_packages");
    for (const row of defaults.sale_packages ?? []) salePackages.put(row);
  }
  writeTx.objectStore("settings").put({
    ...runtime,
    database_version: DB_VERSION,
    schema: DEMO_DATABASE_SCHEMA,
    revision: Number(runtime.revision || 1) + 1,
  });
  await txDone(writeTx);
}

export async function getDemoDatabase(): Promise<IDBDatabase> {
  if (!readyPromise) {
    readyPromise = openRaw().then(async (db) => {
      const tx = db.transaction("settings", "readonly");
      const runtime = await requestResult<DemoRow | undefined>(
        tx.objectStore("settings").get("runtime"),
      );
      await txDone(tx);
      if (!runtime) {
        await seedDatabase(db, buildDemoSeed("active"));
      } else {
        await migrateDatabaseData(db, runtime);
      }
      return db;
    }).catch((error) => {
      readyPromise = null;
      throw error;
    });
  }
  return readyPromise;
}

export async function readTable<T extends DemoRow = DemoRow>(table: DemoTable): Promise<T[]> {
  const db = await getDemoDatabase();
  const tx = db.transaction(table, "readonly");
  const rows = await requestResult(tx.objectStore(table).getAll());
  await txDone(tx);
  return rows as T[];
}

export async function getRow<T extends DemoRow = DemoRow>(table: DemoTable, id: IDBValidKey): Promise<T | undefined> {
  const db = await getDemoDatabase();
  const tx = db.transaction(table, "readonly");
  const row = await requestResult(tx.objectStore(table).get(id));
  await txDone(tx);
  return row as T | undefined;
}

export async function putRow(table: DemoTable, row: DemoRow): Promise<void> {
  const db = await getDemoDatabase();
  const tx = db.transaction(table, "readwrite");
  tx.objectStore(table).put(row);
  await txDone(tx);
  if (typeof window !== "undefined") window.dispatchEvent(new CustomEvent("efhc-demo-data-changed", { detail: { table } }));
}

export async function deleteRow(table: DemoTable, id: IDBValidKey): Promise<void> {
  const db = await getDemoDatabase();
  const tx = db.transaction(table, "readwrite");
  tx.objectStore(table).delete(id);
  await txDone(tx);
  if (typeof window !== "undefined") window.dispatchEvent(new CustomEvent("efhc-demo-data-changed", { detail: { table } }));
}

export async function resetDemoDatabase(scenario: DemoScenario = "active"): Promise<void> {
  const db = await getDemoDatabase();
  await seedDatabase(db, buildDemoSeed(scenario));
  if (typeof window !== "undefined") window.dispatchEvent(new CustomEvent("efhc-demo-reset", { detail: { scenario } }));
}

export async function readRuntimeSettings(): Promise<{ scenario: DemoScenario; fault_mode: DemoFaultMode; seed: string; revision: number }> {
  const row = await getRow("settings", "runtime");
  return {
    scenario: (row?.scenario as DemoScenario) || "active",
    fault_mode: (row?.fault_mode as DemoFaultMode) || "normal",
    seed: String(row?.seed || "EFHC-DEMO-SEED-001"),
    revision: Number(row?.revision || 1),
  };
}

export async function updateRuntimeSettings(patch: Partial<{ scenario: DemoScenario; fault_mode: DemoFaultMode; seed: string }>): Promise<void> {
  const stored = await getRow("settings", "runtime");
  const current = await readRuntimeSettings();
  await putRow("settings", {
    ...(stored || {}),
    id: "runtime",
    ...current,
    ...patch,
    revision: current.revision + 1,
    database_version: DB_VERSION,
    schema: DEMO_DATABASE_SCHEMA,
  });
}
