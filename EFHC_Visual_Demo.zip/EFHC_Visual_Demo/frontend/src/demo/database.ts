import { buildDemoSeed, type DemoRow, type DemoSeed } from "./seed";
import { type DemoFaultMode, type DemoScenario } from "./runtime";

const DB_NAME = "efhc-offline-simulator-v1";
const DB_VERSION = 1;
export const DEMO_TABLES = [
  "settings", "users", "panels", "transactions", "tasks", "user_tasks",
  "referrals", "wallets", "withdrawals", "shop_items", "shop_orders",
  "hub_links", "admin_events", "skins", "templates",
] as const;
export type DemoTable = (typeof DEMO_TABLES)[number];

function requestResult<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("DEMO_IDB_REQUEST_FAILED"));
  });
}

function txDone(tx: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error ?? new Error("DEMO_IDB_TRANSACTION_FAILED"));
    tx.onabort = () => reject(tx.error ?? new Error("DEMO_IDB_TRANSACTION_ABORTED"));
  });
}

async function openRaw(): Promise<IDBDatabase> {
  if (typeof indexedDB === "undefined") throw new Error("DEMO_INDEXEDDB_UNAVAILABLE");
  const request = indexedDB.open(DB_NAME, DB_VERSION);
  request.onupgradeneeded = () => {
    const db = request.result;
    for (const name of DEMO_TABLES) {
      if (!db.objectStoreNames.contains(name)) db.createObjectStore(name, { keyPath: "id" });
    }
  };
  return requestResult(request);
}

async function seedDatabase(db: IDBDatabase, seed: DemoSeed): Promise<void> {
  const tx = db.transaction([...DEMO_TABLES], "readwrite");
  for (const table of DEMO_TABLES) {
    const store = tx.objectStore(table);
    store.clear();
    for (const row of seed[table] ?? []) store.put(row);
  }
  await txDone(tx);
}

let readyPromise: Promise<IDBDatabase> | null = null;

export async function getDemoDatabase(): Promise<IDBDatabase> {
  if (!readyPromise) {
    readyPromise = openRaw().then(async (db) => {
      const tx = db.transaction("settings", "readonly");
      const runtime = await requestResult(tx.objectStore("settings").get("runtime"));
      await txDone(tx);
      if (!runtime) await seedDatabase(db, buildDemoSeed("active"));
      return db;
    });
  }
  return readyPromise;
}

export async function readTable<T extends DemoRow = DemoRow>(table: DemoTable): Promise<T[]> {
  const db = await getDemoDatabase();
  const tx = db.transaction(table, "readonly");
  const rows = await requestResult(tx.objectStore(table).getAll());
  await txDone(tx);
  return rows as T[];
}

export async function getRow<T extends DemoRow = DemoRow>(table: DemoTable, id: IDBValidKey): Promise<T | undefined> {
  const db = await getDemoDatabase();
  const tx = db.transaction(table, "readonly");
  const row = await requestResult(tx.objectStore(table).get(id));
  await txDone(tx);
  return row as T | undefined;
}

export async function putRow(table: DemoTable, row: DemoRow): Promise<void> {
  const db = await getDemoDatabase();
  const tx = db.transaction(table, "readwrite");
  tx.objectStore(table).put(row);
  await txDone(tx);
  window.dispatchEvent(new CustomEvent("efhc-demo-data-changed", { detail: { table } }));
}

export async function deleteRow(table: DemoTable, id: IDBValidKey): Promise<void> {
  const db = await getDemoDatabase();
  const tx = db.transaction(table, "readwrite");
  tx.objectStore(table).delete(id);
  await txDone(tx);
  window.dispatchEvent(new CustomEvent("efhc-demo-data-changed", { detail: { table } }));
}

export async function resetDemoDatabase(scenario: DemoScenario = "active"): Promise<void> {
  const db = await getDemoDatabase();
  await seedDatabase(db, buildDemoSeed(scenario));
  window.dispatchEvent(new CustomEvent("efhc-demo-reset", { detail: { scenario } }));
}

export async function readRuntimeSettings(): Promise<{ scenario: DemoScenario; fault_mode: DemoFaultMode; seed: string; revision: number }> {
  const row = await getRow("settings", "runtime");
  return {
    scenario: (row?.scenario as DemoScenario) || "active",
    fault_mode: (row?.fault_mode as DemoFaultMode) || "normal",
    seed: String(row?.seed || "EFHC-DEMO-SEED-001"),
    revision: Number(row?.revision || 1),
  };
}

export async function updateRuntimeSettings(patch: Partial<{ scenario: DemoScenario; fault_mode: DemoFaultMode; seed: string }>): Promise<void> {
  const current = await readRuntimeSettings();
  await putRow("settings", {
    id: "runtime",
    ...current,
    ...patch,
    revision: current.revision + 1,
  });
}
