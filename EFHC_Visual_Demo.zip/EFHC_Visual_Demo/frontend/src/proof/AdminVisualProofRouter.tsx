import dynamic from "next/dynamic";
import React from "react";

type AdminPageComponent = React.ComponentType<Record<string, unknown>>;

function proofPage(
  loader: () => Promise<{ default: AdminPageComponent }>,
): AdminPageComponent {
  return dynamic(loader, {
    ssr: false,
    loading: () => (
      <div className="efhc-admin-proof-loading">
        Загрузка раздела администратора…
      </div>
    ),
  }) as AdminPageComponent;
}

const ADMIN_PROOF_COMPONENTS: Record<string, AdminPageComponent> = {
  "/admin": proofPage(() => import("../pages/admin")),
  "/admin/ads": proofPage(() => import("../pages/admin/ads")),
  "/admin/bank": proofPage(() => import("../pages/admin/bank")),
  "/admin/diagnostics": proofPage(
    () => import("../pages/admin/diagnostics"),
  ),
  "/admin/efhc-deposits": proofPage(
    () => import("../pages/admin/efhc-deposits"),
  ),
  "/admin/hub": proofPage(() => import("../pages/admin/hub")),
  "/admin/logs": proofPage(() => import("../pages/admin/logs")),
  "/admin/panels": proofPage(
    () => import("../pages/admin/panels"),
  ),
  "/admin/referrals": proofPage(
    () => import("../pages/admin/referrals"),
  ),
  "/admin/reports": proofPage(
    () => import("../pages/admin/reports"),
  ),
  "/admin/sale-packages": proofPage(
    () => import("../pages/admin/sale-packages"),
  ),
  "/admin/shop": proofPage(() => import("../pages/admin/shop")),
  "/admin/system": proofPage(
    () => import("../pages/admin/system"),
  ),
  "/admin/tasks": proofPage(() => import("../pages/admin/tasks")),
  "/admin/templates": proofPage(
    () => import("../pages/admin/templates"),
  ),
  "/admin/users": proofPage(() => import("../pages/admin/users")),
  "/admin/withdrawals": proofPage(
    () => import("../pages/admin/withdrawals"),
  ),
};

export function AdminVisualProofRouter(props: {
  path: string;
  pageProps: Record<string, unknown>;
}) {
  const Component = ADMIN_PROOF_COMPONENTS[props.path]
    || ADMIN_PROOF_COMPONENTS["/admin"];
  return (
    <div
      data-admin-visual-proof-route={props.path}
      data-admin-visual-proof-harness="managed-urlblocklist"
    >
      <Component {...props.pageProps} />
    </div>
  );
}
