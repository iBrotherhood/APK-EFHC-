import { useMutation } from "@tanstack/react-query";

import { createHubEfhcHandoff } from "../services/hub.service";

export function useHubEfhcHandoff() {
  return useMutation({
    mutationFn: createHubEfhcHandoff,
  });
}
