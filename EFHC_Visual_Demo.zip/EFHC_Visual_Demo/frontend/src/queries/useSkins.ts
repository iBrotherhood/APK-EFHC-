import {
  useMutation,
  useQuery,
  useQueryClient,
} from "@tanstack/react-query";

import {
  activateSkin,
  activateSwitcherSkin,
  buySkin,
  getMySkins,
  getSkinsCatalog,
  getSkinSwitcher,
} from "../services/skins.service";

const skinKeys = {
  all: ["skins"] as const,
  catalog: ["skins", "catalog"] as const,
  mine: (tg_id: number | null) => ["skins", "mine", tg_id] as const,
  switcher: (tg_id: number | null) => [
    "skins",
    "switcher",
    tg_id,
  ] as const,
};

function dispatchSkinChanged() {
  if (typeof window !== "undefined") {
    window.dispatchEvent(new Event("efhc_shop_skin_changed"));
  }
}

export function useMySkins(tg_id: number | null) {
  return useQuery({
    queryKey: skinKeys.mine(tg_id),
    enabled: Boolean(tg_id),
    queryFn: getMySkins,
    staleTime: 10_000,
  });
}

export function useSkinsCatalog() {
  return useQuery({
    queryKey: skinKeys.catalog,
    queryFn: getSkinsCatalog,
    staleTime: 30_000,
  });
}

export function useSkinSwitcher(tg_id: number | null) {
  return useQuery({
    queryKey: skinKeys.switcher(tg_id),
    enabled: Boolean(tg_id),
    queryFn: getSkinSwitcher,
    staleTime: 10_000,
  });
}

export function useSkinActions(tg_id: number | null) {
  const queryClient = useQueryClient();
  const invalidate = async () => {
    await queryClient.invalidateQueries({ queryKey: skinKeys.all });
    dispatchSkinChanged();
  };
  const buy = useMutation({
    mutationFn: buySkin,
    onSuccess: invalidate,
  });
  const activate = useMutation({
    mutationFn: activateSkin,
    onSuccess: invalidate,
  });
  const activateSwitcher = useMutation({
    mutationFn: activateSwitcherSkin,
    onSuccess: invalidate,
  });
  return { buy, activate, activateSwitcher, tg_id };
}
