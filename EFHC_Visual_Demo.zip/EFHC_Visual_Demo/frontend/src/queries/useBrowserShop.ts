import {
  useMutation,
  useQuery,
  useQueryClient,
} from "@tanstack/react-query";

import {
  createBrowserShopAccessKey,
  createBrowserShopIntent,
  getBrowserShopBootstrap,
  getBrowserShopCatalog,
  getBrowserShopIntentStatus,
} from "../services/browserShop.service";
import { queryKeys } from "./queryKeys";

const TERMINAL = new Set([
  "CONFIRMED",
  "EXPIRED",
  "CANCELED",
  "FAILED",
]);

export function useBrowserShopAccessKey() {
  return useMutation({ mutationFn: createBrowserShopAccessKey });
}

export function useBrowserShopBootstrap(token: string) {
  return useQuery({
    queryKey: queryKeys.browserShop.bootstrap(token),
    queryFn: () => getBrowserShopBootstrap(token),
    staleTime: 5_000,
  });
}

export function useBrowserShopCatalog() {
  return useQuery({
    queryKey: queryKeys.browserShop.catalog,
    queryFn: getBrowserShopCatalog,
    staleTime: 30_000,
  });
}

export function useBrowserShopIntentStatus(
  token: string,
  intentId: number | null,
) {
  return useQuery({
    queryKey: queryKeys.browserShop.intentStatus(token, intentId || 0),
    enabled: Boolean(token && intentId),
    queryFn: () => getBrowserShopIntentStatus({
      token,
      intentId: intentId || 0,
    }),
    refetchInterval: (query) => {
      const raw = String(query.state.data?.status || "").toUpperCase();
      return TERMINAL.has(raw) ? false : 5_000;
    },
    refetchIntervalInBackground: true,
  });
}

export function useBrowserShopCreateIntent(token: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: createBrowserShopIntent,
    onSuccess: async (result) => {
      await Promise.all([
        queryClient.invalidateQueries({
          queryKey: queryKeys.browserShop.bootstrap(token),
        }),
        queryClient.invalidateQueries({
          queryKey: queryKeys.browserShop.intentStatus(
            token,
            result.intent_id,
          ),
        }),
      ]);
    },
  });
}
