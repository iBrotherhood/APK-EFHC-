import {
  useInfiniteQuery,
  useMutation,
  useQuery,
  useQueryClient,
} from "@tanstack/react-query";

import { useAuthOwnerGlobalId } from "../auth/AuthSessionProvider";
import {
  deleteWallet,
  getProfileBalanceHistoryPage,
  getProfileWallets,
  getProfileWithdrawHistoryPage,
  makePrimaryWallet,
} from "../services/profile.service";
import { queryKeys } from "./queryKeys";

export function useProfileWallets(_legacyTgId: number | null) {
  const globalId = useAuthOwnerGlobalId();
  return useQuery({
    queryKey: queryKeys.profile.wallets(globalId),
    enabled: Boolean(globalId),
    queryFn: ({ signal }) => getProfileWallets(signal),
    staleTime: 10_000,
  });
}

export function useProfileBalanceHistory(
  _legacyTgId: number | null,
  enabled: boolean,
) {
  const globalId = useAuthOwnerGlobalId();
  return useInfiniteQuery({
    queryKey: queryKeys.profile.balanceHistory(globalId),
    enabled: Boolean(globalId) && enabled,
    initialPageParam: null as string | null,
    queryFn: ({ pageParam, signal }) => (
      getProfileBalanceHistoryPage({
        cursor: pageParam,
        signal,
      })
    ),
    getNextPageParam: (lastPage) => (
      lastPage.next_cursor ?? undefined
    ),
  });
}

export function useProfileWithdrawHistory(
  _legacyTgId: number | null,
  enabled: boolean,
) {
  const globalId = useAuthOwnerGlobalId();
  return useInfiniteQuery({
    queryKey: queryKeys.profile.withdrawHistory(globalId),
    enabled: Boolean(globalId) && enabled,
    initialPageParam: null as string | null,
    queryFn: ({ pageParam, signal }) => (
      getProfileWithdrawHistoryPage({
        cursor: pageParam,
        signal,
      })
    ),
    getNextPageParam: (lastPage) => (
      lastPage.next_cursor ?? undefined
    ),
  });
}

type ProfileWalletAction =
  | { kind: "make-primary"; walletId: number | string }
  | { kind: "remove"; walletId: number | string };

export function useProfileWalletActions(_legacyTgId: number | null) {
  const globalId = useAuthOwnerGlobalId();
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (action: ProfileWalletAction) => {
      if (action.kind === "make-primary") {
        return await makePrimaryWallet(action.walletId);
      }
      return await deleteWallet(action.walletId);
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({
        queryKey: queryKeys.profile.wallets(globalId),
      });
    },
  });
}
