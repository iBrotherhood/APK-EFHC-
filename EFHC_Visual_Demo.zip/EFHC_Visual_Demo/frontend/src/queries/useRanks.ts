import {
  useInfiniteQuery,
  useQuery,
  useQueryClient,
} from "@tanstack/react-query";

import { useAuthOwnerGlobalId } from "../auth/AuthSessionProvider";
import {
  getMyRankWithTop,
  getRankTopPage,
} from "../services/ranks.service";
import { queryKeys } from "./queryKeys";

export function useMyRankWithTop(_legacyTgId: number | null) {
  const globalId = useAuthOwnerGlobalId();
  return useQuery({
    queryKey: queryKeys.ranks.myPlusTop(globalId),
    enabled: Boolean(globalId),
    queryFn: ({ signal }) => getMyRankWithTop(signal),
    staleTime: 30_000,
  });
}

export function useRankTopPages(
  _legacyTgId: number | null,
  firstCursor: string | null | undefined,
) {
  const globalId = useAuthOwnerGlobalId();
  return useInfiniteQuery({
    queryKey: queryKeys.ranks.top(globalId),
    enabled: Boolean(globalId && firstCursor),
    initialPageParam: firstCursor ?? null,
    queryFn: ({ pageParam, signal }) => {
      if (!pageParam) {
        return Promise.resolve({
          snapshot_at: "",
          items: [],
          next_cursor: null,
        });
      }
      return getRankTopPage({ cursor: pageParam, signal });
    },
    getNextPageParam: (lastPage) => lastPage.next_cursor ?? undefined,
  });
}

export function useRefreshRanks(_legacyTgId: number | null) {
  const globalId = useAuthOwnerGlobalId();
  const queryClient = useQueryClient();
  return async () => {
    await Promise.all([
      queryClient.invalidateQueries({
        queryKey: queryKeys.ranks.myPlusTop(globalId),
      }),
      queryClient.invalidateQueries({
        queryKey: queryKeys.ranks.top(globalId),
      }),
    ]);
  };
}
