import React from "react";
import { useT } from "../../../hooks/useT";
import type {
  WalletConnectionPhase,
} from "../../../lib/wallet-provider";
import { Button } from "../../ui/Button";
import {
  hapticSelection,
  hapticSoft,
} from "../../../lib/telegram";

type WalletView = {
  name: string;
  appName: string | null;
  imageUrl: string | null;
  aboutUrl: string | null;
  embedded: boolean;
  injected: boolean;
};

type Props = {
  connected: boolean;
  restoring: boolean;
  proofAccepted: boolean;
  connectionPhase: WalletConnectionPhase;
  walletHint?: string | null;
  recommendedWallets: WalletView[];
  onConnect: () => void;
  onDisconnectSession: () => void;
  hapticsEnabled: boolean;
};

function phaseLabel(
  phase: WalletConnectionPhase,
  t: (key: string) => string,
): string {
  const key = `wallet.phase_${phase}`;
  return t(key);
}

export function WalletConnectBanner(props: Props) {
  const t = useT();
  const title = props.connected
    ? t("wallet.session_connected")
    : t("wallet.connect_button");
  const desc = props.restoring
    ? t("wallet.session_restoring")
    : props.connected
      ? t("wallet.connection_ready")
      : t("wallet.connection_needed");
  const busy = [
    "restoring",
    "connecting",
    "verifying",
  ].includes(props.connectionPhase);

  return (
    <div
      className="efhc-wallet-card"
      data-wallet-provider-phase={props.connectionPhase}
      data-wallet-provider-ux="restore-proof-reject"
      data-tonconnect-phase={props.connectionPhase}
      data-tonconnect-wallet-ux="restore-proof-reject"
    >
      <div className="min-w-0 flex-1 space-y-1.5">
        <div className="efhc-wallet-card_title">{title}</div>
        <div className="efhc-wallet-card_desc">{desc}</div>
        <div
          className={
            "efhc-tonconnect-phase "
            + `is-${props.connectionPhase}`
          }
          role="status"
          aria-live="polite"
        >
          <span aria-hidden="true" />
          {phaseLabel(props.connectionPhase, t)}
        </div>
        <ol
          className="efhc-wallet-progress-rail"
          data-wallet-progress-rail="connect-verify-ready"
        >
          {[
            {
              id: "connect",
              label: t("wallet.rail_connect"),
              active: !["disconnected"].includes(
                props.connectionPhase,
              ),
            },
            {
              id: "verify",
              label: t("wallet.rail_verify"),
              active: [
                "verifying",
                "connected",
              ].includes(props.connectionPhase),
            },
            {
              id: "ready",
              label: t("wallet.rail_ready"),
              active: props.connectionPhase === "connected",
            },
          ].map((step, index) => (
            <li
              key={step.id}
              data-active={step.active ? "true" : "false"}
              data-rejected={
                props.connectionPhase === "rejected"
                  ? "true"
                  : "false"
              }
            >
              <span>{index + 1}</span>
              <small>{step.label}</small>
            </li>
          ))}
        </ol>
        {props.proofAccepted ? (
          <div className="text-xs text-[color:var(--tg-hint)]">
            {t("wallet.proof_received")}
          </div>
        ) : null}
        {props.walletHint ? (
          <div className="text-xs text-[color:var(--tg-hint)]">
            {props.walletHint}
          </div>
        ) : null}
        {props.recommendedWallets.length ? (
          <div className="text-xs text-[color:var(--tg-hint)]">
            {t("wallet.recommended_wallets")}: {
              props.recommendedWallets
                .map((item) => item.name)
                .join(", ")
            }
          </div>
        ) : null}
      </div>
      <div className="efhc-wallet-card_actions">
        {props.connected ? (
          <>
            <Button
              variant="secondary"
              onClick={() => {
                hapticSoft(props.hapticsEnabled);
                props.onDisconnectSession();
              }}
            >
              {t("wallet.disconnect_session")}
            </Button>
            <Button
              variant="secondary"
              onClick={() => {
                hapticSelection(props.hapticsEnabled);
                window.location.assign(
                  "/faq?section=5&subsection=5.1",
                );
              }}
            >
              {t("wallet.faq_button")}
            </Button>
          </>
        ) : (
          <Button
            disabled={busy}
            data-wallet-provider-action="connect"
            data-tonconnect-action="connect"
            onClick={() => {
              hapticSelection(props.hapticsEnabled);
              props.onConnect();
            }}
          >
            {busy
              ? t("wallet.connection_waiting")
              : t("wallet.connect_button")}
          </Button>
        )}
      </div>
    </div>
  );
}
