import React from "react";
import { useT } from "../../../hooks/useT";
import { TelegramSectionRow } from "../../ui/telegram/TelegramSectionRow";
import { TelegramStatusBadge } from "../../ui/telegram/TelegramStatusBadge";
import type { WalletListItemModel } from "./WalletListItem";

type Props = {
  wallet: WalletListItemModel | null;
};

function shortAddress(address: string): string {
  if (address.length <= 22) return address;
  return `${address.slice(0, 10)}…${address.slice(-10)}`;
}

export function WalletPrimaryCard(props: Props) {
  const t = useT();
  const right = props.wallet ? (
    <div className="flex flex-wrap items-center justify-end gap-1.5">
      <TelegramStatusBadge
        label={t("wallet.primary_badge")}
        tone="primary"
      />
      <TelegramStatusBadge
        label={
          props.wallet.is_active
            ? t("wallet.status_connected")
            : t("wallet.status_inactive")
        }
        tone={props.wallet.is_active ? "connected" : "inactive"}
      />
    </div>
  ) : undefined;

  return (
    <div className="space-y-2">
      <div className="text-xs font-semibold uppercase tracking-wide text-[color:var(--tg-hint)]">
        {t("wallet.primary_wallet")}
      </div>
      <TelegramSectionRow
        title={
          props.wallet
            ? shortAddress(props.wallet.wallet_address)
            : t("wallet.no_primary")
        }
        subtitle={
          props.wallet
            ? t("wallet.primary_desc")
            : t("wallet.primary_empty")
        }
        rightSlot={right}
      />
    </div>
  );
}
