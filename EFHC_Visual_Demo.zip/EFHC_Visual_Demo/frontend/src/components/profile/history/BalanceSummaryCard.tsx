import React from "react";
import { useT } from "../../../hooks/useT";
import { TelegramStatusBadge } from "../../ui/telegram/TelegramStatusBadge";

type Props = {
  title: string;
  value: string;
  tone: "neutral" | "main" | "bonus";
};

export function BalanceSummaryCard(props: Props) {
  const t = useT();
  const toneLabel =
    props.tone === "main"
      ? t("balances.main")
      : props.tone === "bonus"
      ? t("balances.bonus")
      : t("balances.total");
  return (
    <div className="efhc-history-summary-card">
      <div className="flex items-center justify-between gap-3">
        <div className="text-xs text-[color:var(--tg-hint)]">
          {props.title}
        </div>
        <TelegramStatusBadge label={toneLabel} tone={props.tone} />
      </div>
      <div className="mt-2 text-base font-semibold tabular-nums">
        {props.value} EFHC
      </div>
    </div>
  );
}
