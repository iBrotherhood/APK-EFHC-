import React from "react";
import { useT } from "../../../hooks/useT";
import { BalanceHistoryEmptyState } from "./BalanceHistoryEmptyState";
import {
  BalanceHistoryItem,
  type BalanceHistoryModel,
} from "./BalanceHistoryItem";
import { BalanceHistoryLoadMore } from "./BalanceHistoryLoadMore";

type Props = {
  items: BalanceHistoryModel[];
  loading: boolean;
  nextCursor: string | null;
  onLoadMore: () => void;
  reasonLabel: (reason: string) => string;
};

export function BalanceHistoryList(props: Props) {
  const t = useT();
  if (props.loading && props.items.length === 0) {
    return (
      <div className="text-xs text-[color:var(--tg-hint)]">
        {t("history.loading_items")}
      </div>
    );
  }
  if (!props.loading && props.items.length === 0) {
    return <BalanceHistoryEmptyState />;
  }
  return (
    <div className="efhc-history-list">
      {props.items.map((item) => (
        <div className="efhc-native-virtual-item" key={item.id}>
          <BalanceHistoryItem
            item={item}
            reasonLabel={props.reasonLabel}
          />
        </div>
      ))}
      {props.nextCursor ? (
        <BalanceHistoryLoadMore onLoadMore={props.onLoadMore} />
      ) : null}
    </div>
  );
}
