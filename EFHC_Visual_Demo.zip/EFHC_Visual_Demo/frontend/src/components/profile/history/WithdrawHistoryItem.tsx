import React from "react";
import { useT } from "../../../hooks/useT";
import { TelegramStatusBadge } from "../../ui/telegram/TelegramStatusBadge";

export type WithdrawHistoryModel = {
  id: number;
  tg_id: number;
  amount: string;
  status: string;
  created_at: string;
  updated_at: string;
};

type Props = {
  item: WithdrawHistoryModel;
};

function statusTone(status: string):
  | "connected"
  | "warning"
  | "neutral"
  | "bonus"
  | "main" {
  if (status === "PAID") return "connected";
  if (status === "PENDING") return "warning";
  return "neutral";
}

function formatDateTime(value: string): string {
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return value;
  return parsed.toLocaleString();
}

export function WithdrawHistoryItem(props: Props) {
  const t = useT();
  const { item } = props;
  const statusMap: Record<string, string> = {
    PENDING: t("withdraw.status_pending"),
    PAID: t("withdraw.status_paid"),
    REJECTED: t("withdraw.status_rejected"),
    CANCELED: t("withdraw.status_canceled"),
  };
  return (
    <div className="efhc-history-row efhc-history-row--withdraw">
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          <div className="font-medium break-words">
            {t("withdraw.request_number").replace(
              "{id}",
              String(item.id),
            )}
          </div>
          <TelegramStatusBadge
            label={t("withdraw.request_badge")}
            tone="main"
          />
          <TelegramStatusBadge
            label={statusMap[item.status] || item.status}
            tone={statusTone(item.status)}
          />
        </div>
        <div className="mt-1 text-xs text-[color:var(--tg-hint)]">
          {t("withdraw.created_at")}: {formatDateTime(item.created_at)}
        </div>
        <div className="mt-1 text-xs text-[color:var(--tg-hint)]">
          {t("withdraw.updated_at")}: {formatDateTime(item.updated_at)}
        </div>
      </div>
      <div className="text-right shrink-0">
        <div className="text-sm font-semibold tabular-nums">
          −{item.amount} EFHC
        </div>
      </div>
    </div>
  );
}
