import React from "react";
import { useT } from "../../../hooks/useT";
import { TelegramStatusBadge } from "../../ui/telegram/TelegramStatusBadge";

export type BalanceHistoryModel = {
  id: number;
  amount_efhc: string;
  direction: "credit" | "debit";
  balance_type: "main" | "bonus";
  reason: string;
  created_at: string;
};

type Props = {
  item: BalanceHistoryModel;
  reasonLabel: (reason: string) => string;
};

function amountPrefix(direction: "credit" | "debit"): string {
  return direction === "credit" ? "+" : "−";
}

function formatDateTime(value: string): string {
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return value;
  return parsed.toLocaleString();
}

export function BalanceHistoryItem(props: Props) {
  const t = useT();
  const { item } = props;
  const directionTone =
    item.direction === "credit" ? "connected" : "warning";
  const accountTone =
    item.balance_type === "bonus" ? "bonus" : "main";
  return (
    <div className="efhc-history-row">
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          <div className="font-medium break-words">
            {props.reasonLabel(item.reason)}
          </div>
          <TelegramStatusBadge
            label={
              item.direction === "credit"
                ? t("history.credit")
                : t("history.debit")
            }
            tone={directionTone}
          />
          <TelegramStatusBadge
            label={
              item.balance_type === "bonus"
                ? t("balances.bonus")
                : t("balances.main")
            }
            tone={accountTone}
          />
        </div>
        <div className="mt-1 text-xs text-[color:var(--tg-hint)]">
          #{item.id} · {formatDateTime(item.created_at)}
        </div>
      </div>
      <div className="text-right shrink-0">
        <div className="text-sm font-semibold tabular-nums">
          {amountPrefix(item.direction)}{item.amount_efhc} EFHC
        </div>
      </div>
    </div>
  );
}
