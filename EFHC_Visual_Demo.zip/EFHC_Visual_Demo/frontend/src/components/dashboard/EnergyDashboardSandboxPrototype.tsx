import Link from "next/link";
import React, { useMemo, useState } from "react";

import {
  SimActivityStrip,
  SimDashboardGrid,
  SimDashboardSection,
  SimDashboardShell,
  SimDashboardToolbar,
  SimFreshnessBadge,
  SimHeroEnergyCard,
  SimMiniAreaChart,
  SimMiniBarChart,
  SimMiniSparkline,
  SimPanelChrome,
  SimPeriodSwitch,
  SimSegmentedProgress,
  SimStatCard,
  SimStatusPill,
} from "./SimulationDashboardUiKit";

import type { DashboardMiniChartPoint } from "./MiniCharts";

type EnergySandboxPeriod = "24h" | "7d" | "30d";

type EnergySandboxPrototypeProps = {
  initialPeriod?: EnergySandboxPeriod;
};

type EnergySandboxPreview = {
  heroValue: string;
  generationRate: string;
  availableKwh: string;
  efhcBalance: string;
  activePanels: string;
  rankProgress: number;
  nextRank: string;
  nextAction: string;
  trend: DashboardMiniChartPoint[];
  bars: DashboardMiniChartPoint[];
  activity: DashboardMiniChartPoint[];
};

const periodOptions = [
  {
    key: "24h",
    label: "24ч",
    description: "Короткий период для live feeling",
  },
  {
    key: "7d",
    label: "7д",
    description: "Недельный рост энергии",
  },
  {
    key: "30d",
    label: "30д",
    description: "Месячная динамика портфеля",
  },
];

const energySandboxPreviewByPeriod: Record<
  EnergySandboxPeriod,
  EnergySandboxPreview
> = {
  "24h": {
    heroValue: "184.23000000",
    generationRate: "+0.0042 kWh/s",
    availableKwh: "72.50000000",
    efhcBalance: "72.50000000 EFHC",
    activePanels: "3",
    rankProgress: 68,
    nextRank: "Rank 4",
    nextAction: "Активировать ещё одну панель",
    trend: [
      { id: "00", label: "00:00", value: 120 },
      { id: "04", label: "04:00", value: 128 },
      { id: "08", label: "08:00", value: 141 },
      { id: "12", label: "12:00", value: 161 },
      { id: "16", label: "16:00", value: 175 },
      { id: "20", label: "20:00", value: 184 },
    ],
    bars: [
      { id: "available", label: "Доступно", value: 72, tone: "success" },
      { id: "locked", label: "В панели", value: 100, tone: "info" },
      { id: "rank", label: "Ранг", value: 68, tone: "warning" },
    ],
    activity: [
      { id: "a", label: "Панели", value: 1, tone: "success" },
      { id: "b", label: "Рост", value: 1, tone: "info" },
      { id: "c", label: "Обмен", value: 0, tone: "neutral" },
      { id: "d", label: "Ранг", value: 1, tone: "warning" },
      { id: "e", label: "Задания", value: 1, tone: "success" },
    ],
  },
  "7d": {
    heroValue: "934.90000000",
    generationRate: "+0.0038 kWh/s avg",
    availableKwh: "310.25000000",
    efhcBalance: "310.25000000 EFHC",
    activePanels: "5",
    rankProgress: 74,
    nextRank: "Rank 5",
    nextAction: "Обменять kWh → EFHC 1:1",
    trend: [
      { id: "d1", label: "Пн", value: 420 },
      { id: "d2", label: "Вт", value: 492 },
      { id: "d3", label: "Ср", value: 570 },
      { id: "d4", label: "Чт", value: 655 },
      { id: "d5", label: "Пт", value: 745 },
      { id: "d6", label: "Сб", value: 840 },
      { id: "d7", label: "Вс", value: 934 },
    ],
    bars: [
      { id: "available", label: "Доступно", value: 310, tone: "success" },
      { id: "lifetime", label: "Всего", value: 934, tone: "info" },
      { id: "rank", label: "Ранг", value: 74, tone: "warning" },
    ],
    activity: [
      { id: "a", label: "Панели", value: 1, tone: "success" },
      { id: "b", label: "Рост", value: 1, tone: "info" },
      { id: "c", label: "Обмен", value: 1, tone: "success" },
      { id: "d", label: "Ранг", value: 1, tone: "warning" },
      { id: "e", label: "Задания", value: 1, tone: "success" },
    ],
  },
  "30d": {
    heroValue: "3 842.70000000",
    generationRate: "+0.0035 kWh/s avg",
    availableKwh: "1 208.00000000",
    efhcBalance: "1 208.00000000 EFHC",
    activePanels: "8",
    rankProgress: 81,
    nextRank: "Rank 6",
    nextAction: "Усилить портфель панелей",
    trend: [
      { id: "w1", label: "Нед. 1", value: 900 },
      { id: "w2", label: "Нед. 2", value: 1700 },
      { id: "w3", label: "Нед. 3", value: 2810 },
      { id: "w4", label: "Нед. 4", value: 3842 },
    ],
    bars: [
      { id: "available", label: "Доступно", value: 1208, tone: "success" },
      { id: "lifetime", label: "Всего", value: 3842, tone: "info" },
      { id: "rank", label: "Ранг", value: 81, tone: "warning" },
    ],
    activity: [
      { id: "a", label: "Панели", value: 1, tone: "success" },
      { id: "b", label: "Рост", value: 1, tone: "info" },
      { id: "c", label: "Обмен", value: 1, tone: "success" },
      { id: "d", label: "Ранг", value: 1, tone: "warning" },
      { id: "e", label: "Задания", value: 1, tone: "success" },
    ],
  },
};

function isEnergySandboxPeriod(value: string): value is EnergySandboxPeriod {
  return value === "24h" || value === "7d" || value === "30d";
}

export function EnergyDashboardSandboxPrototype(
  props: EnergySandboxPrototypeProps,
) {
  const [period, setPeriod] = useState<EnergySandboxPeriod>(
    props.initialPeriod ?? "7d",
  );
  const preview = energySandboxPreviewByPeriod[period];
  const segments = useMemo(
    () => [
      {
        id: "energy",
        label: "Энергия",
        value: preview.rankProgress,
        tone: "success" as const,
      },
      {
        id: "panels",
        label: "Панели",
        value: Number(preview.activePanels) * 10,
        tone: "info" as const,
      },
      {
        id: "tasks",
        label: "Задания",
        value: 62,
        tone: "warning" as const,
      },
    ],
    [preview.activePanels, preview.rankProgress],
  );

  const changePeriod = (next: string) => {
    if (isEnergySandboxPeriod(next)) setPeriod(next);
  };

  return (
    <SimDashboardShell
      title="Energy Dashboard screen draft"
      subtitle="internal stand-only preview: визуальный образ Energy без изменения current mode truth"
      contract={{
        id: "energy-dashboard-sandbox-prototype-1467",
        title: "Energy Dashboard internal stand screen draft",
        source: {
          label: "synthetic_preview / internal stand-only",
          dataKind: "synthetic_preview",
          synthetic: true,
        },
        state: {
          status: "success",
          message: "internal stand visual screen draft",
          freshness: "unknown",
        },
        mode: "simulation",
      }}
    >
      <div
        className="efhc-energy-dashboard-sandbox"
        data-energy-dashboard-sandbox-prototype="1467"
        data-energy-dashboard-data-kind="synthetic_preview"
        data-energy-dashboard-preview-only="true"
        data-grafana-reference-only="true"
        data-sandbox-reference-only="true"
      >
        <SimDashboardToolbar
          title="Энергия"
          subtitle="Баланс, генерация, панели и следующий шаг в одном визуальном экране"
          period={
            <SimPeriodSwitch
              label="Период"
              onChange={changePeriod}
              options={periodOptions}
              value={period}
            />
          }
          freshness={
            <SimFreshnessBadge
              freshness="unknown"
              label="Preview"
              updatedAt="internal stand generated"
            />
          }
          actions={<SimStatusPill label="truth-safe preview" tone="info" />}
        />

        <SimHeroEnergyCard
          title="Накопленная энергия"
          value={preview.heroValue}
          unit="kWh"
          subtitle="Главный экран показывает энергию как живой портфель, но данные здесь demo-preview."
          progressLabel={`Прогресс до ${preview.nextRank}`}
          progressValue={preview.rankProgress}
          actions={
            <div className="efhc-energy-dashboard-sandbox__actions">
              <Link href="/panels">Панели</Link>
              <Link href="/exchange">Exchange 1:1</Link>
            </div>
          }
        />

        <div className="efhc-energy-dashboard-sandbox__kpi-strip">
          <SimStatCard
            label="Активные панели"
            value={preview.activePanels}
            hint="portfolio signal"
            tone="success"
          />
          <SimStatCard
            label="Доступно к обмену"
            value={preview.availableKwh}
            hint="kWh → EFHC только 1:1"
            tone="info"
          />
          <SimStatCard
            label="EFHC balance"
            value={preview.efhcBalance}
            hint="без P2P user transfer"
            tone="warning"
          />
          <SimStatCard
            label="Скорость"
            value={preview.generationRate}
            hint="derived visual metric"
            tone="neutral"
          />
        </div>

        <SimDashboardGrid>
          <SimPanelChrome
            title="Рост энергии"
            subtitle="product dashboard BigValue + Sparkline дисциплина, EFHC-owned SVG"
            status="success"
            statusLabel="preview"
            tone="success"
            source="synthetic_preview / internal stand"
            updatedAt="not current mode"
          >
            <SimMiniAreaChart
              ariaLabel="generated energy growth preview"
              dataKind="synthetic_preview"
              label="kWh trend"
              points={preview.trend}
              source="internal stand only"
              synthetic
              tone="success"
              unit="kWh"
            />
          </SimPanelChrome>

          <SimPanelChrome
            title="Структура Energy"
            subtitle="BigValue cards + mini bars для быстрого понимания"
            status="success"
            statusLabel="preview"
            tone="info"
            source="synthetic_preview / internal stand"
            updatedAt="not current mode"
          >
            <SimMiniBarChart
              ariaLabel="generated energy split preview"
              dataKind="synthetic_preview"
              label="Energy split"
              points={preview.bars}
              source="internal stand only"
              synthetic
              tone="info"
              unit="kWh"
            />
          </SimPanelChrome>

          <SimPanelChrome
            title="Следующая цель"
            subtitle="Progress system показывает путь без выдуманной экономики"
            status="success"
            statusLabel={preview.nextRank}
            tone="warning"
            source="derived from preview data"
            updatedAt="not current mode"
          >
            <SimSegmentedProgress
              dataKind="synthetic_preview"
              label="Energy / panels / tasks"
              segments={segments}
              source="internal stand only"
              synthetic
            />
            <p className="efhc-energy-dashboard-sandbox__next-action">
              {preview.nextAction}
            </p>
          </SimPanelChrome>

          <SimPanelChrome
            title="Activity strip"
            subtitle="StatusHistory/StateTimeline discipline без product dashboard current mode"
            status="success"
            statusLabel="preview"
            tone="neutral"
            source="synthetic_preview / internal stand"
            updatedAt="not current mode"
          >
            <SimActivityStrip
              ariaLabel="generated energy activity preview"
              dataKind="synthetic_preview"
              label="Recent signals"
              points={preview.activity}
              source="internal stand only"
              synthetic
              tone="neutral"
            />
            <SimMiniSparkline
              ariaLabel="generated compact energy sparkline"
              dataKind="synthetic_preview"
              label="Compact sparkline"
              points={preview.trend}
              source="internal stand only"
              synthetic
              tone="success"
              unit="kWh"
            />
          </SimPanelChrome>
        </SimDashboardGrid>

        <SimDashboardSection
          title="Правила прототипа"
          subtitle="Этот слой проектирует будущий Energy current mode port, но не меняет текущий экран."
        >
          <div className="efhc-energy-dashboard-sandbox__rules">
            <span>source/derived/generated явно маркируются</span>
            <span>CTA только Panels и Exchange</span>
            <span>экономика 1 EFHC = 1 kWh сохранена</span>
            <span>Grafana = visual discipline only</span>
          </div>
        </SimDashboardSection>
      </div>
    </SimDashboardShell>
  );
}

export const energyDashboardSandboxPrototypeVersion =
  "EFHC_ENERGY_DASHBOARD_SANDBOX_PROTOTYPE_V1";
