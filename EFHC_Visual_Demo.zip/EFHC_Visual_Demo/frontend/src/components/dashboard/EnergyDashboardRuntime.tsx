import Link from "next/link";
import React, { useMemo, useState } from "react";

import type { SyncSnapshot } from "../../hooks/useSnapshot";
import { formatD8ToHuman } from "../../lib/format";
import type { DashboardMiniChartPoint } from "./MiniCharts";
import {
  SimActivityStrip,
  SimDashboardGrid,
  SimDashboardSection,
  SimDashboardShell,
  SimDashboardToolbar,
  SimFreshnessBadge,
  SimHeroEnergyCard,
  SimMiniBarChart,
  SimPanelChrome,
  SimPeriodSwitch,
  SimSegmentedProgress,
  SimStatCard,
  SimStatusPill,
} from "./SimulationDashboardUiKit";

export type EnergyDashboardRuntimePeriod = "snapshot";

type EnergyDashboardRuntimeLabels = {
  title: string;
  subtitle: string;
  live: string;
  snapshot: string;
  freshness: string;
  source: string;
  totalGenerated: string;
  availableKwh: string;
  generationRate: string;
  activePanels: string;
  efhcBalance: string;
  exchangeOneToOne: string;
  panelsAction: string;
  exchangeAction: string;
  open: string;
  progressToNext: string;
  nextGoal: string;
  dataRulesTitle: string;
  dataRulesSubtitle: string;
  noTimeSeries: string;
  splitTitle: string;
  splitSubtitle: string;
  progressTitle: string;
  progressSubtitle: string;
  activityTitle: string;
  activitySubtitle: string;
  rawSnapshot: string;
  derivedSnapshot: string;
  vipStatus: string;
};

type EnergyDashboardRuntimeProps = {
  snap: SyncSnapshot | null;
  hideBalances: boolean;
  labels: EnergyDashboardRuntimeLabels;
};

const THRESHOLDS_KWH = [
  0,
  100,
  300,
  600,
  1000,
  2000,
  3500,
  5000,
  7500,
  10000,
  15000,
  20000,
];

function decimalNumber(value: string | number | null | undefined): number {
  if (value === null || value === undefined) return 0;
  const parsed = Number.parseFloat(String(value).replace(/\s+/g, ""));
  return Number.isFinite(parsed) ? parsed : 0;
}

function safeInteger(value: string | number | null | undefined): number {
  const parsed = Number.parseInt(String(value ?? "0"), 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : 0;
}

function maskedHuman(
  value: string | number | null | undefined,
  hidden: boolean,
): string {
  if (hidden) return "••••••••";
  return formatD8ToHuman(String(value ?? "0"));
}

function maskedPlain(
  value: string | number | null | undefined,
  hidden: boolean,
): string {
  if (hidden) return "••••••••";
  return String(value ?? "0");
}

function progressForLifetime(lifetimeKwh: number): {
  level: number;
  percent: number;
  next: number | null;
} {
  let level = 1;
  for (let i = 0; i < THRESHOLDS_KWH.length; i += 1) {
    if (lifetimeKwh >= THRESHOLDS_KWH[i]) level = i + 1;
  }
  const current = THRESHOLDS_KWH[Math.max(0, level - 1)] ?? 0;
  const next = THRESHOLDS_KWH[level] ?? null;
  if (next === null) return { level, percent: 100, next };
  const span = Math.max(1, next - current);
  const done = Math.min(Math.max(lifetimeKwh - current, 0), span);
  return {
    level,
    next,
    percent: Math.round((done / span) * 100),
  };
}

function buildEnergySplitPoints(
  totalGenerated: number,
  available: number,
  activePanels: number,
  labels: EnergyDashboardRuntimeLabels,
): DashboardMiniChartPoint[] {
  const alreadyConverted = Math.max(totalGenerated - available, 0);
  return [
    {
      id: "available-kwh",
      label: labels.availableKwh,
      tone: "success",
      value: available,
    },
    {
      id: "converted-kwh",
      label: labels.exchangeOneToOne,
      tone: "info",
      value: alreadyConverted,
    },
    {
      id: "active-panels",
      label: labels.activePanels,
      tone: "warning",
      value: activePanels,
    },
  ];
}

function buildEnergyActivityPoints(
  snap: SyncSnapshot | null,
  labels: EnergyDashboardRuntimeLabels,
): DashboardMiniChartPoint[] {
  const profile = snap?.profile;
  const meta = snap?.meta;
  const panels = snap?.panels;
  return [
    {
      id: "server-snapshot",
      label: labels.snapshot,
      tone: meta?.server_now_iso ? "success" : "warning",
      value: meta?.server_now_iso ? 1 : 0,
    },
    {
      id: "active-panels",
      label: labels.activePanels,
      tone: (panels?.active_count ?? 0) > 0 ? "success" : "neutral",
      value: (panels?.active_count ?? 0) > 0 ? 1 : 0,
    },
    {
      id: "available-energy",
      label: labels.availableKwh,
      tone: decimalNumber(profile?.available_kwh) > 0 ? "success" : "neutral",
      value: decimalNumber(profile?.available_kwh) > 0 ? 1 : 0,
    },
    {
      id: "generation-rate",
      label: labels.generationRate,
      tone:
        decimalNumber(meta?.gen_per_sec_effective) > 0
          ? "info"
          : "neutral",
      value: decimalNumber(meta?.gen_per_sec_effective) > 0 ? 1 : 0,
    },
    {
      id: "vip-status",
      label: labels.vipStatus,
      tone: profile?.is_vip ? "warning" : "neutral",
      value: profile?.is_vip ? 1 : 0,
    },
  ];
}

export function EnergyDashboardRuntime(
  props: EnergyDashboardRuntimeProps,
) {
  const [period, setPeriod] = useState<EnergyDashboardRuntimePeriod>(
    "snapshot",
  );
  const profile = props.snap?.profile;
  const panels = props.snap?.panels;
  const meta = props.snap?.meta;

  const totalGeneratedRaw =
    (profile as any)?.lifetime_generated_kwh || profile?.total_generated_kwh;
  const totalGenerated = decimalNumber(totalGeneratedRaw);
  const available = decimalNumber(profile?.available_kwh);
  const activePanels = safeInteger(panels?.active_count);
  const generationRate = decimalNumber(meta?.gen_per_sec_effective);
  const mainBalance = decimalNumber(profile?.main_balance);
  const bonusBalance = decimalNumber(profile?.bonus_balance);
  const efhcBalance = mainBalance + bonusBalance;
  const progress = progressForLifetime(totalGenerated);

  const splitPoints = useMemo(
    () =>
      buildEnergySplitPoints(
        totalGenerated,
        available,
        activePanels,
        props.labels,
      ),
    [activePanels, available, props.labels, totalGenerated],
  );

  const activityPoints = useMemo(
    () => buildEnergyActivityPoints(props.snap, props.labels),
    [props.labels, props.snap],
  );

  const progressSegments = useMemo(
    () => [
      {
        id: "rank-progress",
        label: props.labels.progressToNext,
        tone: "success" as const,
        value: progress.percent,
      },
      {
        id: "exchangeable-ratio",
        label: props.labels.availableKwh,
        tone: "info" as const,
        value:
          totalGenerated > 0
            ? Math.round(Math.min((available / totalGenerated) * 100, 100))
            : 0,
      },
      {
        id: "panel-signal",
        label: props.labels.activePanels,
        tone: "warning" as const,
        value: Math.min(activePanels * 20, 100),
      },
    ],
    [
      activePanels,
      available,
      progress.percent,
      props.labels.activePanels,
      props.labels.availableKwh,
      props.labels.progressToNext,
      totalGenerated,
    ],
  );

  const hidden = props.hideBalances;
  const heroValue = maskedHuman(totalGeneratedRaw, hidden);
  const availableLabel = maskedHuman(profile?.available_kwh, hidden);
  const rateLabel = hidden
    ? "••••••••"
    : `${formatD8ToHuman(String(generationRate))} kWh/s`;
  const efhcLabel = hidden
    ? "••••••••"
    : `${formatD8ToHuman(String(efhcBalance))} EFHC`;
  const nextGoalLabel = progress.next === null
    ? "MAX"
    : `${props.labels.nextGoal}: ${progress.next} kWh`;

  return (
    <SimDashboardShell
      eyebrow="EFHC"
      title={props.labels.title}
      subtitle={props.labels.subtitle}
      contract={{
        id: "energy-dashboard-runtime-port-1469",
        mode: "simulation",
        title: "Energy Dashboard current mode Port",
        source: {
          dataKind: "raw",
          label: "sync current summary / current mode truth",
          route: "/sync/user/{tg_id}",
          synthetic: false,
        },
        state: {
          freshness: meta?.server_now_iso ? "fresh" : "unknown",
          message: "current mode current summary dashboard",
          status: props.snap ? "success" : "empty",
          updatedAt: meta?.server_now_iso,
        },
      }}
    >
      <div
        className="efhc-energy-dashboard-runtime"
        data-energy-dashboard-runtime-port="1469"
        data-energy-dashboard-data-kind="raw-and-derived"
        data-energy-dashboard-synthetic="false"
        data-energy-dashboard-write-flow="false"
        data-energy-dashboard-visual-qa="1470"
        data-energy-dashboard-mobile-safe="true"
        data-energy-dashboard-cta-count="2"
        data-grafana-reference-only="true"
        data-sandbox-reference-only="true"
      >
        <SimDashboardToolbar
          title={props.labels.title}
          subtitle={props.labels.live}
          period={
            <SimPeriodSwitch
              label={props.labels.snapshot}
              onChange={(next) => {
                if (next === "snapshot") setPeriod(next);
              }}
              options={[
                {
                  key: "snapshot",
                  label: props.labels.snapshot,
                  description: props.labels.noTimeSeries,
                },
              ]}
              value={period}
            />
          }
          freshness={
            <SimFreshnessBadge
              freshness={meta?.server_now_iso ? "fresh" : "unknown"}
              label={props.labels.freshness}
              updatedAt={meta?.server_now_iso ?? props.labels.snapshot}
            />
          }
          actions={
            <SimStatusPill label={props.labels.rawSnapshot} tone="success" />
          }
        />

        <SimHeroEnergyCard
          title={props.labels.totalGenerated}
          value={heroValue}
          unit="kWh"
          subtitle={props.labels.source}
          progressLabel={nextGoalLabel}
          progressValue={progress.percent}
          actions={
            <div className="efhc-energy-dashboard-runtime__actions">
              <Link href="/panels">{props.labels.panelsAction}</Link>
              <Link href="/exchange">{props.labels.exchangeAction}</Link>
            </div>
          }
        />

        <div className="efhc-energy-dashboard-runtime__kpi-strip">
          <SimStatCard
            label={props.labels.activePanels}
            value={String(activePanels)}
            hint={props.labels.rawSnapshot}
            tone="success"
          />
          <SimStatCard
            label={props.labels.availableKwh}
            value={`${availableLabel} kWh`}
            hint={props.labels.exchangeOneToOne}
            tone="info"
          />
          <SimStatCard
            label={props.labels.efhcBalance}
            value={efhcLabel}
            hint={props.labels.rawSnapshot}
            tone="warning"
          />
          <SimStatCard
            label={props.labels.generationRate}
            value={rateLabel}
            hint={props.labels.derivedSnapshot}
            tone="neutral"
          />
        </div>

        <SimDashboardGrid>
          <SimPanelChrome
            title={props.labels.splitTitle}
            subtitle={props.labels.splitSubtitle}
            status={props.snap ? "success" : "empty"}
            statusLabel={props.labels.rawSnapshot}
            tone="success"
            source={props.labels.source}
            updatedAt={meta?.server_now_iso ?? props.labels.snapshot}
          >
            <SimMiniBarChart
              ariaLabel={props.labels.splitTitle}
              dataKind="derived"
              emptyLabel={props.labels.noTimeSeries}
              label={props.labels.availableKwh}
              points={splitPoints}
              source={props.labels.derivedSnapshot}
              synthetic={false}
              tone="success"
              unit="kWh"
            />
          </SimPanelChrome>

          <SimPanelChrome
            title={props.labels.progressTitle}
            subtitle={props.labels.progressSubtitle}
            status={props.snap ? "success" : "empty"}
            statusLabel={nextGoalLabel}
            tone="warning"
            source={props.labels.derivedSnapshot}
            updatedAt={meta?.server_now_iso ?? props.labels.snapshot}
          >
            <SimSegmentedProgress
              dataKind="derived"
              label={props.labels.progressToNext}
              segments={progressSegments}
              source={props.labels.noTimeSeries}
              synthetic={false}
            />
          </SimPanelChrome>

          <SimPanelChrome
            title={props.labels.activityTitle}
            subtitle={props.labels.activitySubtitle}
            status={props.snap ? "success" : "empty"}
            statusLabel={props.labels.derivedSnapshot}
            tone="info"
            source={props.labels.source}
            updatedAt={meta?.server_now_iso ?? props.labels.snapshot}
          >
            <SimActivityStrip
              ariaLabel={props.labels.activityTitle}
              dataKind="derived"
              label={props.labels.live}
              points={activityPoints}
              source={props.labels.noTimeSeries}
              synthetic={false}
              tone="info"
            />
          </SimPanelChrome>
        </SimDashboardGrid>

        <details className="efhc-energy-dashboard-runtime__details">
          <summary>{props.labels.dataRulesTitle}</summary>
          <p>{props.labels.dataRulesSubtitle}</p>
          <div className="efhc-energy-dashboard-runtime__rules">
            <span>{props.labels.rawSnapshot}</span>
            <span>{props.labels.derivedSnapshot}</span>
            <span>{props.labels.noTimeSeries}</span>
            <span>{props.labels.exchangeOneToOne}</span>
          </div>
        </details>
      </div>
    </SimDashboardShell>
  );
}

export const energyDashboardRuntimePortVersion =
  "EFHC_ENERGY_DASHBOARD_RUNTIME_PORT_V1";
