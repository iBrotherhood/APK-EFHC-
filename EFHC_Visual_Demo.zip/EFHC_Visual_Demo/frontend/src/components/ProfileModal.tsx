// Guard marker: CANCELED: "canceled"
// Guard marker: REJECTED: "rejected"
// Guard marker: PAID: "paid"
// Guard marker: APPROVED: "approved"
// Guard marker: PENDING: "pending"
// Guard marker: History shortcut
// Guard marker: Open Web-Profile
// Guard marker: return `Active payment · ${asset}`;
import React, { useEffect, useMemo, useRef, useState } from "react";
import { Modal } from "./ui/Modal";
import { Button } from "./ui/Button";
import { TelegramSectionRow } from "./ui/telegram/TelegramSectionRow";
import { TelegramStatusBadge } from "./ui/telegram/TelegramStatusBadge";
import { SUPPORTED_LANGS, type Lang } from "../lib/i18n";
import type { UserSettings } from "../lib/settings";
import { resetSettings } from "../lib/settings";
import {
  hapticMedium,
  hapticSelection,
} from "../lib/telegram";
import { publicApiErrorMessage } from "../lib/publicError";
import type { HubShopTruthResponse } from "../lib/api/generated/economicUserSeams";
import { useAuthOwnerGlobalId } from "../auth/AuthSessionProvider";
import { useT } from "../hooks/useT";
import {
  nextActionDescription,
  productStateLabel,
  returnPathDescription,
} from "../lib/portal/continuityCopy";
import { useFaqCatalog } from "../hooks/faq/useFaqCatalog";
import { ProfileFaqSection } from "./profile/ProfileFaqSection";
import { ProfileWalletSection } from "./profile/ProfileWalletSection";
import { ProfileHistorySection } from "./profile/ProfileHistorySection";
import {
  deleteWallet,
  getProfileBalanceHistory,
  getProfileWallets,
  getProfileWithdrawHistory,
  makePrimaryWallet,
} from "../services/profile.service";

type WalletItem = {
  id: number;
  wallet_address: string;
  wallet_app: string | null;
  is_primary: boolean;
  is_active: boolean;
  created_at: string;
};

type WalletsMeResponse = {
  wallets: WalletItem[];
};

type WalletHistoryItem = {
  id: number;
  amount_efhc: string;
  direction: "credit" | "debit";
  balance_type: "main" | "bonus";
  reason: string;
  created_at: string;
};

type WalletHistoryOut = {
  items: WalletHistoryItem[];
  next_cursor: string | null;
};

type WithdrawHistoryItem = {
  id: number;
  tg_id: number;
  amount: string;
  status: string;
  created_at: string;
  updated_at: string;
};

type WithdrawHistoryOut = {
  items: WithdrawHistoryItem[];
  next_cursor: string | null;
};

type Props = {
  open: boolean;
  onClose: () => void;
  settings: UserSettings;
  setSettings: (s: UserSettings) => void;
  telegramName: string;
  telegramAvatarUrl?: string | null;
  isVip: boolean;
  hasActiv: boolean;
  isAdmin: boolean;
  onOpenAdmin: () => void;
  initialSection?: "wallet" | "history" | null;
  walletHint?: string | null;
  onOpenWalletConnect: () => void;
  onOpenDepositLauncher: () => void;
  onDisconnectWalletSession: () => void;
  tonSessionConnected: boolean;
  tonSessionRestoring: boolean;
  tonProofAccepted: boolean;
  availableWallets: {
    name: string;
    appName: string | null;
    imageUrl: string | null;
    aboutUrl: string | null;
    embedded: boolean;
    injected: boolean;
  }[];
  mainBalance: string;
  bonusBalance: string;
  tg_id: number | null;
};

type ProfileSection = "wallet" | "history" | "faq" | null;

// Quick overlay only. Use it for shortcuts and current status.
// Detailed account, payment, and history views stay in Web-Profile.


// Guard marker: return "no active payment";
function getActivePaymentStateLabel(
  truth: HubShopTruthResponse | null,
): string {
  const stage = truth?.flow_truth?.active_intent?.flow_truth?.product_state;
  const status = truth?.flow_truth?.active_intent?.status;
  if (stage) return productStateLabel(stage);
  if (status) return String(status);
  return "no_active_payment";
}

function getActivePaymentStateTone(
  truth: HubShopTruthResponse | null,
):
  | "primary"
  | "connected"
  | "warning"
  | "neutral"
  | "inactive"
  | "active"
  | "vip" {
  const flow = truth?.flow_truth?.active_intent?.flow_truth;
  if (!flow) return "inactive";
  if (flow.product_state === "terminal_success") return "connected";
  if (
    flow.product_state === "terminal_failed" ||
    flow.product_state === "expired" ||
    flow.lifecycle_stage === "manual_review"
  ) {
    return "warning";
  }
  return "primary";
}

type ToggleKey =
  | "reduce_motion"
  | "hide_balances"
  | "show_decimal_detail"
  | "sfx_enabled"
  | "haptics_enabled"
  | "confirm_actions"
  | "confirm_purchase"
  | "confirm_withdraw"
  | "confirm_convert"
  | "confirm_watch_ad"
  | "toasts_enabled"
  | "important_alerts_only";

function langLabel(
  lang: Lang,
  t: (key: string) => string,
): string {
  return t(`profile.lang.${lang}`);
}

function langFlag(lang: Lang): string {
  const flags: Record<string, string> = {
    en: "🇺🇸",
    ru: "🇷🇺",
    uk: "🇺🇦",
    de: "🇩🇪",
    fr: "🇫🇷",
    es: "🇪🇸",
    it: "🇮🇹",
    tr: "🇹🇷",
    pl: "🇵🇱",
    da: "🇩🇰",
    hi: "🇮🇳",
    id: "🇮🇩",
    sw: "🇰🇪",
  };
  return flags[lang] || "🏳️";
}

function addFixed8(a: string, b: string): string {
  const norm = (value: string): bigint => {
    const s = String(value || "0").trim();
    const neg = s.startsWith("-");
    const raw = neg ? s.slice(1) : s;
    const parts = raw.split(".");
    const whole = parts[0] || "0";
    const frac = (parts[1] || "").padEnd(8, "0").slice(0, 8);
    const val = BigInt(whole) * 100000000n + BigInt(frac || "0");
    return neg ? -val : val;
  };
  const fmt = (value: bigint): string => {
    const neg = value < 0n;
    const abs = neg ? -value : value;
    const whole = abs / 100000000n;
    const frac = String(abs % 100000000n).padStart(8, "0");
    return `${neg ? "-" : ""}${whole.toString()}.${frac}`;
  };
  return fmt(norm(a) + norm(b));
}

function openInternalRoute(path: string): void {
  if (typeof window !== "undefined") {
    window.location.assign(path);
  }
}


function latestWithdrawLabel(status: string | null | undefined): string {
  const raw = String(status || "pending").trim().toUpperCase();
  const labels: Record<string, string> = {
    PENDING: "pending",
    APPROVED: "approved",
    PAID: "paid",
    PAID_AUTO: "paid",
    REJECTED: "rejected",
    CANCELED: "canceled",
    CANCELLED: "canceled",
  };
  return labels[raw] || raw.toLowerCase();
}

function latestWithdrawTone(
  status: string | null | undefined,
):
  | "primary"
  | "connected"
  | "warning"
  | "neutral"
  | "inactive"
  | "active"
  | "vip" {
  const raw = String(status || "pending").trim().toUpperCase();
  if (["PAID", "PAID_AUTO", "APPROVED"].includes(raw)) {
    return "connected";
  }
  if (["REJECTED", "CANCELED", "CANCELLED"].includes(raw)) {
    return "warning";
  }
  return "primary";
}

function SectionCard(
  props: React.PropsWithChildren<{ title: string; note?: string }>,
) {
  return (
    <section className="efhc-card p-3.5 space-y-3">
      <div className="space-y-1">
        <div className="text-sm font-semibold">{props.title}</div>
        {props.note ? (
          <div className="text-xs text-[color:var(--tg-hint)]">
            {props.note}
          </div>
        ) : null}
      </div>
      {props.children}
    </section>
  );
}

function ToggleRow(
  props: {
    title: string;
    desc?: string;
    checked: boolean;
    onToggle: () => void;
  },
) {
  return (
    <button
      type="button"
      onClick={props.onToggle}
      className="efhc-settings-row"
    >
      <div className="efhc-settings-row_copy">
        <div className="efhc-settings-row_title">{props.title}</div>
        {props.desc ? (
          <div className="efhc-settings-row_desc">{props.desc}</div>
        ) : null}
      </div>
      <span
        className={[
          "efhc-switch",
          props.checked ? "efhc-switch--on" : "",
        ].join(" ")}
        aria-hidden="true"
      >
        <span className="efhc-switch_knob" />
      </span>
    </button>
  );
}

function SelectRow(
  props: React.PropsWithChildren<{
    title: string;
    desc?: string;
    value: string;
    onChange: (value: string) => void;
  }>,
) {
  return (
    <div className="efhc-settings-row efhc-settings-row--static">
      <div className="efhc-settings-row_copy">
        <div className="efhc-settings-row_title">{props.title}</div>
        {props.desc ? (
          <div className="efhc-settings-row_desc">{props.desc}</div>
        ) : null}
      </div>
      <select
        value={props.value}
        onChange={(event) => props.onChange(event.target.value)}
        className="efhc-settings-select"
      >
        {props.children}
      </select>
    </div>
  );
}

function NavRow(
  props: {
    title: string;
    desc?: string;
    badge?: string;
    active?: boolean;
    onClick: () => void;
  },
) {
  return (
    <TelegramSectionRow
      title={props.title}
      subtitle={props.desc}
      onClick={props.onClick}
      compact
      rightSlot={
        props.badge ? (
          <TelegramStatusBadge
            label={props.badge}
            tone={props.active ? "primary" : "neutral"}
          />
        ) : undefined
      }
      className={props.active ? "border-[color:var(--tg-button)]/60" : ""}
    />
  );
}

export function ProfileModal(props: Props) {
  const t = useT();
  const globalId = useAuthOwnerGlobalId();
  const modalRoleNote = t("profile.modal_role_note");
  const fileRef = useRef<HTMLInputElement | null>(null);
  const walletBlockRef = useRef<HTMLDivElement | null>(null);
  const historyBlockRef = useRef<HTMLDivElement | null>(null);
  const faqBlockRef = useRef<HTMLDivElement | null>(null);
  const faqCatalogState = useFaqCatalog(props.settings.lang);
  const faqCatalog = faqCatalogState.catalog;
  const reasonLabel = (reason: string): string => {
    const labels: Record<string, string> = {
      panel_purchase: t("profile.reason.panel_activation"),
      panel_activation: t("profile.reason.panel_activation"),
      exchange_kwh_to_efhc: t(
        "profile.reason.exchange_kwh_to_efhc",
      ),
      referral_bonus: t("profile.reason.referral_bonus"),
      task_bonus: t("profile.reason.task_bonus"),
      ad_bonus: t("profile.reason.ad_bonus"),
      withdraw_hold: t("profile.reason.withdraw_hold"),
      withdraw_refund: t("profile.reason.withdraw_refund"),
      withdraw_payout: t("profile.reason.withdraw_payout"),
      shop_purchase: t("profile.reason.hub_operation"),
    };
    return labels[reason] || reason;
  };

  const [activeSection, setActiveSection] = useState<ProfileSection>(
    props.initialSection || null,
  );
  const [wallets, setWallets] = useState<WalletItem[]>([]);
  const [walletsLoading, setWalletsLoading] = useState(false);
  const [walletsError, setWalletsError] = useState<string | null>(null);
  const [historyItems, setHistoryItems] = useState<WalletHistoryItem[]>([]);
  const [historyFilter, setHistoryFilter] = useState("all");
  const [historyLoading, setHistoryLoading] = useState(false);
  const [historyError, setHistoryError] = useState<string | null>(null);
  const [historyCursor, setHistoryCursor] = useState<string | null>(null);
  const [withdrawItems, setWithdrawItems] = useState<WithdrawHistoryItem[]>([]);
  const [withdrawLoading, setWithdrawLoading] = useState(false);
  const [withdrawError, setWithdrawError] = useState<string | null>(null);
  const [withdrawCursor, setWithdrawCursor] = useState<string | null>(null);
  const [shopTruth, setShopTruth] =
    useState<HubShopTruthResponse | null>(null);
  const [shopTruthLoading, setShopTruthLoading] = useState(false);
  const [languageMenuOpen, setLanguageMenuOpen] = useState(false);

  const totalBalance = useMemo(
    () => addFixed8(props.mainBalance, props.bonusBalance),
    [props.mainBalance, props.bonusBalance],
  );
  const connectedWallet = useMemo(
    () => wallets.find((wallet) => wallet.is_active) || null,
    [wallets],
  );
  const latestWithdraw = useMemo(
    () => withdrawItems[0] || null,
    [withdrawItems],
  );

  const activePaymentTitle = useMemo(() => {
    const intent = shopTruth?.flow_truth?.active_intent;
    if (!intent) return t("profile.active_payment_title");
    const asset = String(intent.asset || "payment").toUpperCase();
    return t("profile.active_payment_asset_title").replace(
      "{{asset}}",
      asset,
    );
  }, [shopTruth, t]);

  const activePaymentSubtitle = useMemo(() => {
    const flow = shopTruth?.flow_truth?.active_intent?.flow_truth;
    const intent = shopTruth?.flow_truth?.active_intent;
    if (!intent) {
      return t("profile.active_payment_no_intent_note");
    }
    if (flow?.user_message) {
      return (
        `${flow.user_message} ` +
        returnPathDescription(
          flow.return_path,
          flow.canonical_center,
        )
      );
    }
    return (
      `Intent #${intent.intent_id} · ` +
      nextActionDescription(flow?.next_action || flow?.next_step) +
      ` · ` +
      returnPathDescription(
        flow?.return_path,
        flow?.canonical_center,
      )
    );
  }, [shopTruth, t]);

  const currentAvatar =
    props.settings.avatar_source === "custom"
      ? props.settings.avatar_url || null
      : props.telegramAvatarUrl || null;

  useEffect(() => {
    if (!props.open) {
      setLanguageMenuOpen(false);
      return;
    }
    setActiveSection(props.initialSection || null);
  }, [props.initialSection, props.open]);

  useEffect(() => {
    if (!props.open || !globalId) return;
    void refreshWallets();
    void refreshHistory();
    void refreshWithdraws();
  }, [globalId, props.open]);

  useEffect(() => {
    const bySection: Record<string, React.RefObject<HTMLDivElement | null>> = {
      wallet: walletBlockRef,
      history: historyBlockRef,
      faq: faqBlockRef,
    };
    const node = activeSection ? bySection[activeSection]?.current : null;
    if (node) {
      node.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }, [activeSection]);

  function update(patch: Partial<UserSettings>) {
    props.setSettings({ ...props.settings, ...patch });
  }

  function selectLanguage(lang: Lang) {
    hapticSelection(props.settings.haptics_enabled);
    update({ lang });
    setLanguageMenuOpen(false);
  }

  function updateToggle(key: ToggleKey, value: boolean) {
    hapticSelection(props.settings.haptics_enabled);
    update({ [key]: value } as Partial<UserSettings>);
  }

  function activateSection(section: Exclude<ProfileSection, null>) {
    hapticSelection(props.settings.haptics_enabled);
    setActiveSection(section);
  }

  async function onPickAvatar(file: File): Promise<void> {
    const data = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ""));
      reader.onerror = () => reject(new Error("avatar_read_failed"));
      reader.readAsDataURL(file);
    });
    update({
      avatar_source: "custom",
      avatar_url: data,
    });
  }

  async function refreshWallets(): Promise<void> {
    setWalletsLoading(true);
    setWalletsError(null);
    try {
      const out = await getProfileWallets<WalletsMeResponse>();
      setWallets(out.wallets || []);
    } catch (error) {
      setWalletsError(publicApiErrorMessage(error, t, "profile.error_wallet"));
    } finally {
      setWalletsLoading(false);
    }
  }

  async function refreshHistory(cursor?: string | null): Promise<void> {
    setHistoryLoading(true);
    setHistoryError(null);
    try {
      const out = await getProfileBalanceHistory<WalletHistoryOut>(cursor);
      setHistoryItems((prev) =>
        cursor ? [...prev, ...(out.items || [])] : out.items || [],
      );
      setHistoryCursor(out.next_cursor || null);
    } catch (error) {
      setHistoryError(publicApiErrorMessage(error, t, "profile.error_history"));
    } finally {
      setHistoryLoading(false);
    }
  }

  function openWithdrawPage(): void {
    if (typeof window === "undefined") return;
    props.onClose();
    window.location.assign("/withdraw");
  }


  async function refreshWithdraws(cursor?: string | null): Promise<void> {
    if (!globalId) return;
    setWithdrawLoading(true);
    setWithdrawError(null);
    try {
      const out = await getProfileWithdrawHistory<WithdrawHistoryOut>(cursor);
      setWithdrawItems((prev) =>
        cursor ? [...prev, ...(out.items || [])] : out.items || [],
      );
      setWithdrawCursor(out.next_cursor || null);
    } catch (error) {
      setWithdrawError(
        publicApiErrorMessage(error, t, "profile.error_withdraw_history"),
      );
    } finally {
      setWithdrawLoading(false);
    }
  }

  return (
    <Modal
      open={props.open}
      onClose={props.onClose}
      title={t("profile.modal_title")}
    >
      <div className="space-y-4">
        <div className="text-xs text-[color:var(--tg-hint)]">
          {modalRoleNote}
        </div>
        <section className="efhc-card p-3.5 space-y-3">
          <div className="flex items-center gap-3">
            <div
              className={
                "w-14 h-14 rounded-2xl overflow-hidden "
                + "bg-[var(--tg-secondary-bg)] flex items-center justify-center"
              }
            >
              {currentAvatar ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={currentAvatar}
                  alt={t("profile.custom_avatar")}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="text-sm text-[color:var(--tg-hint)]">{t("profile.no_avatar")}</div>
              )}
            </div>
            <div className="min-w-0 flex-1 space-y-1">
              <div className="font-semibold">
                {props.telegramName || t("profile.telegram_user")}
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <TelegramStatusBadge label={t("profile.telegram_badge")} tone="neutral" />
                {props.hasActiv ? (
                  <TelegramStatusBadge
                    label={t("profile.activ_badge")}
                    tone="active"
                  />
                ) : null}
                {props.isVip ? (
                  <TelegramStatusBadge
                    label={t("profile.vip_badge")}
                    tone="vip"
                  />
                ) : null}
                {props.isAdmin ? (
                  <TelegramStatusBadge label={t("profile.admin_badge")} tone="warning" />
                ) : null}
              </div>
            </div>
          </div>
          <div className="grid gap-2 sm:grid-cols-2">
            <Button
              onClick={() => update({ avatar_source: "telegram" })}
              variant={
                props.settings.avatar_source === "telegram"
                  ? "primary"
                  : "secondary"
              }
            >{t("profile.telegram_avatar")}</Button>
            <Button
              onClick={() => fileRef.current?.click()}
              variant={
                props.settings.avatar_source === "custom"
                  ? "primary"
                  : "secondary"
              }
            >{t("profile.custom_avatar")}</Button>
          </div>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(event) => {
              const file = event.target.files?.[0];
              if (file) void onPickAvatar(file);
            }}
          />
          {props.settings.avatar_source === "custom"
            && props.settings.avatar_url ? (
            <div className="flex justify-end">
              <Button
                variant="secondary"
                onClick={() =>
                  update({
                    avatar_source: "telegram",
                    avatar_url: null,
                  })
                }
              >{t("profile.reset_to_telegram")}</Button>
            </div>
          ) : null}
        </section>

        <SectionCard
          title={t("profile.quick_overlay_title")}
          note={t("profile.quick_overlay_note")}
        >
          <TelegramSectionRow
            title={t("profile.wallet_shortcut_title")}
            subtitle={
              connectedWallet
                ? t("profile.wallet_shortcut_connected").replace(
                  "{{wallet}}",
                  connectedWallet.wallet_app || t("wallet.title"),
                )
                : t("profile.wallet_shortcut_unbound")
            }
            compact
            onClick={() => activateSection("wallet")}
            rightSlot={
              <TelegramStatusBadge
                label={connectedWallet
                  ? t("wallet.status_connected")
                  : t("wallet.status_not_connected")}
                tone={connectedWallet ? "connected" : "warning"}
              />
            }
          />
          <TelegramSectionRow
            title={t("profile.top_up_efhc_title")}
            subtitle={
              t("profile.top_up_efhc_note")
            }
            compact
            onClick={props.onOpenDepositLauncher}
            rightSlot={
              <TelegramStatusBadge
                label={t("profile.launcher_badge")}
                tone="primary"
              />
            }
          />
          <TelegramSectionRow
            title={t("profile.open_web_profile_title")}
            subtitle={
              t("profile.account_center_status")
                .replace("{{total}}", totalBalance)
                .replace("{{main}}", props.mainBalance)
                .replace("{{bonus}}", props.bonusBalance)
            }
            compact
            onClick={() => window.location.assign("/web-profile")}
            rightSlot={
              <TelegramStatusBadge
                label={t("profile.account_center_badge")}
                tone="primary"
              />
            }
          />
          <TelegramSectionRow
            title={activePaymentTitle}
            subtitle={
              shopTruthLoading
                ? t("profile.checking_top_up_state")
                : activePaymentSubtitle
            }
            compact
            onClick={() => window.location.assign("/web-profile")}
            rightSlot={
              <TelegramStatusBadge
                label={getActivePaymentStateLabel(shopTruth) ===
                  "no_active_payment"
                  ? t("profile.no_active_payment")
                  : getActivePaymentStateLabel(shopTruth)}
                tone={getActivePaymentStateTone(shopTruth)}
              />
            }
          />
          <TelegramSectionRow
            title={t("profile.latest_withdraw_title")}
            subtitle={
              latestWithdraw
                ? t("profile.latest_withdraw_request")
                  .replace("{{id}}", String(latestWithdraw.id))
                  .replace("{{amount}}", latestWithdraw.amount)
                : t("profile.latest_withdraw_empty")
            }
            compact
            onClick={openWithdrawPage}
            rightSlot={
              <TelegramStatusBadge
                label={latestWithdrawLabel(latestWithdraw?.status)}
                tone={latestWithdrawTone(latestWithdraw?.status)}
              />
            }
          />
          <TelegramSectionRow
            title={t("profile.history_shortcut_title")}
            subtitle={
              historyItems.length > 0
                ? t("profile.history_shortcut_loaded").replace(
                  "{{count}}",
                  String(historyItems.length),
                )
                : t("profile.history_shortcut_empty")
            }
            compact
            onClick={() => window.location.assign("/web-profile")}
            rightSlot={
              <TelegramStatusBadge
                label={t("history.title")}
                tone="neutral"
              />
            }
          />
        </SectionCard>

        <SectionCard
          title={t("profile.section_title")}
          note={t("profile.section_note")}
        >
          <NavRow
            title={t("wallet.title")}
            desc={t("profile.wallet_nav_desc")}
            active={activeSection === "wallet"}
            badge={activeSection === "wallet" ? t("profile.open_badge") : undefined}
            onClick={() => activateSection("wallet")}
          />
          <NavRow
            title={t("history.title")}
            desc={t("profile.history_nav_desc")}
            active={activeSection === "history"}
            badge={activeSection === "history" ? t("profile.open_badge") : undefined}
            onClick={() => activateSection("history")}
          />
          <NavRow
            title={t("faq.title")}
            desc={t("profile.faq_nav_desc")}
            active={activeSection === "faq"}
            badge={activeSection === "faq" ? t("profile.open_badge") : undefined}
            onClick={() => activateSection("faq")}
          />
        </SectionCard>

        {activeSection === "wallet" ? (
          <SectionCard
            title={t("wallet.title")}
            note={t("profile.wallet_section_note")}
          >
            <div ref={walletBlockRef} className="space-y-3">
              <ProfileWalletSection
                wallets={wallets}
                walletsLoading={walletsLoading}
                walletsError={walletsError}
                walletHint={props.walletHint}
                sessionConnected={props.tonSessionConnected}
                sessionRestoring={props.tonSessionRestoring}
                tonProofAccepted={props.tonProofAccepted}
                connectionPhase={
                  props.tonSessionRestoring
                    ? "restoring"
                    : props.tonSessionConnected
                      ? "connected"
                      : "disconnected"
                }
                availableWallets={props.availableWallets}
                onConnect={props.onOpenWalletConnect}
                onDisconnectSession={props.onDisconnectWalletSession}
                onMakePrimary={(id) => {
                  makePrimaryWallet(id)
                    .then(() => refreshWallets())
                    .catch(() => undefined);
                }}
                onRemove={(id) => {
                  deleteWallet(id)
                    .then(() => refreshWallets())
                    .catch(() => undefined);
                }}
                hapticsEnabled={props.settings.haptics_enabled}
              />
            </div>
          </SectionCard>
        ) : null}

        {activeSection === "history" ? (
          <SectionCard
            title={t("history.title")}
            note={t("profile.history_section_note")}
          >
            <div ref={historyBlockRef} className="space-y-3">
              <ProfileHistorySection
                totalBalance={totalBalance}
                mainBalance={props.mainBalance}
                bonusBalance={props.bonusBalance}
                historyItems={historyItems}
                historyLoading={historyLoading}
                historyError={historyError}
                historyCursor={historyCursor}
                withdrawItems={withdrawItems}
                withdrawLoading={withdrawLoading}
                withdrawError={withdrawError}
                withdrawCursor={withdrawCursor}
                activeFilter={historyFilter}
                onFilterChange={setHistoryFilter}
                onRefresh={() => {
                  void refreshHistory();
                  void refreshWithdraws();
                  hapticMedium(props.settings.haptics_enabled);
                }}
                onLoadMore={() => {
                  if (!historyCursor) return;
                  void refreshHistory(historyCursor);
                }}
                onLoadMoreWithdraw={() => {
                  if (!withdrawCursor) return;
                  void refreshWithdraws(withdrawCursor);
                }}
                reasonLabel={reasonLabel}
              />
            </div>
          </SectionCard>
        ) : null}

        {activeSection === "faq" ? (
          <SectionCard
            title={t("faq.title")}
            note={t("profile.faq_section_note")}
          >
            <div ref={faqBlockRef} className="space-y-3">
              <ProfileFaqSection t={t} catalog={faqCatalog} />
            </div>
          </SectionCard>
        ) : null}

        <SectionCard
          title={t("profile.language_title")}
          note={t("profile.language_note")}
        >
          <div className="efhc-language-select">
            <button
              type="button"
              className="efhc-language-select_button"
              aria-haspopup="listbox"
              aria-expanded={languageMenuOpen}
              onClick={() => {
                hapticSelection(props.settings.haptics_enabled);
                setLanguageMenuOpen((value) => !value);
              }}
            >
              <span className="efhc-language-select_current">
                <span className="text-base leading-none">
                  {langFlag(props.settings.lang)}
                </span>
                <span className="min-w-0 truncate font-semibold">
                  {langLabel(props.settings.lang, t)}
                </span>
              </span>
              <span
                className="efhc-language-select_chevron"
                aria-hidden="true"
              >
                ▾
              </span>
            </button>
            {languageMenuOpen ? (
              <div
                className="efhc-language-select_menu"
                role="listbox"
                aria-label={t("profile.language_title")}
              >
                {SUPPORTED_LANGS.map((lang) => {
                  const active = props.settings.lang === lang;
                  return (
                    <button
                      key={lang}
                      type="button"
                      role="option"
                      aria-selected={active}
                      className={[
                        "efhc-language-select_option",
                        active ? "efhc-language-select_option--active" : "",
                      ].join(" ")}
                      onClick={() => selectLanguage(lang)}
                    >
                      <span className="text-base leading-none">
                        {langFlag(lang)}
                      </span>
                      <span className="min-w-0 truncate">
                        {langLabel(lang, t)}
                      </span>
                    </button>
                  );
                })}
              </div>
            ) : null}
          </div>
        </SectionCard>

        <SectionCard
          title={t("profile.interface_title")}
          note={t("profile.interface_note")}
        >
          <SelectRow
            title={t("profile.theme_title")}
            desc={t("profile.theme_desc")}
            value={props.settings.theme_mode}
            onChange={(value) => {
              hapticSelection(props.settings.haptics_enabled);
              update({ theme_mode: value as UserSettings["theme_mode"] });
            }}
          >
            <option value="auto">{t("profile.theme_auto")}</option>
            <option value="dark">{t("profile.theme_dark")}</option>
            <option value="light">{t("profile.theme_light")}</option>
          </SelectRow>
          <ToggleRow
            title={t("profile.reduce_motion")}
            desc={t("profile.reduce_motion_desc")}
            checked={props.settings.reduce_motion}
            onToggle={() =>
              updateToggle("reduce_motion", !props.settings.reduce_motion)
            }
          />
          <ToggleRow
            title={t("profile.hide_balances")}
            desc={t("profile.hide_balances_desc")}
            checked={props.settings.hide_balances}
            onToggle={() =>
              updateToggle("hide_balances", !props.settings.hide_balances)
            }
          />
          <ToggleRow
            title={t("profile.show_decimal_detail")}
            desc={t("profile.show_decimal_detail_desc")}
            checked={props.settings.show_decimal_detail}
            onToggle={() =>
              updateToggle(
                "show_decimal_detail",
                !props.settings.show_decimal_detail,
              )
            }
          />
        </SectionCard>

        <SectionCard
          title={t("profile.sound_title")}
          note={t("profile.sound_note")}
        >
          <ToggleRow
            title={t("profile.ui_sounds")}
            desc={t("profile.ui_sounds_desc")}
            checked={props.settings.sfx_enabled}
            onToggle={() =>
              updateToggle("sfx_enabled", !props.settings.sfx_enabled)
            }
          />
          <div className="efhc-settings-row efhc-settings-row--static">
            <div className="efhc-settings-row_copy">
              <div className="efhc-settings-row_title">{t("profile.sound_volume")}</div>
              <div className="efhc-settings-row_desc">
                {t("profile.sound_volume_desc")}
              </div>
            </div>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={props.settings.sfx_volume}
              onChange={(event) => {
                update({ sfx_volume: Number(event.target.value) });
              }}
              className="w-28 accent-[var(--tg-button)]"
            />
          </div>
          <SelectRow
            title={t("profile.sound_pack")}
            desc={t("profile.sound_pack_desc")}
            value={props.settings.sfx_pack}
            onChange={(value) => {
              hapticSelection(props.settings.haptics_enabled);
              update({ sfx_pack: value as UserSettings["sfx_pack"] });
            }}
          >
            <option value="default">{t("profile.sound_pack_default")}</option>
          </SelectRow>
          <ToggleRow
            title={t("profile.haptic_feedback")}
            desc={t("profile.haptic_feedback_desc")}
            checked={props.settings.haptics_enabled}
            onToggle={() =>
              updateToggle(
                "haptics_enabled",
                !props.settings.haptics_enabled,
              )
            }
          />
        </SectionCard>

        <SectionCard
          title={t("profile.confirmations_title")}
          note={t("profile.confirmations_note")}
        >
          <ToggleRow
            title={t("profile.confirm_actions")}
            desc={t("profile.confirm_actions_desc")}
            checked={props.settings.confirm_actions}
            onToggle={() =>
              updateToggle(
                "confirm_actions",
                !props.settings.confirm_actions,
              )
            }
          />
          <ToggleRow
            title={t("profile.confirm_purchase")}
            checked={props.settings.confirm_purchase}
            onToggle={() =>
              updateToggle(
                "confirm_purchase",
                !props.settings.confirm_purchase,
              )
            }
          />
          <ToggleRow
            title={t("profile.confirm_withdraw")}
            checked={props.settings.confirm_withdraw}
            onToggle={() =>
              updateToggle(
                "confirm_withdraw",
                !props.settings.confirm_withdraw,
              )
            }
          />
          <ToggleRow
            title={t("profile.confirm_convert")}
            checked={props.settings.confirm_convert}
            onToggle={() =>
              updateToggle(
                "confirm_convert",
                !props.settings.confirm_convert,
              )
            }
          />
          <ToggleRow
            title={t("profile.confirm_watch_ad")}
            checked={props.settings.confirm_watch_ad}
            onToggle={() =>
              updateToggle(
                "confirm_watch_ad",
                !props.settings.confirm_watch_ad,
              )
            }
          />
        </SectionCard>

        <SectionCard
          title={t("profile.notifications_title")}
          note={t("profile.notifications_note")}
        >
          <ToggleRow
            title={t("profile.toasts_enabled")}
            desc={t("profile.toasts_enabled_desc")}
            checked={props.settings.toasts_enabled}
            onToggle={() =>
              updateToggle("toasts_enabled", !props.settings.toasts_enabled)
            }
          />
          <ToggleRow
            title={t("profile.important_alerts_only")}
            desc={t("profile.important_alerts_only_desc")}
            checked={props.settings.important_alerts_only}
            onToggle={() =>
              updateToggle(
                "important_alerts_only",
                !props.settings.important_alerts_only,
              )
            }
          />
        </SectionCard>

        <SectionCard
          title={t("profile.support_title")}
          note={t("profile.support_note")}
        >
          <NavRow
            title={t("profile.open_faq")}
            desc={t("profile.open_faq_desc")}
            onClick={() => openInternalRoute("/faq")}
          />
          <NavRow
            title={t("profile.support_chat")}
            desc={t("profile.support_chat_desc")}
            onClick={() => openInternalRoute("/faq")}
          />
          <NavRow
            title={t("profile.terms")}
            desc={t("profile.terms_desc")}
            onClick={() =>
              openInternalRoute("/web-profile?legal=terms")
            }
          />
          <NavRow
            title={t("profile.privacy")}
            desc={t("profile.privacy_desc")}
            onClick={() =>
              openInternalRoute("/web-profile?legal=privacy")
            }
          />
          <div className="text-xs text-[color:var(--tg-hint)]">
            {t("profile.version_note")}
          </div>
          <div className="flex justify-end">
            <Button
              variant="secondary"
              onClick={() => props.setSettings(resetSettings())}
            >
              {t("profile.reset_settings")}
            </Button>
          </div>
        </SectionCard>

        {props.isAdmin ? (
          <div className="flex justify-end">
            <Button onClick={props.onOpenAdmin}>{t("profile.admin_panel")}</Button>
          </div>
        ) : null}
      </div>
    </Modal>
  );
}
