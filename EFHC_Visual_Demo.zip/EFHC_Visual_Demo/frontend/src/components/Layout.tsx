import React, { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/router";
import { useQueryClient } from "@tanstack/react-query";
import type { Dict, Lang } from "../lib/i18n";
import { tFromDicts } from "../lib/i18n";
import type { UserSettings } from "../lib/settings";
import { DepositModal } from "./DepositModal";
import {
  getTelegramWebApp,
  hapticError,
  hapticSelection,
  hapticSuccess,
  hapticTap,
  telegramBackButtonShow,
  telegramConfirm,
} from "../lib/telegram";
import {
  useWalletProvider,
  type PreparedWalletProof,
  type WalletConnectionPhase,
  type WalletView,
} from "../lib/wallet-provider";
import { GlobalHeader } from "./GlobalHeader";
import { AppNavIcon } from "./icons/AppNavIcon";
import { BrowserLoginDemo } from "./BrowserLoginDemo";
import { getUserLevel } from "../lib/skins";
import { useWalletsMe } from "../hooks/useWalletsMe";
import {
  FrontendShellFrame,
  FrontendShellMain,
  FrontendShellRoot,
} from "./shell/FrontendShell";
import { NetworkStatus } from "./NetworkStatus";

export type LayoutContextValue = {
  lang: Lang;
  t: (k: string) => string;
  td: (k: string) => string;
  tg_id: number | null;
  isVip: boolean;
  isAdmin: boolean;
  settings: UserSettings;
  setLang: (l: Lang) => void;
  setSettings: (s: UserSettings) => void;
  confirm: (
    kind:
      | "purchase"
      | "withdraw"
      | "convert"
      | "watch_ad"
      | "generic",
    title: string,
    detail?: string,
  ) => Promise<boolean>;
  toast: (msg: string, kind?: "success" | "error" | "info") => void;
  openProfile: (section?: "wallet" | "history") => void;
  openDeposit: () => void;
  openWalletConnect: () => void;
  disconnectWalletSession: () => void;
  walletConnectionPhase: WalletConnectionPhase;
  walletHint: string | null;
  walletSessionConnected: boolean;
  walletSessionRestoring: boolean;
  walletProofAccepted: boolean;
  availableWallets: WalletView[];
};

export const LayoutContext = React.createContext<LayoutContextValue>({
  lang: "en",
  t: (k) => k,
  td: (k) => k,
  tg_id: null,
  isVip: false,
  isAdmin: false,
  settings: {
    lang: "en",
    theme_mode: "auto",
    avatar_source: "telegram",
    avatar_url: null,
    sfx_enabled: true,
    sfx_volume: 0.6,
    sfx_pack: "default",
    haptics_enabled: true,
    reduce_motion: false,
    hide_balances: false,
    show_decimal_detail: false,
    confirm_actions: true,
    confirm_purchase: true,
    confirm_withdraw: true,
    confirm_convert: true,
    confirm_watch_ad: true,
    toasts_enabled: true,
    important_alerts_only: false,
  },
  setLang: () => undefined,
  setSettings: () => undefined,
  confirm: async () => true,
  toast: () => undefined,
  openProfile: () => undefined,
  openDeposit: () => undefined,
  openWalletConnect: () => undefined,
  disconnectWalletSession: () => undefined,
  walletConnectionPhase: "disconnected",
  walletHint: null,
  walletSessionConnected: false,
  walletSessionRestoring: false,
  walletProofAccepted: false,
  availableWallets: [],
});

function NavItem(props: {
  href: string;
  active: boolean;
  visualLabel: string;
  localizedLabel: string;
  navKey: string;
  icon: React.ReactNode;
  onNav: () => void;
}) {
  const activeCls =
    "bg-[var(--tg-button)] text-[var(--tg-button-text)] ";
  const inactiveCls =
    "bg-[var(--tg-secondary-bg)] text-[var(--tg-text)] " +
    "border border-[color:var(--tg-hint)]";
  return (
    <Link
      href={props.href}
      aria-current={props.active ? "page" : undefined}
      aria-label={props.localizedLabel}
      data-active={props.active ? "true" : "false"}
      data-nav-key={props.navKey}
      title={props.localizedLabel}
      onClick={(event) => {
        props.onNav();
        if (props.active) event.preventDefault();
      }}
      className={
        "flex flex-col items-center justify-center transition " +
        "text-xs font-semibold efhc-game-nav-button " +
        "efhc-game-nav_item " +
        (props.active ? activeCls : inactiveCls)
      }
    >
      <span className="efhc-game-nav_icon">{props.icon}</span>
      <span className="efhc-game-nav_label">{props.visualLabel}</span>
      <span
        className="efhc-game-nav_active-indicator"
        aria-hidden="true"
      />
    </Link>
  );
}

export function Layout(
  props: React.PropsWithChildren<{
    lang: Lang;
    uiDict: Dict;
    ruDict: Dict;
    descDict: Dict;
    tg_id: number | null;
    telegramName: string;
    telegramAvatarUrl?: string | null;
    snapshot?: {
      profile: {
        username?: string | null;
        is_vip?: boolean;
        has_activ?: boolean;
        main_balance: string;
        bonus_balance: string;
        total_generated_kwh: string;
      };
    } | null;
    isVip: boolean;
    isAdmin: boolean;
    settings: UserSettings;
    setLang: (l: Lang) => void;
    setSettings: (s: UserSettings) => void;
    shopSkinBgUrl?: string | null;
  }>,
) {
  const router = useRouter();
  const t = useMemo(
    () => (k: string) => tFromDicts(k, props.uiDict, props.ruDict),
    [props.uiDict, props.ruDict],
  );
  const td = useMemo(
    () => (k: string) =>
      props.descDict[k] || tFromDicts(k, props.uiDict, props.ruDict),
    [props.descDict, props.uiDict, props.ruDict],
  );
  const [depositOpen, setDepositOpen] = useState(false);
  const [walletHint, setWalletHint] = useState<string | null>(null);
  const [availableWallets, setAvailableWallets] = useState<WalletView[]>([]);
  const [proofState, setProofState] = useState<
    PreparedWalletProof | null
  >(null);
  const [proofAccepted, setProofAccepted] = useState(false);
  const [connectionPhase, setConnectionPhase] = useState<
    WalletConnectionPhase
  >("restoring");
  const [walletModalOpened, setWalletModalOpened] = useState(false);
  const bindingAttemptRef = useRef("");
  const [toasts, setToasts] = useState<
    {
      id: string;
      msg: string;
      kind: "success" | "error" | "info";
      createdAt: number;
    }[]
  >([]);

  const qc = useQueryClient();
  const {
    activeAdapterId,
    session: walletSession,
    restoreSettled,
    modalOpened: providerModalOpened,
    listWallets,
    prepareProof,
    connect: connectWallet,
    bindWallet,
    disconnect: disconnectWallet,
    isUserRejected,
  } = useWalletProvider();
  const sessionConnected = Boolean(walletSession);
  const walletsMe = useWalletsMe(props.tg_id);
  const hasBoundWallet = Boolean(walletsMe.data?.is_connected);
  const walletConnected = hasBoundWallet;
  const isAdminRoute = router.pathname.startsWith("/admin");
  const shellBottomPadding = isAdminRoute
    ? "var(--efhc-safe-bottom)"
    : "calc(6rem + var(--efhc-safe-bottom))";
  const showBrowserLoginDemo = !props.tg_id &&
    router.pathname !== "/browser-shop" &&
    !isAdminRoute;

  const avatarUrl =
    props.settings.avatar_source === "custom"
      ? props.settings.avatar_url || null
      : props.settings.avatar_source === "telegram"
        ? props.telegramAvatarUrl || null
        : null;
  const username =
    props.snapshot?.profile?.username || props.telegramName || "";
  const level = getUserLevel(
    props.snapshot?.profile?.total_generated_kwh || "0",
  );

  useEffect(() => {
    if (!restoreSettled) {
      setConnectionPhase("restoring");
      return;
    }
    if (!walletSession) {
      bindingAttemptRef.current = "";
      setConnectionPhase("disconnected");
      setProofAccepted(false);
      return;
    }
    if (hasBoundWallet) {
      setConnectionPhase("connected");
      setProofAccepted(true);
      setWalletHint(t("wallet.session_restored"));
    }
  }, [hasBoundWallet, restoreSettled, t, walletSession]);

  useEffect(() => {
    setWalletModalOpened(providerModalOpened);
  }, [providerModalOpened]);

  useEffect(() => {
    listWallets()
      .then(setAvailableWallets)
      .catch(() => setAvailableWallets([]));
  }, [activeAdapterId, listWallets]);

  useEffect(() => {
    if (!props.tg_id) return;
    setProofState(null);
    prepareProof()
      .then((state) => {
        setProofState(state);
        if (!state) {
          setConnectionPhase("error");
          setWalletHint(t("wallet.proof_failed"));
          return;
        }
        if (!sessionConnected) setConnectionPhase("proof_ready");
        setWalletHint(t("wallet.proof_ready"));
      })
      .catch(() => {
        setConnectionPhase("error");
        setWalletHint(t("wallet.proof_failed"));
      });
  }, [activeAdapterId, prepareProof, props.tg_id, sessionConnected, t]);

  useEffect(() => {
    if (
      !walletSession
      || !proofState
      || hasBoundWallet
      || walletsMe.isLoading
    ) {
      return;
    }
    const proofKey = String(
      (proofState.value as { payload_token?: unknown } | null)
        ?.payload_token ?? "proof",
    );
    const attemptKey = [
      activeAdapterId,
      walletSession.address,
      proofKey,
    ].join(":");
    if (bindingAttemptRef.current === attemptKey) return;
    bindingAttemptRef.current = attemptKey;

    if (props.tg_id) {
      qc.invalidateQueries({
        queryKey: ["wallets_me", props.tg_id],
      }).catch(() => undefined);
    }
    setConnectionPhase("verifying");
    setWalletHint(t("wallet.proof_verifying"));
    bindWallet(proofState)
      .then((bound) => {
        if (!bound?.is_connected) {
          setConnectionPhase("error");
          setWalletHint(t("wallet.restore_requires_proof"));
          return;
        }
        setWalletModalOpened(false);
        restoreTelegramMainButtonAfterWalletModal();
        setProofAccepted(true);
        setConnectionPhase("connected");
        setWalletHint(t("wallet.proof_received"));
        toast(t("wallet.proof_received"), "success");
        if (props.tg_id) {
          qc.invalidateQueries({
            queryKey: ["wallets_me", props.tg_id],
          }).catch(() => undefined);
        }
      })
      .catch(() => {
        setConnectionPhase("error");
        setWalletHint(t("wallet.proof_failed"));
      });
  }, [
    activeAdapterId,
    bindWallet,
    hasBoundWallet,
    proofState,
    props.tg_id,
    qc,
    t,
    walletSession,
    walletsMe.isLoading,
  ]);

  useEffect(() => {
    if (walletModalOpened) {
      hideTelegramMainButtonForWalletModal();
      return;
    }
    restoreTelegramMainButtonAfterWalletModal();
  }, [depositOpen, walletModalOpened]);

  useEffect(() => {
    if (!depositOpen) return;
    const off = telegramBackButtonShow(() => {
      setDepositOpen(false);
    });
    return () => off();
  }, [depositOpen]);

  useEffect(() => {
    const publicRootRoute = router.pathname === "/";
    if (isAdminRoute || depositOpen || walletModalOpened || publicRootRoute) {
      return;
    }
    const off = telegramBackButtonShow(() => {
      if (typeof window !== "undefined" && window.history.length > 1) {
        router.back();
        return;
      }
      router.push("/").catch(() => undefined);
    });
    return () => off();
  }, [
    depositOpen,
    isAdminRoute,
    router,
    router.pathname,
    walletModalOpened,
  ]);

  function toast(
    msg: string,
    kind: "success" | "error" | "info" = "info",
  ) {
    if (!props.settings.toasts_enabled) return;
    if (kind === "success") {
      hapticSuccess(props.settings.haptics_enabled);
    }
    if (kind === "error") hapticError(props.settings.haptics_enabled);
    const createdAt = Date.now();
    const id = `${createdAt}:${Math.random().toString(16).slice(2)}`;
    setToasts((prev) => {
      const duplicate = prev.some(
        (item) =>
          item.msg === msg &&
          item.kind === kind &&
          createdAt - item.createdAt < 2500,
      );
      if (duplicate) return prev;
      return [...prev, { id, msg, kind, createdAt }].slice(-3);
    });
    window.setTimeout(() => {
      setToasts((prev) => prev.filter((item) => item.id !== id));
    }, 3200);
  }

  async function confirm(
    kind:
      | "purchase"
      | "withdraw"
      | "convert"
      | "watch_ad"
      | "generic",
    title: string,
    detail?: string,
  ): Promise<boolean> {
    if (!props.settings.confirm_actions) return true;
    const gate = {
      purchase: props.settings.confirm_purchase,
      withdraw: props.settings.confirm_withdraw,
      convert: props.settings.confirm_convert,
      watch_ad: props.settings.confirm_watch_ad,
      generic: true,
    }[kind];
    if (!gate) return true;
    return await telegramConfirm(title, detail);
  }

  const bottom = [
    {
      href: "/",
      key: "nav.energy",
      visualLabel: "Energy",
      kind: "energy" as const,
    },
    {
      href: "/panels",
      key: "nav.panels",
      visualLabel: "Panels",
      kind: "panels" as const,
    },
    {
      href: "/exchange",
      key: "nav.exchange",
      visualLabel: "Exchange",
      kind: "exchange" as const,
    },
    {
      href: "/tasks",
      key: "nav.tasks",
      visualLabel: "Tasks",
      kind: "tasks" as const,
    },
    {
      href: "/referrals",
      key: "nav.referrals",
      visualLabel: "Referrals",
      kind: "referrals" as const,
    },
    {
      href: "/ranks",
      key: "nav.ranks",
      visualLabel: "Ranks",
      kind: "ranks" as const,
    },
  ];

  const onTap = (kind: "tap" | "nav") => {
    if (props.settings.sfx_enabled) {
      void import("../lib/sfx").then(({ playSfx }) => {
        playSfx(
          kind,
          props.settings.sfx_enabled,
          props.settings.sfx_volume,
        );
      });
    }
    if (kind === "nav") {
      hapticSelection(props.settings.haptics_enabled);
      return;
    }
    hapticTap(props.settings.haptics_enabled);
  };

  function hideTelegramMainButtonForWalletModal() {
    try {
      getTelegramWebApp()?.MainButton?.hide?.();
    } catch {
      // noop
    }
  }

  function restoreTelegramMainButtonAfterWalletModal() {
    try {
      if (!depositOpen) return;
      getTelegramWebApp()?.MainButton?.show?.();
    } catch {
      // noop
    }
  }

  function openProfile(section?: "wallet" | "history") {
    const query = section ? { section } : undefined;
    void router.push({ pathname: "/web-profile", query });
  }

  async function openWalletConnect() {
    hideTelegramMainButtonForWalletModal();
    setWalletModalOpened(true);
    setConnectionPhase("connecting");
    setWalletHint(t("wallet.connection_waiting"));
    const wallets = await listWallets()
      .catch(() => [] as WalletView[]);
    setAvailableWallets(wallets);
    let prepared = proofState;
    if (!prepared) {
      prepared = await prepareProof()
        .catch(() => null);
      setProofState(prepared);
    }
    if (!prepared) {
      setConnectionPhase("error");
      setWalletHint(t("wallet.proof_failed"));
      setWalletModalOpened(false);
      restoreTelegramMainButtonAfterWalletModal();
      return;
    }
    try {
      await connectWallet();
    } catch (error) {
      setWalletModalOpened(false);
      restoreTelegramMainButtonAfterWalletModal();
      if (isUserRejected(error)) {
        setConnectionPhase("rejected");
        setWalletHint(t("wallet.connection_rejected"));
        toast(t("wallet.connection_rejected"), "info");
        return;
      }
      setConnectionPhase("error");
      setWalletHint(t("wallet.connection_failed"));
      toast(t("wallet.connection_failed"), "error");
    }
  }

  async function disconnectWalletSession() {
    await disconnectWallet().catch(() => undefined);
    if (props.tg_id) {
      qc.invalidateQueries({ queryKey: ["wallets_me", props.tg_id] })
        .catch(() => undefined);
    }
    setProofAccepted(false);
    setConnectionPhase("disconnected");
    setWalletHint(t("wallet.session_disconnected"));
    toast(t("wallet.session_disconnected"), "info");
  }

  function openDeposit() {
    setDepositOpen(true);
  }

  return (
    <LayoutContext.Provider
      value={{
        lang: props.lang,
        t,
        td,
        tg_id: props.tg_id,
        isVip: props.isVip,
        isAdmin: props.isAdmin,
        settings: props.settings,
        setLang: props.setLang,
        setSettings: props.setSettings,
        confirm,
        toast,
        openProfile,
        openDeposit,
        openWalletConnect: () => {
          void openWalletConnect();
        },
        disconnectWalletSession: () => {
          void disconnectWalletSession();
        },
        walletConnectionPhase: connectionPhase,
        walletHint,
        walletSessionConnected: sessionConnected,
        walletSessionRestoring: !restoreSettled,
        walletProofAccepted: proofAccepted,
        availableWallets,
      }}
    >
      <FrontendShellRoot
        data-tma-shell-polish="viewport-theme-backbutton-safe-area"
        data-public-shell-route={isAdminRoute ? "admin" : "public"}
        className={
          "bg-[var(--tg-bg)] efhc-shell efhc-game-shell " +
          "efhc-independent-shell efhc-tma-shell"
        }
        style={{
          minHeight: "var(--tg-viewport-height)",
          paddingBottom: shellBottomPadding,
        }}
      >
        <a className="efhc-skip-link" href="#efhc-main-content">
          {t("onboarding.skip")}
        </a>
        <NetworkStatus t={t} />
        <FrontendShellFrame className="efhc-independent-shell_frame">
        <GlobalHeader
          username={username}
          avatarUrl={avatarUrl}
          level={level}
          isVip={props.snapshot?.profile?.is_vip || props.isVip}
          hasActiv={props.snapshot?.profile?.has_activ || false}
          mainBalance={props.snapshot?.profile?.main_balance || "0"}
          bonusBalance={props.snapshot?.profile?.bonus_balance || "0"}
          walletConnected={walletConnected}
          isAdmin={props.isAdmin}
          onAvatar={() => {
            onTap("tap");
            openProfile();
          }}
          onDeposit={() => openDeposit()}
          onOpenWallet={() => {
            void openWalletConnect();
          }}
        />


        <FrontendShellMain
          id="efhc-main-content"
          tabIndex={-1}
          className="efhc-main efhc-game-shell_main"
          style={{
            paddingBottom: shellBottomPadding,
          }}
        >
          {showBrowserLoginDemo ? <BrowserLoginDemo t={t} /> : null}
          {props.children}
        </FrontendShellMain>
        </FrontendShellFrame>

        {!isAdminRoute && (
          <nav
            className={
              "fixed bottom-0 left-0 right-0 z-30 " +
              "efhc-nav efhc-game-nav"
            }
            style={{ paddingBottom: "var(--efhc-safe-bottom)" }}
          >
            <div className="efhc-game-nav_inner">
              <div
                className={
                  "efhc-pill efhc-game-nav_grid"
                }
                data-nav-geometry="wide-rounded-six"
                data-nav-icon-system="rounded-outline-v2"
              >
                {bottom.map((item) => (
                  <NavItem
                    key={item.key}
                    href={item.href}
                    active={
                      item.href === "/"
                        ? router.pathname === "/"
                        : router.pathname === item.href ||
                          router.pathname.startsWith(`${item.href}/`)
                    }
                    visualLabel={item.visualLabel}
                    localizedLabel={t(item.key)}
                    navKey={item.key}
                    icon={<AppNavIcon kind={item.kind} />}
                    onNav={() => onTap("nav")}
                  />
                ))}
              </div>
            </div>
          </nav>
        )}

        {toasts.length ? (
          <div
            className={
              "fixed left-0 right-0 bottom-24 z-40 " +
              "pointer-events-none"
            }
          >
            <div className="max-w-xl mx-auto px-4 grid gap-2">
              {toasts.map((item) => (
                <div
                  key={item.id}
                  role={item.kind === "error" ? "alert" : "status"}
                  aria-live={item.kind === "error" ? "assertive" : "polite"}
                  aria-atomic="true"
                  className={
                    "pointer-events-none rounded-2xl px-4 py-3 " +
                    "text-sm backdrop-blur " +
                    "bg-[var(--tg-secondary-bg)] " +
                    "text-[var(--tg-text)] border " +
                    "border-[color:var(--tg-hint)]"
                  }
                >
                  {item.msg}
                </div>
              ))}
            </div>
          </div>
        ) : null}


        <DepositModal
          open={depositOpen}
          onClose={() => setDepositOpen(false)}
          tg_id={props.tg_id}
        />
      </FrontendShellRoot>
    </LayoutContext.Provider>
  );
}
