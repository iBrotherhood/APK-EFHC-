import React, { useMemo } from "react";
import {
  AdminActionTable,
  AdminChartCard,
  AdminConfirmationBlock,
  AdminEmptyState,
  AdminFilterBar,
  AdminFlowMapCard,
  AdminKpiCard,
  AdminSectionHeader,
  AdminStatusBadge,
} from "./AdminDashboardUiKit";
import type { AdminWithdrawOutcomePreviewResponse } from "../../lib/api/generated/adminSeams";
import { formatD8ToHuman } from "../../lib/format";
import {
  adminWithdrawOutcomeLabel,
  adminWithdrawStatusLabel,
} from "../../lib/humanLabels";

type WithdrawalLike = {
  id: number;
  tg_id: number;
  amount_efhc: string;
  status: string;
  external_address: string | null;
  is_vip: boolean;
  payout_asset?: string | null;
  tonconnect_transport_kind?: string | null;
};

type Props = {
  items: WithdrawalLike[];
  selected: WithdrawalLike | null;
  selectedId: number | null;
  status: string;
  vipOnly: boolean;
  loading: boolean;
  repairBusy: boolean;
  repairNote?: string | null;
  previewMode: string;
  previewLoading: boolean;
  preview?: AdminWithdrawOutcomePreviewResponse | null;
  onStatusChange: (value: string) => void;
  onVipOnlyChange: (value: boolean) => void;
  onSelect: (id: number) => void;
  onRefresh: () => void;
  onRepair: () => void;
  onPreviewModeChange: (value: string) => void;
};

function countByStatus(items: WithdrawalLike[], status: string): number {
  return items.filter((item) => item.status === status).length;
}

function toneForStatus(status: string) {
  if (status === "PAID") return "success" as const;
  if (status === "PENDING") return "warning" as const;
  if (status === "REJECTED" || status === "CANCELED") {
    return "neutral" as const;
  }
  return "primary" as const;
}

function shortAddress(value: string | null): string {
  if (!value) return "адрес не задан";
  if (value.length <= 18) return value;
  return `${value.slice(0, 8)}…${value.slice(-8)}`;
}

function statusHint(status: string): string {
  if (status === "PENDING") return "ожидает действия оператора";
  if (status === "PAID") return "выплата завершена";
  if (status === "REJECTED") return "заявка отклонена";
  if (status === "CANCELED") return "заявка отменена";
  if (status === "ERROR") return "требует проверки";
  return "операторское состояние";
}

export function AdminWithdrawalsMobileDecisionPanel(props: Props) {
  const pending = countByStatus(props.items, "PENDING");
  const paid = countByStatus(props.items, "PAID");
  const rejected = countByStatus(props.items, "REJECTED");
  const canceled = countByStatus(props.items, "CANCELED");
  const error = countByStatus(props.items, "ERROR");

  const visibleDeck = useMemo(() => props.items.slice(0, 8), [props.items]);

  const selectedAmount = props.selected
    ? `${formatD8ToHuman(props.selected.amount_efhc)} EFHC`
    : "—";

  return (
    <section
      className="efhc-admin-withdraw-mobile"
      data-admin-withdraw-mobile-decision-cycle="1328"
      data-admin-sandbox-source="ui-main:data-table mobile drawer pattern; section-cards; chart-area-interactive; MaterialM dashboard cards"
    >
      <AdminSectionHeader
        eyebrow="Операторский мобильный шаблон"
        title="Мобильный центр решений по выводам"
        subtitle={
          "Выводы работают как строгая панель состояний: ожидание, " +
          "выплата, отклонение, отмена и отдельная проверка ошибки."
        }
        actions={
          <button
            type="button"
            className="efhc-admin-live-dashboard_live"
            onClick={props.onRefresh}
            disabled={props.loading}
          >
            {props.loading ? "Обновляется" : "Обновить"}
          </button>
        }
      />

      <AdminFilterBar
        groups={[
          {
            label: "Статус",
            value: props.status,
            options: [
              { key: "PENDING", label: `Ожидает ${pending}` },
              { key: "PAID", label: `Выплачено ${paid}` },
              { key: "REJECTED", label: `Отклонено ${rejected}` },
              { key: "CANCELED", label: `Отменено ${canceled}` },
              { key: "ERROR", label: `Ошибка ${error}` },
            ],
            onChange: props.onStatusChange,
          },
          {
            label: "Слой",
            value: props.vipOnly ? "vip" : "all",
            options: [
              { key: "all", label: "Все" },
              { key: "vip", label: "VIP" },
            ],
            onChange: (value) => props.onVipOnlyChange(value === "vip"),
          },
          {
            label: "Предпросмотр",
            value: props.previewMode,
            options: [
              { key: "auto", label: "Авто" },
              { key: "success", label: "Успех" },
              { key: "reject", label: "Отклонение" },
            ],
            onChange: props.onPreviewModeChange,
          },
        ]}
      />

      <div className="efhc-admin-withdraw-mobile_kpis">
        <AdminKpiCard
          label="Всего в текущем фильтре"
          value={props.items.length}
          meta="мобильная очередь"
          tone="primary"
        />
        <AdminKpiCard
          label="Ожидает"
          value={pending}
          meta="первый приоритет"
          tone="warning"
        />
        <AdminKpiCard
          label="Выплачено"
          value={paid}
          meta="финальный статус"
          tone="success"
        />
        <AdminKpiCard
          label="Отклонено / отменено"
          value={rejected + canceled}
          meta="финальные отказы"
          tone="neutral"
        />
      </div>

      <AdminFlowMapCard
        title="Дорожка решения оператора"
        nodes={[
          {
            label: "1. Заявка",
            value: props.selected ? `#${props.selected.id}` : "нет",
            hint: props.selected
              ? `tg_id ${props.selected.tg_id}`
              : "выберите карту",
            active: Boolean(props.selected),
          },
          {
            label: "2. Удержание",
            value: selectedAmount,
            hint: "EFHC удержан до результата",
            active: Boolean(props.selected),
          },
          {
            label: "3. Выплата",
            value: props.selected?.payout_asset || "EFHC",
            hint:
              props.selected?.tonconnect_transport_kind ||
              "TonConnect или ручной контроль",
            active:
              props.selected?.status === "PENDING" ||
              props.selected?.status === "ERROR",
          },
          {
            label: "4. Результат",
            value: props.selected
                ? adminWithdrawStatusLabel(props.selected.status)
                : "—",
            hint: props.selected
              ? statusHint(props.selected.status)
              : "нет выбранного кейса",
            active: Boolean(props.selected),
          },
        ]}
      />

      <div className="efhc-admin-withdraw-mobile_grid">
        <AdminChartCard
          title="Очередь решений"
          subtitle="Карточки адаптированы под палец и экран телефона"
          meta={<AdminStatusBadge label="mobile-first" tone="primary" />}
        >
          {visibleDeck.length ? (
            <div className="efhc-admin-withdraw-mobile_deck">
              {visibleDeck.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  className="efhc-admin-withdraw-mobile_card"
                  data-selected={
                    props.selectedId === item.id ? "true" : "false"
                  }
                  onClick={() => props.onSelect(item.id)}
                >
                  <span className="efhc-admin-withdraw-mobile_card-head">
                    <strong>#{item.id}</strong>
                    <AdminStatusBadge
                      label={adminWithdrawStatusLabel(item.status)}
                      tone={toneForStatus(item.status)}
                    />
                  </span>
                  <span className="efhc-admin-withdraw-mobile_amount">
                    {formatD8ToHuman(item.amount_efhc)} EFHC
                  </span>
                  <span className="efhc-admin-withdraw-mobile_meta">
                    tg_id {item.tg_id} · {item.is_vip ? "VIP" : "обычная"}
                  </span>
                  <span className="efhc-admin-withdraw-mobile_address">
                    {shortAddress(item.external_address)}
                  </span>
                </button>
              ))}
            </div>
          ) : (
            <AdminEmptyState
              title="Нет заявок в выбранном слое"
              text="Смените статус или отключите VIP-фильтр."
            />
          )}
        </AdminChartCard>

        <AdminActionTable
          title="Выбранная заявка"
          rows={[
            {
              label: "Номер",
              value: props.selected ? `#${props.selected.id}` : "—",
              hint: "операторский номер",
            },
            {
              label: "Статус",
              value: props.selected
                ? adminWithdrawStatusLabel(props.selected.status)
                : "—",
              hint: props.selected
                ? statusHint(props.selected.status)
                : "нет выбора",
            },
            {
              label: "Сумма",
              value: selectedAmount,
              hint: "только основной EFHC доступен для вывода",
            },
            {
              label: "Кошелёк",
              value: shortAddress(props.selected?.external_address || null),
              hint: "не редактируется вручную",
            },
            {
              label: "Предпросмотр",
              value: props.previewLoading
                ? "загрузка"
                : adminWithdrawOutcomeLabel(
                    props.preview?.bundle.outcome_kind,
                  ),
              hint: "локальный предпросмотр результата",
            },
          ]}
        />
      </div>

      <AdminConfirmationBlock
        title="Защита финальных статусов"
        text={
          "Выплачено, отклонено и отменено являются финальными " +
          "зонами контроля. Операторская интерактивность помогает " +
          "выбирать и проверять заявку, но не меняет экономику вывода " +
          "и не обходит подтверждение."
        }
        confirmed
      />

      <div className="efhc-admin-withdraw-mobile_actions">
        <button
          type="button"
          onClick={props.onRefresh}
          disabled={props.loading}
        >
          {props.loading ? "Обновление…" : "Обновить очередь"}
        </button>
        <button
          type="button"
          onClick={props.onRepair}
          disabled={props.repairBusy || props.loading}
        >
          {props.repairBusy ? "Проверка…" : "Проверить удержание/возврат"}
        </button>
      </div>

      {props.repairNote ? (
        <AdminConfirmationBlock
          title="Последняя проверка согласованности"
          text={props.repairNote}
          confirmed
        />
      ) : null}
    </section>
  );
}
