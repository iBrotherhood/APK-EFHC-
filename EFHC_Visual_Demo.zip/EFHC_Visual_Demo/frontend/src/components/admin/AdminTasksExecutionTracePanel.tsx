import React, { useMemo } from "react";
import {
  AdminActionTable,
  AdminChartCard,
  AdminConfirmationBlock,
  AdminEmptyState,
  AdminErrorState,
  AdminFlowMapCard,
  AdminKpiCard,
  AdminSectionHeader,
  AdminStatusBadge,
} from "./AdminDashboardUiKit";

type TraceLike = {
  id: number;
  tg_id: number;
  amount: string;
  direction: string;
  balance_type: string;
  reason: string;
  idempotency_key: string;
  created_at: string;
};

type Props = {
  traces: TraceLike[];
  loading: boolean;
  error: string | null;
  cursor: string | null;
  selectedTaskTitle: string | null;
  onRefresh: () => void;
  onLoadMore: () => void;
};

function shortKey(value: string): string {
  const raw = String(value || "").trim();
  if (!raw) return "no-key";
  if (raw.length <= 14) return raw;
  return `${raw.slice(0, 8)}…${raw.slice(-4)}`;
}

function taskReason(value: string): string {
  const raw = String(value || "").trim();
  if (!raw) return "task trace";
  if (raw.startsWith("task_bonus:")) {
    return raw.replace("task_bonus:", "task:");
  }
  return raw;
}

export function AdminTasksExecutionTracePanel(props: Props) {
  const creditCount = props.traces.filter(
    (item) => item.direction === "credit",
  ).length;
  const bonusCount = props.traces.filter(
    (item) => item.balance_type === "bonus",
  ).length;
  const latestTrace = props.traces[0] || null;
  const visible = useMemo(() => props.traces.slice(0, 8), [props.traces]);

  return (
    <section
      className="efhc-admin-tasks-trace"
      data-admin-tasks-execution-trace-boundary="1342"
    >
      <AdminSectionHeader
        eyebrow="work pass · execution trace boundary"
        title="След исполнения Tasks"
        subtitle={
          "Админ видит только санитарный trace начислений и решений. " +
          "Публичная история выполнения заданий не возвращается."
        }
        actions={
          <button type="button" onClick={props.onRefresh}>
            Обновить trace
          </button>
        }
      />

      <div className="efhc-admin-tasks-trace_kpis">
        <AdminKpiCard
          label="Trace rows"
          value={props.traces.length}
          meta="task_bonus ledger"
          hint="admin-only surface"
          tone="primary"
        />
        <AdminKpiCard
          label="Credit"
          value={creditCount}
          meta="bank ledger"
          hint="выплата не идёт из UI напрямую"
          tone="success"
        />
        <AdminKpiCard
          label="Bonus lane"
          value={bonusCount}
          meta="bonus_balance"
          hint="main_balance не трогается"
          tone="warning"
        />
        <AdminKpiCard
          label="Context"
          value={props.selectedTaskTitle || "общий"}
          meta="selected task"
          hint="trace остаётся ledger-filtered"
          tone="neutral"
        />
      </div>

      <AdminFlowMapCard
        title="Tasks execution boundary"
        nodes={[
          {
            label: "1. Submission",
            value: "proof",
            hint: "карточка заявки",
            active: true,
          },
          {
            label: "2. Moderation",
            value: "approve / reject",
            hint: "operator decision",
            active: true,
          },
          {
            label: "3. Bank credit",
            value: "task_bonus",
            hint: "transactions_service",
            active: creditCount > 0,
          },
          {
            label: "4. Trace",
            value: "sanitized",
            hint: "без raw payload dump",
            active: props.traces.length > 0,
          },
        ]}
      />

      <AdminChartCard
        title="Task bonus trace"
        subtitle="Только админский ledger-срез reason=task_bonus"
        meta={<AdminStatusBadge label="admin-only" tone="warning" />}
      >
        {props.error ? (
          <AdminErrorState title="Trace недоступен" text={props.error} />
        ) : visible.length ? (
          <div className="efhc-admin-tasks-trace_list">
            {visible.map((item) => (
              <article
                key={item.id}
                className="efhc-admin-tasks-trace_item"
              >
                <div>
                  <strong>#{item.id} · tg_id {item.tg_id}</strong>
                  <span>{taskReason(item.reason)}</span>
                </div>
                <div>
                  <b>{item.amount} EFHC</b>
                  <small>
                    {item.direction} · {item.balance_type} · {item.created_at}
                  </small>
                  <small>idk {shortKey(item.idempotency_key)}</small>
                </div>
              </article>
            ))}
          </div>
        ) : (
          <AdminEmptyState
            title="Trace пуст"
            text="Начислений task_bonus пока нет или они ещё не загружены."
          />
        )}
      </AdminChartCard>

      <AdminActionTable
        title="Trace controls"
        rows={[
          {
            label: "Source",
            value: "admin logs transfer slice",
            hint: "reason=task_bonus",
          },
          {
            label: "Latest",
            value: latestTrace ? `#${latestTrace.id}` : "нет",
            hint: latestTrace ? latestTrace.created_at : "нет событий",
          },
          {
            label: "Next page",
            value: props.cursor ? "available" : "none",
            hint: "cursor не показывается оператору как raw payload",
          },
        ]}
      />

      <div className="efhc-admin-tasks-trace_actions">
        <button type="button" onClick={props.onRefresh}>
          Обновить trace
        </button>
        <button
          type="button"
          onClick={props.onLoadMore}
          disabled={!props.cursor || props.loading}
        >
          Загрузить ещё trace
        </button>
      </div>

      <AdminConfirmationBlock
        title="Граница видимости"
        text={
          "Trace доступен только Admin. Public Tasks по-прежнему не " +
          "показывает скрытую историю выполнений."
        }
        confirmed
      />
    </section>
  );
}
