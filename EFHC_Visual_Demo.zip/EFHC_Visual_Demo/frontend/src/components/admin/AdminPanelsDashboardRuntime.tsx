import React, { useMemo, useState } from "react";

import { formatD8ToHuman, sumScaledDown } from "../../lib/format";
import {
  AdminActionTable,
  AdminDashboardGrid,
  AdminDashboardToolbar,
  AdminFilterBar,
  AdminFlowMapCard,
  AdminFreshnessBadge,
  AdminHeatStrip,
  AdminKpiCard,
  AdminMiniBarChart,
  AdminPanelChrome,
  AdminProgressBar,
  AdminRefreshPicker,
  AdminStatusBadge,
} from "./AdminDashboardUiKit";

export const adminPanelsDashboardRuntimeVersion =
  "EFHC_ADMIN_PANELS_DASHBOARD_RUNTIME_V1";

export type AdminPanelsDashboardItem = {
  id: number;
  is_active: boolean;
  created_at: string;
  expires_at?: string | null;
  archived_at?: string | null;
  last_generated_at?: string | null;
  base_gen_per_sec?: string | null;
  generated_kwh: string;
};

export type AdminPanelsDashboardRuntimeProps = {
  items: AdminPanelsDashboardItem[];
  currentItems: AdminPanelsDashboardItem[];
  activeOnly: boolean;
  filterApplied: boolean;
  loading?: boolean;
  error?: string | null;
  updatedAt?: string;
  onRefresh: () => void;
};

type PanelScope = "all" | "active" | "archive" | "attention";

type PanelPoint = {
  id: string;
  label: string;
  value: number;
  tone?: "success" | "warning" | "info" | "neutral" | "danger";
};

const DAY_MS = 24 * 60 * 60 * 1000;
const PANEL_LIFECYCLE_DAYS = 180;
const PANEL_LIFECYCLE_MS = PANEL_LIFECYCLE_DAYS * DAY_MS;

function humanInt(value: number): string {
  return value.toLocaleString("ru-RU");
}

function parseTime(value: string | null | undefined): number | null {
  if (!value) return null;
  const ts = Date.parse(value);
  return Number.isFinite(ts) ? ts : null;
}

function pct(part: number, total: number): number {
  if (!total) return 0;
  return Math.round((part / total) * 100);
}

function sumDecimal(
  items: AdminPanelsDashboardItem[],
  field: "generated_kwh" | "base_gen_per_sec",
): string {
  return items.reduce(
    (acc, item) => sumScaledDown(acc, String(item[field] || "0"), 8),
    "0",
  );
}

function daysUntil(value: string | null | undefined): number | null {
  const ts = parseTime(value);
  if (ts === null) return null;
  return Math.ceil((ts - Date.now()) / DAY_MS);
}

function panelAgeDays(item: AdminPanelsDashboardItem): number | null {
  const created = parseTime(item.created_at);
  if (created === null) return null;
  return Math.max(0, Math.floor((Date.now() - created) / DAY_MS));
}

function lifecyclePercent(item: AdminPanelsDashboardItem): number | null {
  const created = parseTime(item.created_at);
  const expires = parseTime(item.expires_at);
  if (created === null || expires === null || expires <= created) return null;
  const elapsed = Date.now() - created;
  const total = expires - created;
  return Math.min(100, Math.max(0, Math.round((elapsed / total) * 100)));
}

function averageLifecyclePercent(items: AdminPanelsDashboardItem[]): number | null {
  const values = items
    .filter((item) => item.is_active)
    .map(lifecyclePercent)
    .filter((value): value is number => value !== null);
  if (!values.length) return null;
  return Math.round(values.reduce((acc, value) => acc + value, 0) / values.length);
}

function nextExpiryLabel(items: AdminPanelsDashboardItem[]): string {
  const activeDates = items
    .filter((item) => item.is_active)
    .map((item) => parseTime(item.expires_at))
    .filter((value): value is number => value !== null)
    .sort((a, b) => a - b);
  if (!activeDates.length) return "нет даты";
  const days = Math.ceil((activeDates[0] - Date.now()) / DAY_MS);
  if (days < 0) return "просрочено";
  if (days === 0) return "сегодня";
  return `${days} д`;
}

function scopeLabel(scope: PanelScope): string {
  if (scope === "active") return "Активные";
  if (scope === "archive") return "Архив";
  if (scope === "attention") return "Внимание";
  return "Все панели";
}

function buildPanelPoints(
  active: number,
  archived: number,
  expiringSoon: number,
  missingExpiry: number,
): PanelPoint[] {
  return [
    { id: "active", label: "active", value: active, tone: "success" },
    { id: "archive", label: "archive", value: archived, tone: "neutral" },
    {
      id: "expiring-soon",
      label: "expiring soon",
      value: expiringSoon,
      tone: "warning",
    },
    {
      id: "missing-expiry",
      label: "missing expiry",
      value: missingExpiry,
      tone: "danger",
    },
  ];
}

function freshnessLabel(props: AdminPanelsDashboardRuntimeProps): string {
  if (props.error) return "ошибка panels snapshot";
  if (props.loading) return "обновление";
  if (!props.items.length) return "panels snapshot empty";
  return "panels snapshot loaded";
}

function shortDate(value: string | null | undefined): string {
  const ts = parseTime(value);
  if (ts === null) return "—";
  return new Date(ts).toLocaleDateString("ru-RU");
}

export function AdminPanelsDashboardRuntime(
  props: AdminPanelsDashboardRuntimeProps,
) {
  const [scope, setScope] = useState<PanelScope>("all");
  const active = props.items.filter((item) => item.is_active).length;
  const archived = props.items.filter((item) => !item.is_active).length;
  const total = props.items.length;
  const activePercent = pct(active, total);
  const archivePercent = pct(archived, total);
  const expiringSoon = props.items.filter((item) => {
    if (!item.is_active) return false;
    const days = daysUntil(item.expires_at);
    return days !== null && days >= 0 && days <= 14;
  }).length;
  const missingExpiry = props.items.filter(
    (item) => item.is_active && !item.expires_at,
  ).length;
  const attentionTotal = expiringSoon + missingExpiry;
  const generatedTotal = formatD8ToHuman(sumDecimal(props.items, "generated_kwh"));
  const baseRateTotal = formatD8ToHuman(sumDecimal(props.items, "base_gen_per_sec"));
  const lifecycle = averageLifecyclePercent(props.items);
  const lifecycleLabel = lifecycle === null ? "нет backend dates" : `${lifecycle}%`;
  const hasSnapshot = Boolean(props.items.length);
  const points = useMemo(
    () => buildPanelPoints(active, archived, expiringSoon, missingExpiry),
    [active, archived, expiringSoon, missingExpiry],
  );
  const under30 = props.items.filter((item) => {
    const age = panelAgeDays(item);
    return item.is_active && age !== null && age < 30;
  }).length;
  const midLifecycle = props.items.filter((item) => {
    const age = panelAgeDays(item);
    return item.is_active && age !== null && age >= 30 && age < 120;
  }).length;
  const lateLifecycle = props.items.filter((item) => {
    const age = panelAgeDays(item);
    return item.is_active && age !== null && age >= 120;
  }).length;
  const scopedItems = props.items.filter((item) => {
    if (scope === "active") return item.is_active;
    if (scope === "archive") return !item.is_active;
    if (scope === "attention") {
      const days = daysUntil(item.expires_at);
      return item.is_active && (!item.expires_at || (days !== null && days <= 14));
    }
    return true;
  });
  const recentItems = scopedItems.slice(0, 8);
  const freshness = props.error
    ? "stale"
    : props.loading
      ? "unknown"
      : hasSnapshot
        ? "fresh"
        : "stale";

  return (
    <section
      className="efhc-admin-panels-dashboard-runtime"
      data-admin-panels-dashboard-runtime="1487"
      data-admin-panels-truth="raw-derived"
      data-admin-panels-no-synthetic="true"
      data-admin-panels-no-write-actions="true"
      data-admin-panels-no-raw-payload="true"
      data-admin-panels-no-debug-json="true"
      data-admin-panels-no-secrets="true"
      data-admin-panels-no-fake-activation-trends="true"
      data-admin-panels-lifecycle-safe="true"
      data-admin-panels-economy="read-only"
    >
      <AdminDashboardToolbar
        title="Admin Panels Dashboard"
        subtitle="Read-only lifecycle overview; activation controls stay below."
        breadcrumb="Admin / Panels"
        refresh={(
          <AdminRefreshPicker
            disabled={props.loading}
            label="Refresh mode"
            onRefresh={props.onRefresh}
            refreshLabel="Обновить panels"
            value="manual"
          />
        )}
        updatedAt={props.updatedAt || "panels snapshot"}
        freshness={(
          <AdminFreshnessBadge
            freshness={freshness}
            label={freshnessLabel(props)}
            updatedAt={props.updatedAt || "snapshot"}
          />
        )}
        filters={(
          <AdminFilterBar
            groups={[
              {
                key: "panel-scope",
                label: "Срез",
                value: scope,
                queryKey: "panel_scope",
                querySync: "safe_display_only",
                onChange: (value) => setScope(value as PanelScope),
                options: [
                  { key: "all", label: "Все" },
                  { key: "active", label: "Активные" },
                  { key: "archive", label: "Архив" },
                  { key: "attention", label: "Внимание" },
                ],
              },
            ]}
            onReset={() => setScope("all")}
            resetLabel="Сбросить"
          />
        )}
      />

      <AdminDashboardGrid>
        <AdminKpiCard
          label="Всего панелей"
          value={humanInt(total)}
          meta={props.filterApplied ? "tg filter snapshot" : "global snapshot"}
          hint="Существующий read-only list endpoint, максимум текущей выборки."
          tone="info"
        />
        <AdminKpiCard
          label="Активные"
          value={humanInt(active)}
          meta={`${activePercent}%`}
          hint="Активные панели по runtime flag без смены lifecycle logic."
          tone={active ? "success" : "neutral"}
        />
        <AdminKpiCard
          label="Архив"
          value={humanInt(archived)}
          meta={`${archivePercent}%`}
          hint="Неактивные панели в текущем snapshot."
          tone={archived ? "neutral" : "info"}
        />
        <AdminKpiCard
          label="Внимание"
          value={humanInt(attentionTotal)}
          meta={`${expiringSoon} expiring · ${missingExpiry} no expiry`}
          hint="Только marker для оператора; не меняет статусы."
          tone={attentionTotal ? "warning" : "success"}
        />
      </AdminDashboardGrid>

      <div className="efhc-admin-panels-dashboard-grid">
        <AdminPanelChrome
          title="Panel lifecycle snapshot"
          subtitle="Derived snapshot display; это не activation trend."
          status={props.error ? "error" : hasSnapshot ? "success" : "stale"}
          tone={attentionTotal ? "warning" : "success"}
          source="GET /admin/panels"
          updatedAt={props.updatedAt || "snapshot"}
        >
          <AdminMiniBarChart
            ariaLabel="Admin panels lifecycle snapshot"
            dataKind="derived"
            points={points}
          />
          <div className="efhc-admin-panels-dashboard-status-grid">
            {points.map((point) => (
              <div
                className="efhc-admin-panels-dashboard-status"
                data-admin-panel-lifecycle-status={point.id}
                key={point.id}
              >
                <span>{point.label}</span>
                <strong>{humanInt(point.value)}</strong>
              </div>
            ))}
          </div>
        </AdminPanelChrome>

        <AdminPanelChrome
          title="180-day lifecycle control"
          subtitle={`Активный display-срез: ${scopeLabel(scope)}.`}
          status={props.error ? "error" : hasSnapshot ? "success" : "stale"}
          tone={attentionTotal ? "warning" : "info"}
          source="created_at + expires_at derived display"
          updatedAt={props.updatedAt || "snapshot"}
        >
          <AdminProgressBar
            ariaLabel="Active panels ratio"
            dataKind="derived"
            label="Active panels"
            value={activePercent}
          />
          <AdminProgressBar
            ariaLabel="Archived panels ratio"
            dataKind="derived"
            label="Archived panels"
            tone="neutral"
            value={archivePercent}
          />
          <AdminProgressBar
            ariaLabel="Average lifecycle progress"
            dataKind="derived"
            label="Average lifecycle"
            tone={lifecycle === null ? "neutral" : "warning"}
            value={lifecycle ?? 0}
          />
          <div className="efhc-admin-panels-dashboard-readiness">
            <AdminStatusBadge label={`lifecycle ${lifecycleLabel}`} tone="info" />
            <AdminStatusBadge label={`next expiry ${nextExpiryLabel(props.items)}`} tone="warning" />
            <AdminStatusBadge label="180-day canon preserved" tone="success" />
          </div>
        </AdminPanelChrome>
      </div>

      <div className="efhc-admin-panels-dashboard-grid">
        <AdminPanelChrome
          title="Panel age buckets"
          subtitle="Buckets use current snapshot timestamps only."
          status={hasSnapshot ? "success" : "empty"}
          tone="neutral"
          source="derived from created_at"
          updatedAt={props.updatedAt || "snapshot"}
        >
          <AdminHeatStrip
            ariaLabel="Admin panels age buckets"
            points={[
              { id: "under-30", label: "<30d", value: under30 },
              { id: "middle", label: "30-119d", value: midLifecycle },
              { id: "late", label: "120d+", value: lateLifecycle },
              { id: "archive", label: "archive", value: archived },
            ]}
          />
          <AdminActionTable
            title="Snapshot totals"
            rows={[
              {
                label: "generated kWh",
                value: `${generatedTotal} kWh`,
                hint: "Сумма generated_kwh из текущей выборки.",
              },
              {
                label: "base rate",
                value: `${baseRateTotal} kWh/s`,
                hint: "Сумма base_gen_per_sec как audit field.",
              },
              {
                label: "loaded rows",
                value: humanInt(props.currentItems.length),
                hint: props.activeOnly
                  ? "Текущая таблица отфильтрована active-only."
                  : "Текущая таблица показывает выбранный list state.",
              },
            ]}
          />
        </AdminPanelChrome>

        <AdminPanelChrome
          title="Recent panels snapshot"
          subtitle="Safe table preview; controls are outside dashboard."
          status={recentItems.length ? "success" : "empty"}
          tone="info"
          source="GET /admin/panels"
          updatedAt={props.updatedAt || "snapshot"}
        >
          <div className="efhc-admin-panels-dashboard-table">
            {recentItems.length ? (
              recentItems.map((item) => (
                <div className="efhc-admin-panels-dashboard-row" key={item.id}>
                  <div>
                    <strong>Panel #{item.id}</strong>
                    <span>
                      {shortDate(item.created_at)} → {shortDate(item.expires_at)}
                    </span>
                  </div>
                  <div>
                    <AdminStatusBadge
                      label={item.is_active ? "Активная" : "Архив"}
                      tone={item.is_active ? "success" : "neutral"}
                    />
                    <small>{formatD8ToHuman(item.generated_kwh)} kWh</small>
                  </div>
                </div>
              ))
            ) : (
              <p className="efhc-admin-panels-dashboard-empty">
                Нет строк для выбранного display-среза.
              </p>
            )}
          </div>
        </AdminPanelChrome>
      </div>

      <AdminPanelChrome
        title="Panel dashboard safety boundary"
        subtitle="Dashboard помогает видеть lifecycle, но не управляет панелями."
        status="success"
        tone="info"
        source="existing guarded admin panel controls"
        updatedAt="static boundary"
      >
        <AdminFlowMapCard
          title="Canonical panel operator order"
          nodes={[
            {
              label: "snapshot",
              value: "read-only",
              active: true,
              hint: "Сначала посмотреть active/archive/lifecycle state.",
            },
            {
              label: "attention",
              value: humanInt(attentionTotal),
              hint: "Expiring soon и missing expiry только markers.",
            },
            {
              label: "controls",
              value: "guarded",
              hint: "Переключение активности остаётся в существующих кнопках.",
            },
            {
              label: "truth",
              value: "backend SSOT",
              hint: "Dashboard не меняет 180-day lifecycle и генерацию.",
            },
          ]}
        />
        <p className="efhc-admin-panels-dashboard-boundary">
          Dashboard не вызывает write endpoints, не меняет active/archive
          логику, не создаёт fake activation trends и не скрывает backend
          defect через frontend workaround.
        </p>
      </AdminPanelChrome>
    </section>
  );
}
