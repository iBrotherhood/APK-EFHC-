import React, { useMemo, useState } from "react";

import {
  AdminDashboardGrid,
  AdminDashboardToolbar,
  AdminFilterBar,
  AdminFlowMapCard,
  AdminFreshnessBadge,
  AdminHeatStrip,
  AdminKpiCard,
  AdminMiniBarChart,
  AdminPanelChrome,
  AdminProgressBar,
  AdminRefreshPicker,
  AdminStatusBadge,
} from "./AdminDashboardUiKit";

export const adminDepositsDashboardRuntimeVersion =
  "EFHC_ADMIN_DEPOSITS_DASHBOARD_RUNTIME_V1";

export type AdminDepositsRuntimeSummary = {
  ok?: boolean;
  release_mode?: string;
  automation_mode?: string;
  release_gate_note?: string;
  primary_path?: string;
  fallback_path?: string;
  pending_manual_count?: number;
  error_retry_count?: number;
  error_user_count?: number;
  auto_credited_count?: number;
  pending_intents_count?: number;
};

type DepositScope =
  | "pipeline"
  | "exceptions"
  | "intents"
  | "credited";

type DepositPoint = {
  id: string;
  label: string;
  value: number;
  tone?: "success" | "warning" | "info" | "neutral" | "danger";
};

export type AdminDepositsDashboardRuntimeProps = {
  summary: AdminDepositsRuntimeSummary | null;
  loading?: boolean;
  error?: string | null;
  formReadyFields: number;
  rawTxState: string;
  resultFieldCount: number;
  finalResultLabel: string;
  finalResultTone: "success" | "warning" | "neutral";
  updatedAt?: string;
  onRefresh: () => void;
};

function count(value: number | undefined): number {
  return Number.isFinite(value) ? Number(value) : 0;
}

function human(value: number): string {
  return value.toLocaleString("ru-RU");
}

function pct(part: number, total: number): number {
  if (!total) return 0;
  return Math.round((part / total) * 100);
}

function scopeLabel(scope: DepositScope): string {
  if (scope === "exceptions") return "Исключения";
  if (scope === "intents") return "Интенты";
  if (scope === "credited") return "Зачислено";
  return "Pipeline";
}

function buildDepositPoints(
  summary: AdminDepositsRuntimeSummary | null,
): DepositPoint[] {
  return [
    {
      id: "credited",
      label: "credited",
      value: count(summary?.auto_credited_count),
      tone: "success",
    },
    {
      id: "pending-manual",
      label: "manual",
      value: count(summary?.pending_manual_count),
      tone: "warning",
    },
    {
      id: "retry",
      label: "retry",
      value: count(summary?.error_retry_count),
      tone: "info",
    },
    {
      id: "user-error",
      label: "user error",
      value: count(summary?.error_user_count),
      tone: "danger",
    },
    {
      id: "pending-intents",
      label: "pending intents",
      value: count(summary?.pending_intents_count),
      tone: "neutral",
    },
  ];
}

function freshnessLabel(props: AdminDepositsDashboardRuntimeProps): string {
  if (props.error) return "ошибка runtime summary";
  if (props.loading) return "обновление";
  if (!props.summary) return "summary pending";
  return "summary loaded";
}

export function AdminDepositsDashboardRuntime(
  props: AdminDepositsDashboardRuntimeProps,
) {
  const [scope, setScope] = useState<DepositScope>("pipeline");
  const points = useMemo(
    () => buildDepositPoints(props.summary),
    [props.summary],
  );
  const autoCredited = count(props.summary?.auto_credited_count);
  const pendingManual = count(props.summary?.pending_manual_count);
  const retry = count(props.summary?.error_retry_count);
  const userError = count(props.summary?.error_user_count);
  const pendingIntents = count(props.summary?.pending_intents_count);
  const exceptionTotal = pendingManual + retry + userError;
  const observedTotal = autoCredited + exceptionTotal + pendingIntents;
  const automationPercent = pct(autoCredited, observedTotal);
  const exceptionPercent = pct(exceptionTotal, observedTotal);
  const pendingIntentsPercent = pct(pendingIntents, observedTotal);
  const hasSummary = Boolean(props.summary);
  const freshness = props.error
    ? "stale"
    : props.loading
      ? "unknown"
      : hasSummary
        ? "fresh"
        : "stale";

  return (
    <section
      className="efhc-admin-deposits-dashboard-runtime"
      data-admin-deposits-dashboard-runtime="1485"
      data-admin-deposits-truth="raw-derived"
      data-admin-deposits-no-synthetic="true"
      data-admin-deposits-no-write-actions="true"
      data-admin-deposits-no-raw-payload="true"
      data-admin-deposits-no-debug-json="true"
      data-admin-deposits-no-secrets="true"
      data-admin-deposits-money-path="read-only"
    >
      <AdminDashboardToolbar
        title="Admin Deposits Dashboard"
        subtitle="Read-only money-path overview для EFHC deposits."
        breadcrumb="Admin / EFHC Deposits"
        refresh={(
          <AdminRefreshPicker
            label="Refresh mode"
            onRefresh={props.onRefresh}
            refreshLabel="Обновить deposits"
            value="manual"
          />
        )}
        updatedAt={props.updatedAt || "runtime summary snapshot"}
        freshness={(
          <AdminFreshnessBadge
            freshness={freshness}
            label={freshnessLabel(props)}
            updatedAt={props.updatedAt || "snapshot"}
          />
        )}
        filters={(
          <AdminFilterBar
            groups={[
              {
                key: "deposit-scope",
                label: "Срез",
                value: scope,
                queryKey: "deposit_scope",
                querySync: "safe_display_only",
                onChange: (value) => setScope(value as DepositScope),
                options: [
                  { key: "pipeline", label: "Pipeline" },
                  { key: "exceptions", label: "Исключения" },
                  { key: "intents", label: "Интенты" },
                  { key: "credited", label: "Зачислено" },
                ],
              },
            ]}
            onReset={() => setScope("pipeline")}
            resetLabel="Сбросить"
          />
        )}
      />

      <AdminDashboardGrid>
        <AdminKpiCard
          label="Автозачислено"
          value={human(autoCredited)}
          meta="credited"
          hint="Завершённые строки watcher automation."
          tone="success"
        />
        <AdminKpiCard
          label="Manual backlog"
          value={human(pendingManual)}
          meta="pending_manual"
          hint="Строки, где нужен replay или exception path."
          tone={pendingManual ? "warning" : "neutral"}
        />
        <AdminKpiCard
          label="Retry / user errors"
          value={human(retry + userError)}
          meta={`${retry} retry · ${userError} user`}
          hint="Ошибки показываются как очередь внимания оператора."
          tone={retry + userError ? "danger" : "neutral"}
        />
        <AdminKpiCard
          label="Pending intents"
          value={human(pendingIntents)}
          meta="payment_intents"
          hint="PENDING deposit_efhc intents из read-only summary."
          tone={pendingIntents ? "warning" : "neutral"}
        />
      </AdminDashboardGrid>

      <div className="efhc-admin-deposits-dashboard-grid">
        <AdminPanelChrome
          title="Money-path pipeline"
          subtitle="Derived snapshot display; не real time-series."
          status={hasSummary ? "success" : "stale"}
          tone={exceptionTotal ? "warning" : "success"}
          source="GET /admin/efhc-deposits/runtime-summary"
          updatedAt={props.updatedAt || "snapshot"}
        >
          <AdminMiniBarChart
            ariaLabel="EFHC deposits pipeline snapshot"
            dataKind="derived"
            points={points}
          />
          <div className="efhc-admin-deposits-dashboard-status-grid">
            {points.map((point) => (
              <div
                className="efhc-admin-deposits-dashboard-status"
                data-deposit-pipeline-status={point.id}
                key={point.id}
              >
                <span>{point.label}</span>
                <strong>{human(point.value)}</strong>
              </div>
            ))}
          </div>
        </AdminPanelChrome>

        <AdminPanelChrome
          title="Automation readiness"
          subtitle={`Активный display-срез: ${scopeLabel(scope)}.`}
          status={props.error ? "error" : hasSummary ? "success" : "stale"}
          tone={exceptionTotal ? "warning" : "success"}
          source="runtime summary + local operator state"
          updatedAt={props.updatedAt || "snapshot"}
        >
          <AdminProgressBar
            ariaLabel="Automation credited ratio"
            dataKind="derived"
            label="Automation credited"
            value={automationPercent}
          />
          <AdminProgressBar
            ariaLabel="Exception backlog ratio"
            dataKind="derived"
            label="Exception backlog"
            tone={exceptionTotal ? "warning" : "success"}
            value={exceptionPercent}
          />
          <AdminProgressBar
            ariaLabel="Pending intents ratio"
            dataKind="derived"
            label="Pending intents"
            tone={pendingIntents ? "warning" : "neutral"}
            value={pendingIntentsPercent}
          />
          <p className="efhc-admin-deposits-dashboard-coverage-note">
            Automation credited + exception backlog + pending intents cover the
            observedTotal denominator. Pending intents are displayed separately
            so the operator does not see a missing percent.
          </p>
          <div className="efhc-admin-deposits-dashboard-readiness">
            <AdminStatusBadge
              label={props.rawTxState === "invalid" ? "raw JSON issue" : "input guard"}
              tone={props.rawTxState === "invalid" ? "danger" : "neutral"}
            />
            <AdminStatusBadge
              label={`${props.formReadyFields} fields ready`}
              tone={props.formReadyFields ? "info" : "neutral"}
            />
            <AdminStatusBadge
              label={props.finalResultLabel}
              tone={props.finalResultTone}
            />
          </div>
        </AdminPanelChrome>
      </div>

      <AdminPanelChrome
        title="Deposit route safety boundary"
        subtitle="Dashboard показывает состояние, но не исполняет обработку."
        status="success"
        tone="info"
        source="existing guarded admin route"
        updatedAt="static boundary"
      >
        <AdminFlowMapCard
          title="Canonical operator order"
          nodes={[
            {
              label: "runtime summary",
              value: "read-only",
              active: true,
              hint: "Сначала посмотреть состояние watcher path.",
            },
            {
              label: "replay",
              value: "guarded",
              hint: "Повтор automated path только по tx_hash.",
            },
            {
              label: "exception path",
              value: "last step",
              hint: "Ручная обработка только после проверки replay.",
            },
            {
              label: "final result",
              value: props.resultFieldCount || "—",
              hint: "Ответ обработки остаётся в detail shell.",
            },
          ]}
        />
        <AdminHeatStrip
          ariaLabel="Deposit dashboard truth boundary"
          points={[
            { id: "read-only", label: "read-only", value: hasSummary ? 1 : 0 },
            { id: "no-secrets", label: "no secrets", value: 1 },
            { id: "no-payload", label: "no payload", value: 1 },
            { id: "no-bypass", label: "no bypass", value: 1 },
          ]}
        />
        <p className="efhc-admin-deposits-dashboard-boundary">
          Dashboard не вызывает money-changing endpoints, не создаёт
          idempotency key и не показывает raw payload/debug JSON. Replay,
          exception processing and force fulfill stay in existing guarded
          controls below this read-only overview.
        </p>
      </AdminPanelChrome>
    </section>
  );
}
