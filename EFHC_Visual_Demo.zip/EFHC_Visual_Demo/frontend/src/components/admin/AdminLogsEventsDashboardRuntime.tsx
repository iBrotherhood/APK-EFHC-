import React, { useCallback, useEffect, useMemo, useState } from "react";

import { useLargeAdminFilter } from "../../hooks/admin/useLargeAdminFilter";

import {
  ADMIN_LOGS_TRANSFERS_PATH,
} from "../../lib/api/generated/adminSeams";

import {
  AdminActionTable,
  AdminDashboardGrid,
  AdminDashboardToolbar,
  AdminFilterBar,
  AdminFreshnessBadge,
  AdminHeatStrip,
  AdminKpiCard,
  AdminMiniBarChart,
  AdminPanelChrome,
  AdminRefreshPicker,
  AdminStatusBadge,
} from "./AdminDashboardUiKit";
import { adminSafeLoadError } from "../../lib/adminError";
import { useAdminLinkedTransport } from "../../queries/useAdminLinkedTransport";
import { isAdminVisualProofMode } from "../../proof/visualProofMode";

export const adminLogsEventsDashboardRuntimeVersion =
  "EFHC_ADMIN_LOGS_EVENTS_DASHBOARD_RUNTIME_V1";

type AdminLogTone = "success" | "warning" | "danger" | "neutral" | "info";
type SeverityFilter = "all" | "attention" | "success" | "info";
type SourceFilter = "all" | "task" | "bank" | "withdraw" | "deposit";
type TimeFilter = "latest" | "hour" | "day";

type TransferLogItem = {
  id: number;
  amount: string;
  direction: string;
  balance_type: string;
  reason: string;
  created_at: string;
};

type TransferLogsOut = {
  ok: boolean;
  items: TransferLogItem[];
  next_cursor: string | null;
};

type EventPoint = {
  id: string;
  label: string;
  value: number;
  tone: AdminLogTone;
};

type DashboardEvent = {
  id: string;
  title: string;
  description: string;
  severity: "success" | "attention" | "info";
  source: SourceFilter;
  amount: number;
  amountLabel: string;
  balanceLabel: string;
  directionLabel: string;
  createdAt: string;
  redactedFields: number;
};

const EMPTY_RESPONSE: TransferLogsOut = {
  ok: false,
  items: [],
  next_cursor: null,
};

const VISUAL_PROOF_RESPONSE: TransferLogsOut = {
  ok: true,
  items: [
    {
      id: 156801,
      amount: "100.00000000",
      direction: "user_credit",
      balance_type: "main",
      reason: "deposit credited · signature [REDACTED]",
      created_at: "2026-07-21T10:30:00Z",
    },
    {
      id: 156802,
      amount: "25.00000000",
      direction: "user_debit",
      balance_type: "main",
      reason: "withdraw review · proof <redacted>",
      created_at: "2026-07-21T10:31:00Z",
    },
    {
      id: 156803,
      amount: "5.00000000",
      direction: "user_credit",
      balance_type: "bonus",
      reason: "task bonus · safe summary",
      created_at: "2026-07-21T10:32:00Z",
    },
  ],
  next_cursor: null,
};

const SOURCE_OPTIONS: Array<{ key: SourceFilter; label: string }> = [
  { key: "all", label: "Все источники" },
  { key: "task", label: "Задачи" },
  { key: "bank", label: "Банк" },
  { key: "withdraw", label: "Выводы" },
  { key: "deposit", label: "Депозиты" },
];

const SEVERITY_OPTIONS: Array<{ key: SeverityFilter; label: string }> = [
  { key: "all", label: "Все статусы" },
  { key: "attention", label: "Внимание" },
  { key: "success", label: "Успешные" },
  { key: "info", label: "Инфо" },
];

const TIME_OPTIONS: Array<{ key: TimeFilter; label: string }> = [
  { key: "latest", label: "Последние" },
  { key: "hour", label: "За час" },
  { key: "day", label: "За сутки" },
];

function safeText(value: unknown): string {
  const text = String(value ?? "").trim();
  return text || "—";
}

function amountNumber(value: string): number {
  const parsed = Number(String(value || "0").replace(/,/g, "."));
  return Number.isFinite(parsed) ? parsed : 0;
}

function amountLabel(value: string): string {
  return amountNumber(value).toLocaleString("ru-RU", {
    maximumFractionDigits: 8,
  });
}

function balanceTypeLabel(value: string): string {
  if (value === "main") return "основной баланс";
  if (value === "bonus") return "бонусный баланс";
  if (value === "bank") return "банк";
  return "тип баланса скрыт";
}

function directionLabel(value: string): string {
  if (value === "user_credit") return "зачисление пользователю";
  if (value === "user_debit") return "списание пользователя";
  if (value === "bank_credit") return "зачисление банку";
  if (value === "bank_debit") return "списание банка";
  return "операция";
}

function sourceFromReason(reason: string): SourceFilter {
  const value = reason.toLowerCase();
  if (value.includes("task")) return "task";
  if (value.includes("withdraw")) return "withdraw";
  if (value.includes("deposit") || value.includes("ton")) return "deposit";
  if (value.includes("bank") || value.includes("mint") || value.includes("burn")) {
    return "bank";
  }
  return "all";
}

function eventSeverity(item: TransferLogItem): DashboardEvent["severity"] {
  const reason = item.reason.toLowerCase();
  if (reason.includes("reject") || reason.includes("fail")) return "attention";
  if (item.direction === "user_debit") return "attention";
  if (item.direction === "user_credit") return "success";
  return "info";
}

function severityTone(severity: DashboardEvent["severity"]): AdminLogTone {
  if (severity === "success") return "success";
  if (severity === "attention") return "warning";
  return "info";
}

function titleForEvent(item: TransferLogItem): string {
  const source = sourceFromReason(item.reason);
  if (source === "task") return "Task bonus event";
  if (source === "withdraw") return "Withdrawal money-path event";
  if (source === "deposit") return "Deposit ledger event";
  if (source === "bank") return "Bank ledger event";
  return "Ledger event";
}

function toEvent(item: TransferLogItem): DashboardEvent {
  const severity = eventSeverity(item);
  const redactedFields = [
    "[REDACTED]",
    "•••",
    "<redacted>",
  ].filter((marker) => item.reason.includes(marker)).length;
  return {
    id: String(item.id),
    title: titleForEvent(item),
    description: safeText(item.reason),
    severity,
    source: sourceFromReason(item.reason),
    amount: amountNumber(item.amount),
    amountLabel: amountLabel(item.amount),
    balanceLabel: balanceTypeLabel(item.balance_type),
    directionLabel: directionLabel(item.direction),
    createdAt: safeText(item.created_at),
    redactedFields,
  };
}

function withinTimeFilter(event: DashboardEvent, filter: TimeFilter): boolean {
  if (filter === "latest") return true;
  const ts = Date.parse(event.createdAt);
  if (!Number.isFinite(ts)) return true;
  const diffMs = Date.now() - ts;
  if (filter === "hour") return diffMs <= 60 * 60 * 1000;
  return diffMs <= 24 * 60 * 60 * 1000;
}

function buildPoints(events: DashboardEvent[]): EventPoint[] {
  const attention = events.filter((event) => event.severity === "attention").length;
  const success = events.filter((event) => event.severity === "success").length;
  const info = events.filter((event) => event.severity === "info").length;
  const task = events.filter((event) => event.source === "task").length;
  const bank = events.filter((event) => event.source === "bank").length;
  const withdraw = events.filter((event) => event.source === "withdraw").length;
  const deposit = events.filter((event) => event.source === "deposit").length;
  return [
    { id: "attention", label: "Внимание", value: attention, tone: "warning" },
    { id: "success", label: "Успех", value: success, tone: "success" },
    { id: "info", label: "Инфо", value: info, tone: "info" },
    { id: "task", label: "Задачи", value: task, tone: "neutral" },
    { id: "bank", label: "Банк", value: bank, tone: "neutral" },
    { id: "withdraw", label: "Выводы", value: withdraw, tone: "warning" },
    { id: "deposit", label: "Депозиты", value: deposit, tone: "success" },
  ];
}


export function AdminLogsEventsDashboardRuntime() {
  const visualProof = isAdminVisualProofMode();
  const adminApiRequest = useAdminLinkedTransport();
  const [response, setResponse] = useState<TransferLogsOut>(
    visualProof ? VISUAL_PROOF_RESPONSE : EMPTY_RESPONSE,
  );
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [updatedAt, setUpdatedAt] = useState<string | null>(null);
  const [source, setSource] = useState<SourceFilter>("all");
  const [severity, setSeverity] = useState<SeverityFilter>("all");
  const [time, setTime] = useState<TimeFilter>("latest");
  const [visibleLimit, setVisibleLimit] = useState(24);
  const [selectedEvent, setSelectedEvent] = useState<
    DashboardEvent | null
  >(null);

  const refresh = useCallback(() => {
    setLoading(true);
    setError(null);
    void adminApiRequest<TransferLogsOut>(`${ADMIN_LOGS_TRANSFERS_PATH}?limit=80`, "GET")
      .then((next) => {
        setResponse(next);
        setUpdatedAt(new Date().toISOString());
      })
      .catch((err: unknown) => {
        setError(adminSafeLoadError(err));
        setResponse(EMPTY_RESPONSE);
        setUpdatedAt(new Date().toISOString());
      })
      .finally(() => setLoading(false));
  }, [adminApiRequest]);

  useEffect(() => {
    if (visualProof) {
      setUpdatedAt("2026-07-21T10:32:00Z");
      return;
    }
    refresh();
  }, [refresh, visualProof]);

  const events = useMemo(
    () => (response.items || []).map(toEvent),
    [response.items],
  );
  const syncEventFilter = useCallback(
    (event: DashboardEvent) => {
      const sourceOk = source === "all" || event.source === source;
      const severityOk =
        severity === "all" || event.severity === severity;
      return sourceOk && severityOk && withinTimeFilter(event, time);
    },
    [severity, source, time],
  );
  const largeFilter = useLargeAdminFilter(
    events,
    "logs",
    { now: Date.now(), severity, source, time },
    syncEventFilter,
  );
  const visibleEvents = largeFilter.filtered;
  const points = useMemo(() => buildPoints(events), [events]);
  const visiblePoints = useMemo(() => buildPoints(visibleEvents), [visibleEvents]);
  const attentionCount = events.filter((event) => event.severity === "attention").length;
  const successCount = events.filter((event) => event.severity === "success").length;
  const totalAmount = events.reduce(
    (acc, event) => acc + Math.abs(event.amount),
    0,
  );
  const freshness = error ? "stale" : loading ? "unknown" : "fresh";
  const redactedCount = events.reduce(
    (total, event) => total + event.redactedFields,
    0,
  );
  const renderedEvents = visibleEvents.slice(0, visibleLimit);

  return (
    <section
      className="efhc-admin-logs-events-dashboard efhc-dashboard-surface"
      data-admin-logs-events-dashboard-runtime="1490"
      data-admin-logs-events-truth="read-only-transfer-log-snapshot"
      data-admin-logs-events-no-write-actions="true"
      data-admin-logs-events-no-raw-payload="true"
      data-admin-logs-events-no-debug-json="true"
      data-admin-logs-events-no-secrets="true"
      data-admin-logs-events-no-fake-timeseries="true"
      data-grafana-reference-only="true"
      data-sandbox-reference-only="true"
      data-admin-worker-filter={largeFilter.workerActive ? "active" : "idle"}
    >
      <div className="efhc-admin-logs-sticky-filters">
      <AdminDashboardToolbar
        title="Logs / Events Dashboard"
        subtitle="Read-only операторская лента безопасных ledger-событий без raw payload и без секретов."
        breadcrumb="Admin / Logs"
        refresh={(
          <AdminRefreshPicker
            label="Logs refresh"
            onRefresh={refresh}
            refreshLabel="Обновить события"
            value="manual"
          />
        )}
        updatedAt={updatedAt || "snapshot pending"}
        freshness={(
          <AdminFreshnessBadge
            freshness={freshness}
            label={loading ? "загрузка" : error ? "ошибка" : "events snapshot"}
          />
        )}
        filters={(
          <AdminFilterBar
            groups={[
              {
                key: "log-source",
                label: "Источник",
                value: source,
                options: SOURCE_OPTIONS,
                onChange: (value) => setSource(value as SourceFilter),
                querySync: "disabled",
              },
              {
                key: "log-severity",
                label: "Статус",
                value: severity,
                options: SEVERITY_OPTIONS,
                onChange: (value) => setSeverity(value as SeverityFilter),
                querySync: "disabled",
              },
              {
                key: "log-time",
                label: "Период",
                value: time,
                options: TIME_OPTIONS,
                onChange: (value) => setTime(value as TimeFilter),
                querySync: "disabled",
              },
            ]}
            onReset={() => {
              setSource("all");
              setSeverity("all");
              setTime("latest");
            }}
            resetLabel="Сбросить"
          />
        )}
      />
      </div>

      <AdminDashboardGrid>
        <AdminKpiCard
          label="Всего событий"
          value={String(events.length)}
          meta="transfer-log snapshot"
          hint="GET /admin/logs/transfers?limit=80"
          tone="neutral"
        />
        <AdminKpiCard
          label="Внимание"
          value={String(attentionCount)}
          meta="derived severity"
          hint="Списания, reject/fail markers и operator attention."
          tone={attentionCount > 0 ? "warning" : "success"}
        />
        <AdminKpiCard
          label="Успешные"
          value={String(successCount)}
          meta="derived severity"
          hint="Зачисления и успешные ledger events."
          tone="success"
        />
        <AdminKpiCard
          label="Скрытые поля"
          value={String(redactedCount)}
          meta="safe redaction markers"
          hint="Исходные значения никогда не показываются."
          tone={redactedCount ? "warning" : "success"}
        />
        <AdminKpiCard
          label="Объём"
          value={amountLabel(String(totalAmount))}
          meta="EFHC abs"
          hint="Сумма абсолютных значений только для видимого snapshot."
          tone="info"
        />
      </AdminDashboardGrid>

      <AdminPanelChrome
        title="Event distribution"
        subtitle="Grafana-like status panel, но без fake history: только текущий snapshot."
        status={error ? "error" : loading ? "loading" : "success"}
        source="GET /admin/logs/transfers"
      >
        <AdminMiniBarChart
          points={visiblePoints}
          label="Видимый срез"
          unit="events"
          source="derived snapshot"
          dataKind="derived"
          ariaLabel="Admin logs derived event distribution"
        />
        <div className="mt-3 flex flex-wrap gap-2">
          {points.map((point) => (
            <AdminStatusBadge
              key={point.id}
              label={`${point.label}: ${point.value}`}
              tone={point.tone}
            />
          ))}
        </div>
      </AdminPanelChrome>

      <AdminPanelChrome
        title="Safe event feed"
        subtitle="Без raw meta, без idempotency display, без debug JSON и без секретов."
        status={visibleEvents.length === 0 ? "empty" : "success"}
        source="safe render of transfer-log rows"
      >
        <div className="efhc-admin-logs-events-dashboard__feed">
          {visibleEvents.length === 0 ? (
            <p className="text-sm text-slate-400">
              Нет событий для выбранного фильтра.
            </p>
          ) : (
            renderedEvents.map((event) => (
              <article
                key={event.id}
                className="efhc-admin-logs-events-dashboard__event efhc-native-virtual-item"
                data-admin-log-event-severity={event.severity}
                data-admin-log-redacted={
                  event.redactedFields ? "true" : "false"
                }
                tabIndex={0}
                onClick={() => setSelectedEvent(event)}
                onKeyDown={(keyEvent) => {
                  if (keyEvent.key === "Enter") {
                    setSelectedEvent(event);
                  }
                }}
              >
                <div>
                  <strong>{event.title}</strong>
                  <p>{event.description}</p>
                  <small>{event.createdAt}</small>
                </div>
                <div>
                  <AdminStatusBadge
                    label={event.severity}
                    tone={severityTone(event.severity)}
                  />
                  {event.redactedFields ? (
                    <AdminStatusBadge
                      label={`redacted · ${event.redactedFields}`}
                      tone="warning"
                    />
                  ) : null}
                  <span>{event.directionLabel}</span>
                  <span>{event.balanceLabel}</span>
                  <b>{event.amountLabel} EFHC</b>
                </div>
              </article>
            ))
          )}
        </div>
        {visibleEvents.length > renderedEvents.length ? (
          <button
            type="button"
            className="efhc-admin-log-load-more"
            onClick={() => setVisibleLimit((value) => value + 24)}
          >
            Показать следующую виртуальную порцию
          </button>
        ) : null}
      </AdminPanelChrome>

      {selectedEvent ? (
        <aside
          className="efhc-admin-log-detail-drawer"
          data-admin-log-detail-drawer="fixed-safe-summary"
        >
          <button
            type="button"
            onClick={() => setSelectedEvent(null)}
          >
            Закрыть
          </button>
          <strong>{selectedEvent.title}</strong>
          <p>{selectedEvent.description}</p>
          <dl>
            <div>
              <dt>Время</dt>
              <dd>{selectedEvent.createdAt}</dd>
            </div>
            <div>
              <dt>Скрыто полей</dt>
              <dd>{selectedEvent.redactedFields}</dd>
            </div>
            <div>
              <dt>Сумма</dt>
              <dd>{selectedEvent.amountLabel} EFHC</dd>
            </div>
          </dl>
          <small>Raw payload и скрытые значения недоступны.</small>
        </aside>
      ) : null}

      <AdminPanelChrome
        title="Events status strip"
        subtitle="StatusHistory-like визуализация текущего snapshot, не реальный timeline."
        status="success"
        source="derived snapshot, no real time-series claim"
      >
        <AdminHeatStrip
          points={visiblePoints}
          ariaLabel="Admin logs current event status strip"
          dataKind="derived"
        />
      </AdminPanelChrome>

      <AdminPanelChrome
        title="Operator drill-down boundary"
        subtitle="Dashboard помогает перейти в домены, но не выполняет действия."
        status="success"
        source="navigation-only"
      >
        <AdminActionTable
          rows={[
            {
              label: "Задачи",
              value: "task_bonus events",
              hint: "Проверять actions только на /admin/tasks.",
            },
            {
              label: "Банк",
              value: "ledger events",
              hint: "Mint/burn остаются в guarded bank flow.",
            },
            {
              label: "Выводы",
              value: "withdraw events",
              hint: "Decision flow остаётся на /admin/withdrawals.",
            },
            {
              label: "Депозиты",
              value: "deposit events",
              hint: "Replay/exception остаются на /admin/efhc-deposits.",
            },
          ]}
        />
      </AdminPanelChrome>

      <AdminPanelChrome
        title="Truth / safety boundary"
        subtitle="Логи — это наблюдение, не business truth mutation."
        status={error ? "error" : "success"}
        tone={error ? "danger" : "neutral"}
        source="dashboard contract"
      >
        <AdminActionTable
          rows={[
            {
              label: "Источник",
              value: "read-only transfer logs",
              hint: "События берутся из существующего admin endpoint.",
            },
            {
              label: "Payload",
              value: "safe summary only",
              hint: "Raw meta и debug JSON не рендерятся.",
            },
            {
              label: "Actions",
              value: "navigation/support only",
              hint: "Dashboard не меняет состояние системы.",
            },
            {
              label: "History",
              value: "snapshot only",
              hint: "Real time-series будет только после отдельного backend contract cycle.",
            },
          ]}
        />
        {error ? <p className="text-sm text-red-200">{error || null}</p> : null}
      </AdminPanelChrome>
    </section>
  );
}
