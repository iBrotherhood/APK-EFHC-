import React from "react";
import { Button } from "../ui/Button";
import { AdminModuleIcon } from "./AdminModuleIcon";

type AdminAppItem = {
  href: string;
  label: string;
  note: string;
  state: "live" | "helper" | "draft" | "deferred";
};

type Props = {
  items: AdminAppItem[];
};

function stateLabel(state: AdminAppItem["state"]): string {
  if (state === "live") return "Работает";
  if (state === "helper") return "Служебное";
  if (state === "draft") return "Черновик";
  return "Отложено";
}

export function AdminAppButtonGrid(props: Props) {
  return (
    <div className="efhc-admin-app-grid">
      {props.items.map((item) => (
        <Button
          key={item.href}
          href={item.href}
          variant="secondary"
          className="efhc-admin-app-button"
        >
          <span className="efhc-admin-app-button_icon">
            <AdminModuleIcon href={item.href} label={item.label} />
          </span>
          <span className="efhc-admin-app-button_body">
            <strong>{item.label}</strong>
            <em>{item.note}</em>
          </span>
          <span
            className={
              "efhc-admin-app-button_state "
              + `efhc-admin-app-button_state--${item.state}`
            }
          >
            {stateLabel(item.state)}
          </span>
        </Button>
      ))}
    </div>
  );
}
