import React, { useMemo, useState } from "react";
import {
  AdminActionTable,
  AdminChartCard,
  AdminFilterBar,
  AdminFlowMapCard,
  AdminKpiCard,
  AdminSectionHeader,
  AdminStatusBadge,
} from "./AdminDashboardUiKit";

type DiagnosticScope = "admin" | "public" | "release";
type DiagnosticWindow = "now" | "next" | "guard";

type DiagnosticCard = {
  key: string;
  label: string;
  value: string;
  hint: string;
  scope: DiagnosticScope;
  severity: "neutral" | "success" | "warning";
};

const CARDS: DiagnosticCard[] = [
  {
    key: "admin-diagnostics",
    label: "Admin diagnostics",
    value: "technical only",
    hint: "Маршруты и raw facts остаются только в Diagnostics.",
    scope: "admin",
    severity: "success",
  },
  {
    key: "route-health",
    label: "Route health",
    value: "visible here",
    hint: "Endpoint labels не возвращаются на business screens.",
    scope: "admin",
    severity: "neutral",
  },
  {
    key: "public-ui",
    label: "Public UI",
    value: "no debug",
    hint: "Публичные страницы получают UX-интерактив без internals.",
    scope: "public",
    severity: "success",
  },
  {
    key: "public-plan",
    label: "Public interactivity",
    value: "planned",
    hint: "Energy, Panels, Exchange, Tasks, Referrals, History.",
    scope: "public",
    severity: "warning",
  },
  {
    key: "release-core",
    label: "Release evidence",
    value: "separated",
    hint: "Diagnostics не считается бизнес-действием release-core.",
    scope: "release",
    severity: "success",
  },
  {
    key: "ci-boundary",
    label: "CI boundary",
    value: "manual",
    hint: "Workflow files остаются manual-control зоной.",
    scope: "release",
    severity: "warning",
  },
];

const WINDOW_LABELS: Record<DiagnosticWindow, string> = {
  now: "Сейчас",
  next: "Дальше",
  guard: "Guard",
};

function scopeLabel(scope: DiagnosticScope): string {
  if (scope === "admin") return "Admin";
  if (scope === "public") return "Public UI";
  return "Release";
}

function chartPath(items: DiagnosticCard[]): string {
  const max = Math.max(items.length, 1);
  return items
    .map((item, index) => {
      const x = items.length === 1
        ? 50
        : Math.round((index / (items.length - 1)) * 100);
      const base = item.severity === "success" ? 22 : 40;
      const bump = item.severity === "warning" ? 20 : 0;
      const y = Math.round(base + bump + (index % max) * 5);
      return `${index === 0 ? "M" : "L"}${x},${y}`;
    })
    .join(" ");
}

export function AdminDiagnosticsTechnicalBoundaryPanel() {
  const [scope, setScope] = useState<DiagnosticScope>("admin");
  const [window, setWindow] = useState<DiagnosticWindow>("now");
  const [selected, setSelected] = useState(0);

  const filtered = useMemo(
    () => CARDS.filter((item) => item.scope === scope),
    [scope],
  );
  const current = filtered[selected % Math.max(filtered.length, 1)];
  const publicCount = CARDS.filter((item) => item.scope === "public").length;
  const adminCount = CARDS.filter((item) => item.scope === "admin").length;
  const releaseCount = CARDS.filter((item) => item.scope === "release").length;

  return (
    <section
      className="efhc-admin-diagnostics-boundary"
      data-admin-diagnostics-boundary-cycle="1345"
      data-admin-sandbox-source="ui-main tabs; data-table; chart-area-interactive; MaterialM status cards"
    >
      <AdminSectionHeader
        eyebrow="Diagnostics Admin · technical-only"
        title="Техническая диагностика без бизнес-действий"
        subtitle={
          "Diagnostics остаётся единственным местом для route health, " +
          "endpoint labels, helper-фактов и public/admin boundary review."
        }
        actions={
          <AdminStatusBadge
            label="no business mutation"
            tone="warning"
          />
        }
      />

      <div className="efhc-admin-diagnostics-boundary_kpis">
        <AdminKpiCard
          label="Admin internals"
          value={adminCount}
          meta="route health / helper facts"
          tone="neutral"
        />
        <AdminKpiCard
          label="Public UI roadmap"
          value={publicCount}
          meta="interactive UX без debug"
          tone="success"
        />
        <AdminKpiCard
          label="Release boundaries"
          value={releaseCount}
          meta="manual CI / evidence separation"
          tone="warning"
        />
      </div>

      <AdminFilterBar
        groups={[
          {
            label: "Контур",
            value: scope,
            options: [
              { key: "admin", label: "Admin" },
              { key: "public", label: "Public" },
              { key: "release", label: "Release" },
            ],
            onChange: (value) => {
              setScope(value as DiagnosticScope);
              setSelected(0);
            },
          },
          {
            label: "Окно",
            value: window,
            options: [
              { key: "now", label: "Сейчас" },
              { key: "next", label: "Дальше" },
              { key: "guard", label: "Guard" },
            ],
            onChange: (value) => setWindow(value as DiagnosticWindow),
          },
        ]}
      />

      <AdminChartCard
        title="Boundary signal"
        subtitle={
          "Кликабельные точки показывают, какие technical facts " +
          "разрешены только внутри Diagnostics."
        }
        meta={<AdminStatusBadge label={WINDOW_LABELS[window]} />}
      >
        {filtered.length ? (
          <svg
            viewBox="0 0 100 80"
            className="efhc-admin-diagnostics-boundary_chart"
            role="img"
            aria-label="Diagnostics boundary signal"
          >
            <path d={chartPath(filtered)} fill="none" />
            {filtered.map((item, index) => {
              const x = filtered.length === 1
                ? 50
                : Math.round((index / (filtered.length - 1)) * 100);
              const y = item.severity === "success"
                ? 22
                : item.severity === "warning"
                  ? 60
                  : 40;
              return (
                <circle
                  key={item.key}
                  cx={x}
                  cy={y}
                  r={4}
                  className="efhc-admin-diagnostics-boundary_point"
                  role="button"
                  tabIndex={0}
                  aria-label={item.label}
                  onClick={() => setSelected(index)}
                  onKeyDown={(event) => {
                    if (event.key === "Enter" || event.key === " ") {
                      setSelected(index);
                    }
                  }}
                />
              );
            })}
          </svg>
        ) : null}
      </AdminChartCard>

      <AdminFlowMapCard
        title="Diagnostics boundary map"
        nodes={filtered.map((item, index) => ({
          label: item.label,
          value: item.value,
          hint: item.hint,
          active: index === selected,
          onClick: () => setSelected(index),
        }))}
      />

      {current ? (
        <AdminActionTable
          title="Selected diagnostic card"
          rows={[
            {
              label: "Scope",
              value: scopeLabel(current.scope),
              hint: "Выбранный технический контур.",
            },
            {
              label: "Boundary",
              value: current.value,
              hint: current.hint,
            },
            {
              label: "Public rule",
              value: "no raw payload",
              hint: "Public UI получает UX-интерактив, а не diagnostics.",
            },
          ]}
        />
      ) : null}
    </section>
  );
}
