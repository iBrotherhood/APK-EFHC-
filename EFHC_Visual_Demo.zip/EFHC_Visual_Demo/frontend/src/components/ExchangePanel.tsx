// Guard marker: Exchange page is kWh -> EFHC only.
import React, { useMemo, useState } from "react";
import { Card } from "./ui/Card";
import { Button } from "./ui/Button";
import { useT } from "../hooks/useT";
import {
  fromScaledBigint,
  toScaledBigintDown,
} from "../lib/format";

type Props = {
  maxKwh: string;
  onExchange: (amountKwh: string) => Promise<void>;
  pending?: boolean;
};

function validDecimal(raw: string): boolean {
  const value = raw.trim();
  if (!value) return false;
  if (value.includes("e") || value.includes("E")) return false;
  if (value.includes("-")) return false;
  return /^\d+(\.\d{0,8})?$/.test(value);
}

function sanitizeAmountInput(raw: string): string {
  const cleaned = raw.replace(/,/g, ".").replace(/\s+/g, "");
  let result = "";
  let hasDot = false;
  let decimals = 0;
  for (const char of cleaned) {
    if (char >= "0" && char <= "9") {
      if (hasDot) {
        if (decimals >= 8) continue;
        decimals += 1;
      }
      result += char;
      continue;
    }
    if (char === "." && !hasDot) {
      hasDot = true;
      result += result ? "." : "0.";
    }
  }
  return result;
}

export function ExchangePanel(props: Props) {
  const t = useT();
  const maxScaled = useMemo(() => {
    return toScaledBigintDown(props.maxKwh || "0", 8);
  }, [props.maxKwh]);
  const [amount, setAmount] = useState("0.00000000");

  const amountIsValid = useMemo(() => {
    return validDecimal(amount);
  }, [amount]);

  const amountScaled = useMemo(() => {
    if (!amountIsValid) return 0n;
    return toScaledBigintDown(amount, 8);
  }, [amount, amountIsValid]);

  const normalizedAmount = useMemo(() => {
    return fromScaledBigint(amountScaled, 8);
  }, [amountScaled]);

  const overMax = useMemo(() => {
    return amountScaled > maxScaled;
  }, [amountScaled, maxScaled]);

  const disabled = useMemo(() => {
    if (props.pending) return true;
    if (!amountIsValid) return true;
    if (amountScaled <= 0n) return true;
    return overMax;
  }, [props.pending, amountIsValid, amountScaled, overMax]);

  const helperText = useMemo(() => {
    if (!amountIsValid) return t("exchange.amount_invalid_detail");
    if (overMax) return t("exchange.amount_over_available");
    return t("exchange.amount_hint");
  }, [amountIsValid, overMax, t]);

  function setMax() {
    setAmount(fromScaledBigint(maxScaled, 8));
  }

  function onAmountChange(value: string) {
    setAmount(sanitizeAmountInput(value));
  }

  return (
    <Card title={t("exchange.title")}>
      <div
        className="efhc-exchange-panel"
        data-exchange-boundary="kwh-to-efhc-only"
        data-exchange-rate="1-kwh-1-efhc"
        data-exchange-amount-polish="1287"
      >
        <div className="text-sm efhc-text-muted">
          {t("exchange.rate_hint")}
        </div>
        <div className="mt-2 efhc-exchange-canonical-row">
          <div>
            <div className="text-xs efhc-text-muted2">
              {t("exchange.available_kwh")}
            </div>
            <div className="mt-1 font-semibold tabular-nums">
              {fromScaledBigint(maxScaled, 8)}
            </div>
          </div>
          <Button
            variant="secondary"
            onClick={setMax}
            data-exchange-max-action="true"
          >
            {t("exchange.max")}
          </Button>
        </div>
        <label className="efhc-exchange-input-group">
          <span className="text-xs efhc-text-muted2">
            {t("exchange.amount_label")}
          </span>
          <input
            className="efhc-input mt-2 w-full"
            value={amount}
            onChange={(e) => onAmountChange(e.target.value)}
            inputMode="decimal"
            placeholder="0.00000000"
            aria-invalid={overMax || !amountIsValid}
            aria-label={t("exchange.amount_label")}
            data-exchange-amount-input="kwh"
          />
        </label>
        <div
          className="efhc-exchange-preview-row"
          data-exchange-preview="one-to-one"
        >
          <span>{t("exchange.receive_label")}</span>
          <strong className="tabular-nums">
            {normalizedAmount} EFHC
          </strong>
        </div>
        <div
          className={
            overMax || !amountIsValid
              ? "efhc-exchange-helper efhc-exchange-helper--warning"
              : "efhc-exchange-helper"
          }
          data-exchange-amount-helper="true"
        >
          {helperText}
        </div>
        <Button
          className="mt-3 w-full"
          onClick={() => props.onExchange(normalizedAmount)}
          disabled={disabled}
        >
          {props.pending
            ? t("exchange.processing")
            : t("exchange.action_exchange")}
        </Button>
      </div>
    </Card>
  );
}
