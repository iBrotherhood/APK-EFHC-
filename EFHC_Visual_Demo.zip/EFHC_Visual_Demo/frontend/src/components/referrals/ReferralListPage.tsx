import React, { useContext, useEffect, useMemo } from "react";
import { useRouter } from "next/router";
import { Card } from "../ui/Card";
import { Button } from "../ui/Button";
import { Badge } from "../ui/Badge";
import { Skeleton } from "../ui/Skeleton";
import { EmptyState } from "../ui/EmptyState";
import { useT } from "../../hooks/useT";
import {
  useReferralList,
  useReferralStats,
} from "../../queries/useReferrals";
import { LayoutContext } from "../Layout";
import {
  hapticSelection,
  hapticSoft,
  telegramBackButtonShow,
} from "../../lib/telegram";

type Props = {
  parent_tg_id: number | null;
  tab: "active" | "inactive";
};

export function ReferralListPage(props: Props) {
  const t = useT();
  const router = useRouter();
  const ctx = useContext(LayoutContext);

  useEffect(() => {
    const off = telegramBackButtonShow(() => {
      hapticSelection(ctx.settings.haptics_enabled);
      void router.push("/referrals");
    });
    return () => off();
  }, [ctx.settings.haptics_enabled, router]);

  const browserMode = !props.parent_tg_id;

  const statsQ = useReferralStats(props.parent_tg_id);
  const listQ = useReferralList(props.parent_tg_id, props.tab);

  const items = useMemo(() => {
    return (listQ.data?.pages || []).flatMap((page) => page.items || []);
  }, [listQ.data]);

  const title =
    props.tab === "active"
      ? t("referrals.active_page")
      : t("referrals.inactive_page");
  const activeCount = statsQ.data?.active_referrals ?? 0;
  const inactiveCount = statsQ.data?.inactive_referrals ?? 0;
  const totalCount = statsQ.data?.total_referrals ?? 0;
  const currentCount = props.tab === "active" ? activeCount : inactiveCount;
  const loading = !browserMode && listQ.isFetching && items.length === 0;

  const refreshAll = () => {
    hapticSelection(ctx.settings.haptics_enabled);
    ctx.toast(t("common.refresh"), "info");
    void statsQ.refetch();
    void listQ.refetch();
  };

  const openTab = (nextTab: "active" | "inactive") => {
    if (nextTab === props.tab) return;
    hapticSelection(ctx.settings.haptics_enabled);
    void router.push(
      nextTab === "active" ? "/referrals/active" : "/referrals/inactive",
    );
  };

  const onLoadMore = async () => {
    hapticSelection(ctx.settings.haptics_enabled);
    await listQ.fetchNextPage();
    hapticSoft(ctx.settings.haptics_enabled);
  };

  const emptyDetail =
    props.tab === "active"
      ? t("referrals.empty_active_detail")
      : t("referrals.empty_inactive_detail");

  return (
    <div className="grid gap-4">
      <section className="efhc-subpage-hero p-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="text-2xl font-bold">{title}</div>
            <div className="mt-1 text-sm efhc-text-muted2">
              {props.tab === "active"
                ? t("referrals.active_page_hint")
                : t("referrals.inactive_page_hint")}
            </div>
          </div>
          <Badge>
            {t("referrals.total_count_short")}: {currentCount}
          </Badge>
        </div>
      </section>

      <Card>
        <div className="grid gap-3 sm:grid-cols-3">
          <button
            className={[
              "efhc-list-row efhc-list-row--button",
              props.tab === "active" ? "efhc-list-row--selected" : "",
            ].join(" ")}
            onClick={() => openTab("active")}
            type="button"
          >
            <div>
              <div className="text-sm font-semibold">
                {t("referrals.active")}
              </div>
              <div className="text-xs efhc-text-muted2">
                {t("referrals.active_page_hint")}
              </div>
            </div>
            <Badge>{activeCount}</Badge>
          </button>

          <button
            className={[
              "efhc-list-row efhc-list-row--button",
              props.tab === "inactive" ? "efhc-list-row--selected" : "",
            ].join(" ")}
            onClick={() => openTab("inactive")}
            type="button"
          >
            <div>
              <div className="text-sm font-semibold">
                {t("referrals.inactive")}
              </div>
              <div className="text-xs efhc-text-muted2">
                {t("referrals.inactive_page_hint")}
              </div>
            </div>
            <Badge>{inactiveCount}</Badge>
          </button>

          <div className="efhc-list-row">
            <div>
              <div className="text-sm font-semibold">
                {t("referrals.total")}
              </div>
              <div className="text-xs efhc-text-muted2">
                {t("referrals.total_hint")}
              </div>
            </div>
            <Badge>{totalCount}</Badge>
          </div>
        </div>
      </Card>

      <Card
        title={title}
        data-referrals-active-inactive-boundary="1296"
      >
        <div className="grid gap-2">
          {items.map((item) => (
            <div
              key={item.username || item.joined_at || item.child_tg_id}
              className="efhc-list-row"
              data-referral-row="username-only"
            >
              <div className="min-w-0">
                <div className="truncate text-sm font-semibold">
                  {item.username
                    ? `@${item.username}`
                    : t("referrals.user_hidden_fallback")}
                </div>
                <div className="text-xs efhc-text-muted2">
                  {item.is_active
                    ? t("referrals.active_row_hint")
                    : t("referrals.inactive_row_hint")}
                  {item.total_generated_kwh
                    ? ` • ${item.total_generated_kwh} kWh`
                    : ""}
                  {typeof item.panels_count === "number"
                    ? ` • ${t("referrals.panels_count_label")}: ` +
                      `${item.panels_count}`
                    : ""}
                </div>
              </div>
              <Badge>
                {item.is_active
                  ? t("referrals.active")
                  : t("referrals.inactive")}
              </Badge>
            </div>
          ))}

          {loading ? (
            <div className="grid gap-2">
              <Skeleton className="h-16" />
              <Skeleton className="h-16" />
            </div>
          ) : null}

          {items.length === 0 && !listQ.isFetching ? (
            <EmptyState
              title={
                props.tab === "active"
                  ? t("referrals.empty_active")
                  : t("referrals.empty_inactive")
              }
              detail={emptyDetail}
              actionLabel={
                browserMode ? t("referrals.open_profile") : t("common.refresh")
              }
              onAction={browserMode ? () => router.push("/") : refreshAll}
            />
          ) : null}

          {listQ.isError ? (
            <EmptyState
              title={t("common.error")}
              detail={t("referrals.load_error")}
              actionLabel={
                browserMode ? t("referrals.open_profile") : t("common.refresh")
              }
              onAction={browserMode ? () => router.push("/") : refreshAll}
            />
          ) : null}

          <div className="flex flex-wrap items-center gap-2 mt-2">
            {!browserMode && listQ.hasNextPage ? (
              <Button
                disabled={listQ.isFetching}
                onClick={() => void onLoadMore()}
              >
                {listQ.isFetching ? t("common.loading") : t("common.load_more")}
              </Button>
            ) : (
              <span className="text-xs efhc-text-muted2">
                {t("common.end")}
              </span>
            )}
            <Button
              variant="secondary"
              disabled={listQ.isFetching}
              onClick={refreshAll}
            >
              {t("common.refresh")}
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
