import React from "react";
import { createPortal } from "react-dom";

import { useT } from "../../hooks/useT";

export function Modal(
  props: React.PropsWithChildren<{
    open: boolean;
    onClose: () => void;
    title: string;
  }>,
) {
  const t = useT();
  if (!props.open || typeof document === "undefined") return null;

  return createPortal(
    <div
      className="fixed inset-0 efhc-modal-overlay"
      aria-modal="true"
      role="dialog"
      aria-label={props.title}
      data-modal-portal="body"
      onClick={props.onClose}
    >
      <div
        className="efhc-modal efhc-modal-sheet w-full"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="efhc-modal-header">
          <div className="efhc-modal-title">{props.title}</div>
          <button
            type="button"
            className="efhc-modal-close"
            aria-label={t("common.close")}
            onClick={props.onClose}
          >
            ×
          </button>
        </div>
        <div className="efhc-modal-body">{props.children}</div>
      </div>
    </div>,
    document.body,
  );
}
