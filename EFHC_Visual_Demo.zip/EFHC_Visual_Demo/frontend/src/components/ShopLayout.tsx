import React, { useMemo } from "react";
import Link from "next/link";
import type { Dict, Lang } from "../lib/i18n";
import { tFromDicts } from "../lib/i18n";
import type { UserSettings } from "../lib/settings";
import { LayoutContext } from "./Layout";
import {
  FrontendShellMain,
  FrontendShellRoot,
} from "./shell/FrontendShell";

function ProfileIcon() {
  return (
    <svg
      width="18"
      height="18"
      viewBox="0 0 24 24"
      fill="none"
      aria-hidden="true"
    >
      <circle
        cx="12"
        cy="8"
        r="3.2"
        stroke="currentColor"
        strokeWidth="1.8"
      />
      <path
        d="M5.5 19c.7-4 2.85-5.9 6.5-5.9s5.8 1.9 6.5 5.9"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function ShopLayout(
  props: React.PropsWithChildren<{
    lang: Lang;
    uiDict: Dict;
    ruDict: Dict;
    descDict: Dict;
    tg_id: number | null;
    telegramName: string;
    telegramAvatarUrl?: string | null;
    snapshot?: {
      profile: {
        username?: string | null;
        main_balance: string;
        bonus_balance: string;
      };
    } | null;
    isVip: boolean;
    isAdmin: boolean;
    settings: UserSettings;
    setLang: (l: Lang) => void;
    setSettings: (s: UserSettings) => void;
  }>,
) {
  const t = useMemo(
    () => (k: string) => tFromDicts(k, props.uiDict, props.ruDict),
    [props.uiDict, props.ruDict],
  );
  const td = useMemo(
    () => (k: string) =>
      props.descDict[k] || tFromDicts(k, props.uiDict, props.ruDict),
    [props.descDict, props.uiDict, props.ruDict],
  );
  const username =
    props.snapshot?.profile?.username || props.telegramName || "EFHC";
  const avatarUrl = props.telegramAvatarUrl || null;
  const mainBalance = props.snapshot?.profile?.main_balance || "0";
  const profileHref = "/web-profile";

  return (
    <LayoutContext.Provider
      value={{
        lang: props.lang,
        t,
        td,
        tg_id: props.tg_id,
        isVip: props.isVip,
        isAdmin: props.isAdmin,
        settings: props.settings,
        setLang: props.setLang,
        setSettings: props.setSettings,
        confirm: async () => true,
        toast: () => undefined,
        openProfile: () => undefined,
        openDeposit: () => undefined,
        openWalletConnect: () => undefined,
        disconnectWalletSession: () => undefined,
        walletConnectionPhase: "disconnected",
        walletHint: null,
        walletSessionConnected: false,
        walletSessionRestoring: false,
        walletProofAccepted: false,
        availableWallets: [],
      }}
    >
      <FrontendShellRoot>
        <header className="efhc-shop-layout_header">
          <div className="efhc-shop-layout_topbar">
            <div className="efhc-shop-layout_identity">
              <div className="efhc-shop-layout_avatar">
                {avatarUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={avatarUrl} alt={t("common.avatar_alt")} />
                ) : (
                  <span>{username.slice(0, 1).toUpperCase()}</span>
                )}
              </div>
              <div className="efhc-shop-layout_name">
                <small>EFHC</small>
                <strong>{username}</strong>
              </div>
            </div>
            <div className="efhc-shop-layout_balance">
              <small>EFHC</small>
              <strong>{mainBalance}</strong>
            </div>
            <Link
              href={profileHref}
              className="efhc-shop-layout_profile"
              aria-label={t("profile.title")}
              title={t("profile.title")}
            >
              <ProfileIcon />
              <span>{t("profile.title")}</span>
            </Link>
          </div>
        </header>
        <FrontendShellMain className="efhc-shop-layout_main">
          {props.children}
        </FrontendShellMain>
      </FrontendShellRoot>
    </LayoutContext.Provider>
  );
}
