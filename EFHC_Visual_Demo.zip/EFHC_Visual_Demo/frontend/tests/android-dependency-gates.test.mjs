import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
test('no legacy back-gesture override; uses AndroidX dispatcher', () => {
 const source=read('../../android/app/src/main/java/org/federationofavatars/efhc/simulator/MainActivity.kt');
 assert.match(source, /OnBackPressedCallback/);
 assert.match(source, /onBackPressedDispatcher\.addCallback/);
 assert.doesNotMatch(source, /override\s+fun\s+onBackPressed\s*\(/);
});
test('Gradle and wrapper checksums are both pinned to 9.8.2', () => {
 const props=read('../../android/gradle/wrapper/gradle-wrapper.properties');
 const download=read('../../android/gradle/wrapper/WrapperDownloader.java');
 assert.match(props, /gradle-9\.8\.2-bin\.zip/);
 assert.match(download, /gradle-9\.8\.2-bin\.zip/);
 assert.match(props, /21bd5da2de49b642904077f38c0efdc7778e92b3ed0889392dca61b97e389607/);
 assert.match(download, /3b8a25775a69158b5ad2b1d17a80a88dc7b40a352a73eb27d06c612a7ce68e98/);
});
test('AGP 9.5 uses built-in Kotlin and stable AndroidX', () => {
 const root=read('../../android/build.gradle.kts');
 const app=read('../../android/app/build.gradle.kts');
 assert.match(root,/com\.android\.application\"\) version \"9\.5\.0/);
 assert.doesNotMatch(root+app, /org\.jetbrains\.kotlin\.android/);
 assert.match(app,/androidx\.activity:activity:1\.13\.0/);
 assert.match(app,/androidx\.webkit:webkit:1\.18\.0/);
 assert.match(app,/targetSdk\s*=\s*36/);
});
