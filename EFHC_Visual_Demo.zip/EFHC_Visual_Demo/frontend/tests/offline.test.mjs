import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {resolve} from 'node:path';
const root=resolve(import.meta.dirname,'../..');
const contract=JSON.parse(readFileSync(resolve(root,'SIMULATOR_CONTRACT.json'),'utf8'));
test('strict offline contract and required demo marker',()=>{
 assert.equal(contract.mode,'offline_simulator');
 assert.equal(contract.backend,'local_demo_engine');
 assert.equal(contract.network_access,false);
 assert.equal(contract.production_api_enabled,false);
 assert.equal(contract.real_financial_operations,false);
 assert.equal(contract.demo_marker_required,true);
 assert.equal(contract.state_storage,'local_only');
});
test('canonical Android package identifiers',()=>{
 const gradle=readFileSync(resolve(root,'android/app/build.gradle.kts'),'utf8');
 assert.match(gradle,/org\.federationofavatars\.efhc\.simulator/);
 assert.match(gradle,/targetSdk\s*=\s*36/);
 assert.match(gradle,/minSdk\s*=\s*26/);
});
test('source contains 0562 loading splash, design themes and offline marker',()=>{
 const html=readFileSync(resolve(root,'frontend/source/FRONTEND_v865.html'),'utf8');
 assert.match(html,/efhcOwner0562Splash/);
 assert.match(html,/data-offline-demo="full-release-additive"/);
 assert.match(html,/data-color-theme-id/);
});
test('Android manifest does not request network or dangerous permissions',()=>{
 const manifest=readFileSync(resolve(root,'android/app/src/main/AndroidManifest.xml'),'utf8');
 for(const permission of ['INTERNET','CAMERA','RECORD_AUDIO','ACCESS_FINE_LOCATION','READ_CONTACTS'])assert.doesNotMatch(manifest,new RegExp('android\\.permission\\.'+permission));
});
