import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {resolve} from 'node:path';
const root=resolve(import.meta.dirname,'../..');
const contract=JSON.parse(readFileSync(resolve(root,'SIMULATOR_CONTRACT.json'),'utf8'));
test('strict offline contract and required demo marker',()=>{
 assert.equal(contract.mode,'offline_simulator');
 assert.equal(contract.backend,'local_demo_engine');
 assert.equal(contract.network_access,false);
 assert.equal(contract.production_api_enabled,false);
 assert.equal(contract.real_financial_operations,false);
 assert.equal(contract.demo_marker_required,true);
 assert.equal(contract.state_storage,'local_only');
});
test('canonical Android package identifiers',()=>{
 const gradle=readFileSync(resolve(root,'android/app/build.gradle.kts'),'utf8');
 assert.match(gradle,/org\.federationofavatars\.efhc\.simulator/);
 assert.match(gradle,/targetSdk\s*=\s*36/);
 assert.match(gradle,/minSdk\s*=\s*26/);
});
test('source contains 0562 loading splash, design themes and offline marker',()=>{
 const html=readFileSync(resolve(root,'frontend/source/FRONTEND_v865.html'),'utf8');
 assert.match(html,/efhcOwner0562Splash/);
 assert.match(html,/data-offline-demo="full-release-additive"/);
 assert.match(html,/data-color-theme-id/);
});
test('Android manifest does not request network or dangerous permissions',()=>{
 const manifest=readFileSync(resolve(root,'android/app/src/main/AndroidManifest.xml'),'utf8');
 for(const permission of ['INTERNET','CAMERA','RECORD_AUDIO','ACCESS_FINE_LOCATION','READ_CONTACTS'])assert.doesNotMatch(manifest,new RegExp('android\\.permission\\.'+permission));
});
test('Gradle wrapper bootstrap uses official checksum-verified Gradle 8.13 distribution',()=>{
 const downloader=readFileSync(resolve(root,'android/gradle/wrapper/WrapperDownloader.java'),'utf8');
 const props=readFileSync(resolve(root,'android/gradle/wrapper/gradle-wrapper.properties'),'utf8');
 assert.doesNotMatch(downloader,/https:\/\/services\.gradle\.org\/distributions\/gradle-8\.13-wrapper\.jar/);
 assert.match(downloader,/gradle-8\.13-bin\.zip/);
 assert.match(downloader,/81a82aaea5abcc8ff68b3dfcb58b3c3c429378efd98e7433460610fecd7ae45f/);
 assert.match(downloader,/20f1b1176237254a6fc204d8434196fa11a4cfb387567519c61556e8710aed78/);
 assert.match(props,/distributionSha256Sum=20f1b1176237254a6fc204d8434196fa11a4cfb387567519c61556e8710aed78/);
});
test('Gradle explicitly generates Android BuildConfig used by MainActivity',()=>{
 const gradle=readFileSync(resolve(root,'android/app/build.gradle.kts'),'utf8');
 const kotlin=readFileSync(resolve(root,'android/app/src/main/java/org/federationofavatars/efhc/simulator/MainActivity.kt'),'utf8');
 assert.match(gradle,/buildConfig\s*=\s*true/);
 assert.match(kotlin,/BuildConfig\.DEBUG/);
});
