import { createHash } from "node:crypto";
import { existsSync, readFileSync, statSync } from "node:fs";
import { resolve, sep } from "node:path";

const root = process.cwd();
const manifestPath = resolve(root, "release-assets-manifest.json");
const requiredLanguages = [
  "ru", "en", "uk", "de", "fr", "es", "it",
  "tr", "pl", "da", "hi", "id", "sw",
];

function fail(message) {
  console.error(`EFHC RELEASE ASSETS VERIFY: FAIL; ${message}`);
  process.exit(1);
}

function checksum(path) {
  return createHash("sha256")
    .update(readFileSync(path))
    .digest("hex");
}

if (!existsSync(manifestPath)) {
  fail("release-assets-manifest.json is missing");
}

let manifest;
try {
  manifest = JSON.parse(readFileSync(manifestPath, "utf8"));
} catch (error) {
  fail(`invalid release asset manifest: ${error}`);
}
if (manifest.schema !== "EFHC_FRONTEND_RELEASE_ASSETS_V1") {
  fail("unsupported release asset manifest schema");
}
if (!manifest.files || typeof manifest.files !== "object") {
  fail("manifest files map is missing");
}

for (const [relativePath, expected] of Object.entries(manifest.files)) {
  const absolutePath = resolve(root, relativePath);
  if (absolutePath !== root && !absolutePath.startsWith(root + sep)) {
    fail(`unsafe asset path: ${relativePath}`);
  }
  if (!existsSync(absolutePath) || !statSync(absolutePath).isFile()) {
    fail(`missing packaged asset: ${relativePath}`);
  }
  const expectedHash = Array.isArray(expected)
    ? expected.join("")
    : expected;
  const actual = checksum(absolutePath);
  if (actual !== expectedHash) {
    fail(`checksum mismatch: ${relativePath}`);
  }
  if (relativePath.endsWith(".json")) {
    try {
      JSON.parse(readFileSync(absolutePath, "utf8"));
    } catch (error) {
      fail(`invalid JSON asset ${relativePath}: ${error}`);
    }
  }
}

for (const language of requiredLanguages) {
  const faq = `public/faq/${language}.json`;
  const locale = `public/locale/${language}.json`;
  if (!Object.hasOwn(manifest.files, faq)) fail(`missing ${faq}`);
  if (!Object.hasOwn(manifest.files, locale)) fail(`missing ${locale}`);
}
for (const path of [
  "src/data/faq/catalogs.ts",
  "public/pwa-build.json",
  ".efhc-build-id",
]) {
  if (!Object.hasOwn(manifest.files, path)) fail(`missing ${path}`);
}

const pwa = JSON.parse(
  readFileSync(resolve(root, "public/pwa-build.json"), "utf8"),
);
if (pwa.schema !== "EFHC_PWA_BUILD_V2") {
  fail("invalid PWA build schema");
}
for (const language of requiredLanguages) {
  const faqPath = resolve(root, "public", "faq", `${language}.json`);
  const localePath = resolve(root, "public", "locale", `${language}.json`);
  if (pwa.faq_checksums?.[language] !== checksum(faqPath)) {
    fail(`PWA FAQ checksum mismatch: ${language}`);
  }
  if (pwa.locale_checksums?.[language] !== checksum(localePath)) {
    fail(`PWA locale checksum mismatch: ${language}`);
  }
}

console.log(
  `EFHC RELEASE ASSETS VERIFY: PASS; files=${Object.keys(manifest.files).length}`,
);
