import { rmSync } from "node:fs";

const transientBuildPaths = [
  new URL("../.next", import.meta.url),
  new URL("../tsconfig.tsbuildinfo", import.meta.url),
];

for (const path of transientBuildPaths) {
  rmSync(path, {
    recursive: true,
    force: true,
  });
}

console.log("EFHC frontend transient build state cleared");
