import { existsSync, readFileSync, readdirSync, statSync } from "node:fs";
import { resolve, relative } from "node:path";

const frontend = process.cwd();
const project = resolve(frontend, "..");
const android = resolve(project, "android");
const contractPath = resolve(project, "SIMULATOR_CONTRACT.json");
const contract = JSON.parse(readFileSync(contractPath, "utf8"));

const expectedContract = {
  mode: "offline_simulator",
  backend: "local_demo_engine",
  network_access: false,
  production_api_enabled: false,
  real_financial_operations: false,
  demo_marker_required: true,
  data_generation: "deterministic_seeded",
  state_storage: "local_only",
  application_id: "org.federationofavatars.efhc.simulator",
  demo_table_count: 17,
};
for (const [key, value] of Object.entries(expectedContract)) {
  if (contract[key] !== value) throw new Error(`CONTRACT_${key}_INVALID`);
}
if (!/^0\.1\.4$/.test(String(contract.simulator_version))) {
  throw new Error("CONTRACT_SIMULATOR_VERSION_INVALID");
}

const required = [
  "src/demo/runtime.ts",
  "src/demo/seed.ts",
  "src/demo/database.ts",
  "src/demo/api.ts",
  "src/demo/DemoControlCenter.tsx",
  "src/demo/demo.css",
  "scripts/build-demo.mjs",
  "../android/app/src/main/AndroidManifest.xml",
  "../android/app/src/main/java/org/federationofavatars/efhc/simulator/MainActivity.kt",
  "../android/app/src/main/assets/web/simulator-contract.json",
];
for (const file of required) {
  const target = resolve(frontend, file);
  if (!existsSync(target) || statSync(target).size === 0) {
    throw new Error(`MISSING_OR_EMPTY:${file}`);
  }
}
const embeddedSourceContract = readFileSync(
  resolve(android, "app/src/main/assets/web/simulator-contract.json"),
  "utf8",
);
if (embeddedSourceContract !== readFileSync(contractPath, "utf8")) {
  throw new Error("ANDROID_SOURCE_CONTRACT_DRIFT");
}
if (existsSync(resolve(frontend, "src/pages/api"))) {
  throw new Error("NEXT_SERVER_API_ROUTES_MUST_NOT_SHIP_IN_OFFLINE_SIMULATOR");
}

function collectPageRoutes(directory, prefix = "") {
  const routes = [];
  for (const name of readdirSync(directory).sort()) {
    const file = resolve(directory, name);
    const rel = `${prefix}/${name}`;
    if (statSync(file).isDirectory()) routes.push(...collectPageRoutes(file, rel));
    if (!name.endsWith(".tsx")) continue;
    const page = rel.replace(/\.tsx$/, "");
    if (page.split("/").pop().startsWith("_")) continue;
    if (["/404", "/500"].includes(page)) continue;
    routes.push(page.replace(/\/index$/, "") || "/");
  }
  return routes;
}

const expectedPages = [
  "/", "/ads", "/app", "/browser-shop", "/exchange", "/faq", "/hub",
  "/panels", "/ranks", "/referrals", "/referrals/active",
  "/referrals/inactive", "/tasks", "/web-profile", "/withdraw",
  "/admin", "/admin/ads", "/admin/bank", "/admin/diagnostics",
  "/admin/efhc-deposits", "/admin/hub", "/admin/logs", "/admin/panels",
  "/admin/referrals", "/admin/reports", "/admin/sale-packages",
  "/admin/shop", "/admin/system", "/admin/tasks", "/admin/templates",
  "/admin/users", "/admin/withdrawals",
].sort();
const actualPages = collectPageRoutes(resolve(frontend, "src/pages")).sort();
if (JSON.stringify(actualPages) !== JSON.stringify(expectedPages)) {
  throw new Error(`PAGE_ROUTE_MATRIX_MISMATCH:${JSON.stringify(actualPages)}`);
}

const api = readFileSync(resolve(frontend, "src/demo/api.ts"), "utf8");
const routeMarkers = [
  "/auth/session", "/auth/logout", "/auth/telegram/session", "/auth/ton/proof", "/sync/me", "/user/me/panels-summary", "/panels/active",
  "/panels/archive", "/panels/activate", "/exchange/preview",
  "/exchange/convert", "/tasks/catalog", "/tasks/my", "/tasks/claim",
  "/ads/slot", "/ads/callback/builtin_timer", "/referrals/stats/me",
  "/referrals/active/me", "/referrals/inactive/me", "/ranks/my-plus-top/me",
  "/ranks/top/me",
  "/wallets/me", "/wallets/balance-history", "make-primary",
  "/withdraw/list", "/withdraw/list/me",
  "/withdraw/request", "withdraw-outcomes",
  "/skins/catalog", "/skins/my", "/skins/switcher", "(buy|activate|switcher",
  "/shopfront/access-key", "/hub/shop-truth", "/shopfront/bootstrap",
  "/shopfront/catalog", "/shopfront/create-intent", "/shopfront/intent-status",
  "/shopfront/profile", "/hub/efhc-handoff", "/deposit/direct-open",
  "/wallets/tonconnect/proof-payload", "/wallets/tonconnect/check-proof",
  "/wallets/connect", "/health", "/health/db", "/health/runtime",
  "/admin/users/search", "/admin/transfer", "/admin/bank/balance",
  "/admin/bank/mint", "/admin/bank/burn", "/admin/panels",
  "/admin/withdrawals", "/admin/withdrawals/repair-consistency",
  "/admin/referrals/summary", "/admin/ads/providers", "/admin/tasks",
  "/admin/tasks/refresh-statuses", "submissions", "/admin/shop/items",
  "/admin/shop/items/upsert", "/admin/shop/items/status",
  "/admin/shop/items/delete", "/admin/shop/items/set-price",
  "/admin/shop/orders", "legacy",
  "force-fulfill", "/admin/hub/links", "/admin/hub/links/reorder",
  "/admin/templates", "/admin/efhc-deposits/runtime-summary",
  "/admin/efhc-deposits/process", "reprocess", "/admin/logs/transfers",
  "/admin/observability/events", "/admin/observability/health",
  "/admin/observability/summary", "/admin/observability/timeseries",
  "/admin/reports/", "/admin/ton/reconcile", "/admin/sale-packages",
];
for (const path of routeMarkers) {
  if (!api.includes(path)) throw new Error(`DEMO_ROUTE_MISSING:${path}`);
}
for (const marker of [
  '["PUT", "PATCH"].includes(method)',
  '["PUT", "PATCH", "DELETE"].includes(method)',
  'DEMO_API_ROUTE_NOT_IMPLEMENTED',
  'DEMO_DATABASE_SCHEMA',
  'DEMO_WITHDRAW_INSUFFICIENT_BALANCE',
  'DEMO_EXCHANGE_INSUFFICIENT_KWH',
  'DEMO_AD_REPLAY',
  'current_level_min',
  'bonus_asset: "EFHCb"',
  'active_skin_id: 1',
  'wallet_sync_required: true',
]) {
  if (!api.includes(marker)) throw new Error(`DEMO_API_GUARD_MISSING:${marker}`);
}

const db = readFileSync(resolve(frontend, "src/demo/database.ts"), "utf8");
const tables = [
  "settings", "users", "panels", "transactions", "tasks", "user_tasks",
  "referrals", "wallets", "withdrawals", "shop_items", "shop_orders",
  "hub_links", "admin_events", "skins", "templates", "sale_packages",
  "ad_events",
];
for (const table of tables) {
  if (!db.includes(`"${table}"`)) throw new Error(`DEMO_TABLE_MISSING:${table}`);
}
for (const marker of [
  "const DB_VERSION = 2",
  "migrateDatabaseData",
  "assertDemoSeedIntegrity(seed)",
  "by_global_id",
  "by_task_and_user",
  "by_wallet_address",
  "by_token",
]) {
  if (!db.includes(marker)) throw new Error(`DEMO_DATABASE_GUARD_MISSING:${marker}`);
}
for (const forbiddenKeyPath of [
  'keyPath: "is_active"',
  'keyPath: "is_primary"',
]) {
  if (db.includes(forbiddenKeyPath)) {
    throw new Error(`DEMO_INDEXEDDB_BOOLEAN_INDEX_FORBIDDEN:${forbiddenKeyPath}`);
  }
}
for (const marker of [
  'const countTx = db.transaction("sale_packages", "readonly")',
  'const writeTx = db.transaction(',
  'database_version: DB_VERSION',
  'schema: DEMO_DATABASE_SCHEMA',
  '...(stored || {})',
]) {
  if (!db.includes(marker)) throw new Error(`DEMO_MIGRATION_GUARD_MISSING:${marker}`);
}

const seed = readFileSync(resolve(frontend, "src/demo/seed.ts"), "utf8");
for (const marker of [
  "assertDemoSeedIntegrity(seed)",
  "DEMO_SEED_OWNER_MISSING",
  "DEMO_SEED_INVALID_GLOBAL_ID",
  "DEMO_SEED_MULTIPLE_PRIMARY_WALLETS",
  "task_and_user",
  "price_asset_d8",
  "efhc_amount_d8",
]) {
  if (!seed.includes(marker)) throw new Error(`DEMO_SEED_GUARD_MISSING:${marker}`);
}

const manifest = readFileSync(resolve(android, "app/src/main/AndroidManifest.xml"), "utf8");
for (const forbidden of [
  "android.permission.INTERNET",
  "android.permission.CAMERA",
  "android.permission.RECORD_AUDIO",
  "android.permission.ACCESS_FINE_LOCATION",
  "android.permission.READ_CONTACTS",
]) {
  if (manifest.includes(forbidden)) throw new Error(`FORBIDDEN_ANDROID_PERMISSION:${forbidden}`);
}

const gradle = readFileSync(resolve(android, "app/build.gradle.kts"), "utf8");
for (const marker of [
  'applicationId = "org.federationofavatars.efhc.simulator"',
  'versionName = "0.1.4"',
  'versionCode = 5',
  'buildConfigField("String", "RUNTIME_MODE", "\\"offline_simulator\\"")',
  "prepareSimulatorAssets",
  "generatedSimulatorAssets",
  'mustRunAfter("clean")',
  "assets.setSrcDirs",
  "verifyDebugApkContainsSimulatorContract",
  "dependsOn(verifyDebugApkContainsSimulatorContract)",
  "dependsOn(\"packageDebug\")",
  'noCompress += listOf("json", "zip")',
  '"assets/web/index.html"',
  '"assets/web/simulator-contract.json"',
  '"assets/web/web-bundle.zip"',
  "Unexpected compact web asset inventory",
  "Canonical CI contract probe failed",
  "set -o pipefail; unzip -l",
  "Source simulator contract differs from the canonical contract",
  "Embedded simulator contract differs from the canonical contract",
  "Bundled simulator contract differs from the canonical contract",
]) {
  if (!gradle.includes(marker)) throw new Error(`ANDROID_BUILD_GUARD_MISSING:${marker}`);
}

const buildScript = readFileSync(resolve(frontend, "scripts/build-demo.mjs"), "utf8");
for (const marker of [
  "validateContract(androidContract)",
  "ANDROID_WEB_ENTRYPOINT_MISSING",
  "ANDROID_WEB_BUNDLE_MISSING",
  "DEMO_EXPORTED_CONTRACT_DRIFT",
  'run("zip", ["-q", "-r", "-X", androidBundle, "."]',
  'run("unzip", ["-tqq", androidBundle]',
  "SIMULATOR_CONTRACT_INVALID",
]) {
  if (!buildScript.includes(marker)) throw new Error(`DEMO_BUILD_GUARD_MISSING:${marker}`);
}

if (existsSync(resolve(project, ".github"))) {
  throw new Error("SIMULATOR_ARCHIVE_MUST_NOT_EMBED_GITHUB_WORKFLOWS");
}

const activity = readFileSync(
  resolve(android, "app/src/main/java/org/federationofavatars/efhc/simulator/MainActivity.kt"),
  "utf8",
);
for (const marker of [
  "WebViewAssetLoader",
  "Offline simulator blocks external network access",
  "connect-src 'self'",
  "OnBackPressedCallback",
  "SimulatorWebBundle.install(this)",
  'BUNDLE_ASSET = "web/web-bundle.zip"',
  "ZipInputStream",
  "MAX_EXPANDED_BYTES",
  "Unsafe simulator web bundle path",
  "contractBytes(context).contentEquals",
  "SimulatorFilesPathHandler",
]) {
  if (!activity.includes(marker)) throw new Error(`ANDROID_OFFLINE_GUARD_MISSING:${marker}`);
}

console.log(
  `[PASS] ${actualPages.length} pages, ${tables.length} IndexedDB tables, ` +
  `${routeMarkers.length} API route markers, migrations, contracts and Android offline guards`,
);
