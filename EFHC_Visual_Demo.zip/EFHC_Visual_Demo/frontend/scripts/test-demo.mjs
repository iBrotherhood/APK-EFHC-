import {
  copyFileSync,
  existsSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  readdirSync,
  rmSync,
  statSync,
  writeFileSync,
} from "node:fs";
import { resolve, relative } from "node:path";
import { tmpdir } from "node:os";
import { spawnSync } from "node:child_process";
import { createRequire } from "node:module";

const frontend = process.cwd();
const project = resolve(frontend, "..");
const android = resolve(project, "android");
const contractPath = resolve(project, "SIMULATOR_CONTRACT.json");
const contract = JSON.parse(readFileSync(contractPath, "utf8"));

const expectedContract = {
  mode: "offline_simulator",
  backend: "local_demo_engine",
  network_access: false,
  production_api_enabled: false,
  real_financial_operations: false,
  demo_marker_required: true,
  data_generation: "deterministic_seeded",
  state_storage: "local_only",
  application_id: "org.federationofavatars.efhc.simulator",
  demo_table_count: 17,
  state_database: "indexeddb_table_store_v3",
  source_efhc_version: "v172.50",
  economic_canon: "EFHC_BACKEND_CANON_V172_50_D8",
  economic_constants_embedded: true,
  rounding: "ROUND_DOWN",
  decimal_places: 8,
};
for (const [key, value] of Object.entries(expectedContract)) {
  if (contract[key] !== value) throw new Error(`CONTRACT_${key}_INVALID`);
}
if (!/^0\.2\.0$/.test(String(contract.simulator_version))) {
  throw new Error("CONTRACT_SIMULATOR_VERSION_INVALID");
}

const required = [
  "src/demo/runtime.ts",
  "src/demo/seed.ts",
  "src/demo/database.ts",
  "src/demo/api.ts",
  "src/demo/economics.ts",
  "src/demo/DemoControlCenter.tsx",
  "public/demo/efhc-backend-canon-v172-50.json",
  "../BACKEND_ECONOMIC_CANON_V172_50_MANIFEST.json",
  "../INTERFACE_SOURCE_V172_50_MANIFEST.json",
  "src/demo/demo.css",
  "scripts/build-demo.mjs",
  "../android/app/src/main/AndroidManifest.xml",
  "../android/app/src/main/java/org/federationofavatars/efhc/simulator/MainActivity.kt",
  "../android/app/src/main/assets/web/simulator-contract.json",
];
for (const file of required) {
  const target = resolve(frontend, file);
  if (!existsSync(target) || statSync(target).size === 0) {
    throw new Error(`MISSING_OR_EMPTY:${file}`);
  }
}
const embeddedSourceContract = readFileSync(
  resolve(android, "app/src/main/assets/web/simulator-contract.json"),
  "utf8",
);
if (embeddedSourceContract !== readFileSync(contractPath, "utf8")) {
  throw new Error("ANDROID_SOURCE_CONTRACT_DRIFT");
}
if (existsSync(resolve(frontend, "src/pages/api"))) {
  throw new Error("NEXT_SERVER_API_ROUTES_MUST_NOT_SHIP_IN_OFFLINE_SIMULATOR");
}

function collectPageRoutes(directory, prefix = "") {
  const routes = [];
  for (const name of readdirSync(directory).sort()) {
    const file = resolve(directory, name);
    const rel = `${prefix}/${name}`;
    if (statSync(file).isDirectory()) routes.push(...collectPageRoutes(file, rel));
    if (!name.endsWith(".tsx")) continue;
    const page = rel.replace(/\.tsx$/, "");
    if (page.split("/").pop().startsWith("_")) continue;
    if (["/404", "/500"].includes(page)) continue;
    routes.push(page.replace(/\/index$/, "") || "/");
  }
  return routes;
}

const expectedPages = [
  "/", "/ads", "/app", "/browser-shop", "/exchange", "/faq", "/hub",
  "/panels", "/ranks", "/referrals", "/referrals/active",
  "/referrals/inactive", "/tasks", "/web-profile", "/withdraw",
  "/admin", "/admin/ads", "/admin/bank", "/admin/diagnostics",
  "/admin/efhc-deposits", "/admin/hub", "/admin/logs", "/admin/panels",
  "/admin/referrals", "/admin/reports", "/admin/sale-packages",
  "/admin/shop", "/admin/system", "/admin/tasks", "/admin/templates",
  "/admin/users", "/admin/withdrawals",
].sort();
const actualPages = collectPageRoutes(resolve(frontend, "src/pages")).sort();
if (JSON.stringify(actualPages) !== JSON.stringify(expectedPages)) {
  throw new Error(`PAGE_ROUTE_MATRIX_MISMATCH:${JSON.stringify(actualPages)}`);
}

const api = readFileSync(resolve(frontend, "src/demo/api.ts"), "utf8");
const routeMarkers = [
  "/auth/session", "/auth/logout", "/auth/telegram/session", "/auth/ton/proof", "/sync/me", "/user/me/panels-summary", "/panels/active",
  "/panels/archive", "/panels/activate", "/exchange/preview",
  "/exchange/convert", "/tasks/catalog", "/tasks/my", "/tasks/claim",
  "/ads/slot", "/ads/callback/builtin_timer", "/referrals/stats/me",
  "/referrals/active/me", "/referrals/inactive/me", "/ranks/my-plus-top/me",
  "/ranks/top/me",
  "/wallets/me", "/wallets/balance-history", "make-primary",
  "/withdraw/list", "/withdraw/list/me",
  "/withdraw/request", "withdraw-outcomes",
  "/skins/catalog", "/skins/my", "/skins/switcher", "(buy|activate|switcher",
  "/shopfront/access-key", "/hub/shop-truth", "/shopfront/bootstrap",
  "/shopfront/catalog", "/shopfront/create-intent", "/shopfront/intent-status",
  "/shopfront/profile", "/hub/efhc-handoff", "/deposit/direct-open",
  "/wallets/tonconnect/proof-payload", "/wallets/tonconnect/check-proof",
  "/wallets/connect", "/health", "/health/db", "/health/runtime",
  "/admin/users/search", "/admin/transfer", "/admin/bank/balance",
  "/admin/bank/mint", "/admin/bank/burn", "/admin/panels",
  "/admin/withdrawals", "/admin/withdrawals/repair-consistency",
  "/admin/referrals/summary", "/admin/ads/providers", "/admin/tasks",
  "/admin/tasks/refresh-statuses", "submissions", "/admin/shop/items",
  "/admin/shop/items/upsert", "/admin/shop/items/status",
  "/admin/shop/items/delete", "/admin/shop/items/set-price",
  "/admin/shop/orders", "legacy",
  "force-fulfill", "/admin/hub/links", "/admin/hub/links/reorder",
  "/admin/templates", "/admin/efhc-deposits/runtime-summary",
  "/admin/efhc-deposits/process", "reprocess", "/admin/logs/transfers",
  "/admin/observability/events", "/admin/observability/health",
  "/admin/observability/summary", "/admin/observability/timeseries",
  "/admin/reports/", "/admin/ton/reconcile", "/admin/sale-packages",
];
for (const path of routeMarkers) {
  if (!api.includes(path)) throw new Error(`DEMO_ROUTE_MISSING:${path}`);
}
for (const marker of [
  '["PUT", "PATCH"].includes(method)',
  '["PUT", "PATCH", "DELETE"].includes(method)',
  'DEMO_API_ROUTE_NOT_IMPLEMENTED',
  'DEMO_DATABASE_SCHEMA',
  'DEMO_WITHDRAW_INSUFFICIENT_BALANCE',
  'DEMO_EXCHANGE_INSUFFICIENT_KWH',
  'DEMO_AD_REPLAY',
  'current_level_min',
  'bonus_asset: EFHC_BACKEND_CANON.referralBonusAsset',
  'active_skin_id: 1',
  'wallet_sync_required: true',
]) {
  if (!api.includes(marker)) throw new Error(`DEMO_API_GUARD_MISSING:${marker}`);
}

const db = readFileSync(resolve(frontend, "src/demo/database.ts"), "utf8");
const tables = [
  "settings", "users", "panels", "transactions", "tasks", "user_tasks",
  "referrals", "wallets", "withdrawals", "shop_items", "shop_orders",
  "hub_links", "admin_events", "skins", "templates", "sale_packages",
  "ad_events",
];
for (const table of tables) {
  if (!db.includes(`"${table}"`)) throw new Error(`DEMO_TABLE_MISSING:${table}`);
}
for (const marker of [
  "const DB_VERSION = 3",
  "migrateDatabaseData",
  "assertDemoSeedIntegrity(seed)",
  "by_global_id",
  "by_task_and_user",
  "by_wallet_address",
  "by_token",
]) {
  if (!db.includes(marker)) throw new Error(`DEMO_DATABASE_GUARD_MISSING:${marker}`);
}
for (const forbiddenKeyPath of [
  'keyPath: "is_active"',
  'keyPath: "is_primary"',
]) {
  if (db.includes(forbiddenKeyPath)) {
    throw new Error(`DEMO_INDEXEDDB_BOOLEAN_INDEX_FORBIDDEN:${forbiddenKeyPath}`);
  }
}
for (const marker of [
  'const readTx = db.transaction(["sale_packages", "users", "panels"], "readonly")',
  'const writeTx = db.transaction(',
  'database_version: DB_VERSION',
  'schema: DEMO_DATABASE_SCHEMA',
  '...(stored || {})',
]) {
  if (!db.includes(marker)) throw new Error(`DEMO_MIGRATION_GUARD_MISSING:${marker}`);
}

const seed = readFileSync(resolve(frontend, "src/demo/seed.ts"), "utf8");
for (const marker of [
  "assertDemoSeedIntegrity(seed)",
  "DEMO_SEED_OWNER_MISSING",
  "DEMO_SEED_INVALID_GLOBAL_ID",
  "DEMO_SEED_MULTIPLE_PRIMARY_WALLETS",
  "task_and_user",
  "price_asset_d8",
  "efhc_amount_d8",
]) {
  if (!seed.includes(marker)) throw new Error(`DEMO_SEED_GUARD_MISSING:${marker}`);
}

const economics = readFileSync(resolve(frontend, "src/demo/economics.ts"), "utf8");
const economicCanon = JSON.parse(readFileSync(resolve(frontend, "public/demo/efhc-backend-canon-v172-50.json"), "utf8"));
const economicManifest = JSON.parse(readFileSync(resolve(project, "BACKEND_ECONOMIC_CANON_V172_50_MANIFEST.json"), "utf8"));
if (JSON.stringify(economicCanon) !== JSON.stringify(economicManifest)) {
  throw new Error("ECONOMIC_CANON_ASSET_MANIFEST_DRIFT");
}
const exactEconomicCanon = {
  schema: "EFHC_BACKEND_ECONOMIC_CANON_V172_50_D8",
  source_release: "EFHC_Bot_v172_50",
  source_archive_sha256: "a4edb6ebbcb99a439e79e839e1ee5160796b0845d2c6925bf77d731e897eb3ca",
  decimals: 8,
  rounding: "ROUND_DOWN",
  generation_per_second_base_kwh: "0.00000692",
  generation_per_second_vip_kwh: "0.00000741",
  exchange_rate_kwh_to_efhc: "1.00000000",
  scheduler_tick_seconds: 600,
  panel_price_efhc: "100.00000000",
  panel_lifetime_days: 180,
  max_active_panels: 1000,
  minimum_withdraw_efhc: "10.00000000",
  referral_direct_bonus_efhcb: "0.10000000",
  referral_direct_bonus_max_active: 10000,
};
for (const [key, value] of Object.entries(exactEconomicCanon)) {
  if (economicManifest[key] !== value) throw new Error(`ECONOMIC_CANON_${key}_INVALID`);
}
if (Object.keys(economicManifest.source_file_sha256 || {}).length !== 8) {
  throw new Error("ECONOMIC_CANON_SOURCE_HASH_COUNT_INVALID");
}
if (contract.economic_constants_asset !== "demo/efhc-backend-canon-v172-50.json") {
  throw new Error("CONTRACT_ECONOMIC_ASSET_INVALID");
}
const economicMarkers = {
  sourceRelease: economicCanon.source_release,
  generationPerSecondBaseKwh: economicCanon.generation_per_second_base_kwh,
  generationPerSecondVipKwh: economicCanon.generation_per_second_vip_kwh,
  exchangeRateKwhToEfhc: economicCanon.exchange_rate_kwh_to_efhc,
  panelPriceEfhc: economicCanon.panel_price_efhc,
  panelLifetimeDays: economicCanon.panel_lifetime_days,
  maxActivePanels: economicCanon.max_active_panels,
  minimumWithdrawEfhc: economicCanon.minimum_withdraw_efhc,
  referralDirectBonusEfhcb: economicCanon.referral_direct_bonus_efhcb,
  referralDirectBonusMaxActive: economicCanon.referral_direct_bonus_max_active,
};
for (const [key, value] of Object.entries(economicMarkers)) {
  const marker = typeof value === "string"
    ? `${key}: "${value}"`
    : key === "referralDirectBonusMaxActive"
      ? `${key}: 10_000`
      : `${key}: ${value}`;
  if (!economics.includes(marker)) throw new Error(`DEMO_ECONOMIC_CANON_DRIFT:${key}`);
}
for (const marker of [
  "ROUND_DOWN", "splitBonusThenMainD8", "calculateGenerationD8",
  "reverseExchangeAllowed: false", "p2pTransfersAllowed: false",
  "userNegativeBalanceAllowed: false", "bankNegativeBalanceAllowed: true",
]) {
  if (!economics.includes(marker)) throw new Error(`DEMO_ECONOMIC_GUARD_MISSING:${marker}`);
}
for (const forbidden of ["0.00050000", "2.50000000", "panelLifetimeDays: 90"]) {
  if (api.includes(forbidden) || economics.includes(forbidden)) throw new Error(`DEMO_LEGACY_ECONOMICS_FORBIDDEN:${forbidden}`);
}
for (const marker of [
  "settleOwnerEnergy", "exchanged_kwh_total", "DEMO_WITHDRAW_BELOW_MINIMUM",
  "splitBonusThenMainD8", "panel_activation_bank",
]) {
  if (!api.includes(marker)) throw new Error(`DEMO_ECONOMIC_API_GUARD_MISSING:${marker}`);
}

const runtimeTestRoot = mkdtempSync(resolve(tmpdir(), "efhc-demo-runtime-test-"));
try {
  const runtimeTestSource = resolve(runtimeTestRoot, "src");
  const runtimeTestOutput = resolve(runtimeTestRoot, "out");
  mkdirSync(runtimeTestSource, { recursive: true });
  for (const file of ["economics.ts", "runtime.ts", "seed.ts"]) {
    copyFileSync(resolve(frontend, "src/demo", file), resolve(runtimeTestSource, file));
  }
  writeFileSync(
    resolve(runtimeTestSource, "process-stub.d.ts"),
    "declare const process: { env: Record<string, string | undefined> };\n",
  );
  const localTsc = resolve(frontend, "node_modules/typescript/bin/tsc");
  const command = existsSync(localTsc) ? process.execPath : "tsc";
  const prefixArgs = existsSync(localTsc) ? [localTsc] : [];
  const compile = spawnSync(command, [
    ...prefixArgs,
    "--target", "ES2020",
    "--module", "CommonJS",
    "--strict",
    "--skipLibCheck",
    "--rootDir", runtimeTestSource,
    "--outDir", runtimeTestOutput,
    resolve(runtimeTestSource, "process-stub.d.ts"),
    resolve(runtimeTestSource, "economics.ts"),
    resolve(runtimeTestSource, "runtime.ts"),
    resolve(runtimeTestSource, "seed.ts"),
  ], { encoding: "utf8" });
  if (compile.error || compile.status !== 0) {
    throw new Error(
      `DEMO_RUNTIME_COMPILE_FAILED:${compile.error?.message || compile.stderr || compile.stdout}`,
    );
  }
  const require = createRequire(import.meta.url);
  const runtimeEconomics = require(resolve(runtimeTestOutput, "economics.js"));
  const runtimeSeed = require(resolve(runtimeTestOutput, "seed.js"));
  const runtimeAssertions = [
    [runtimeEconomics.d8("1.123456789"), "1.12345678", "ROUND_DOWN_POSITIVE"],
    [runtimeEconomics.d8("-1.123456789"), "-1.12345678", "ROUND_DOWN_NEGATIVE"],
    [runtimeEconomics.calculateGenerationD8(600, false), "0.00415200", "BASE_GENERATION_600S"],
    [runtimeEconomics.calculateGenerationD8(600, true), "0.00444600", "VIP_GENERATION_600S"],
    [runtimeEconomics.exchangeKwhToEfhcD8("12.345678999"), "12.34567899", "EXCHANGE_D8"],
    [runtimeEconomics.referralLevelForActive(10_000), 5, "REFERRAL_LEVEL_5"],
    [runtimeEconomics.referralLevelSteps()[4].cumulative_total_reward, "2411.00000000", "REFERRAL_TOTAL"],
  ];
  for (const [actual, expected, label] of runtimeAssertions) {
    if (actual !== expected) throw new Error(`DEMO_RUNTIME_MATH_${label}:${actual}:${expected}`);
  }
  const debit = runtimeEconomics.splitBonusThenMainD8({
    bonusBalance: "30.00000000",
    mainBalance: "100.00000000",
    amount: "100.00000000",
  });
  if (JSON.stringify(debit) !== JSON.stringify({
    bonusPart: "30.00000000",
    mainPart: "70.00000000",
    bonusAfter: "0.00000000",
    mainAfter: "30.00000000",
  })) throw new Error("DEMO_RUNTIME_BONUS_FIRST_DEBIT_INVALID");
  const expectedScenarioRows = {
    active: 171,
    vip: 178,
    new_user: 87,
    risk: 171,
    dense: 863,
  };
  for (const [scenario, expectedRows] of Object.entries(expectedScenarioRows)) {
    const generated = runtimeSeed.buildDemoSeed(scenario);
    if (Object.keys(generated).length !== 17) throw new Error(`DEMO_RUNTIME_TABLE_COUNT:${scenario}`);
    const rowCount = Object.values(generated).reduce((sum, rows) => sum + rows.length, 0);
    if (rowCount !== expectedRows) throw new Error(`DEMO_RUNTIME_ROW_COUNT:${scenario}:${rowCount}`);
  }
} finally {
  rmSync(runtimeTestRoot, { recursive: true, force: true });
}

const interfaceManifest = JSON.parse(readFileSync(resolve(project, "INTERFACE_SOURCE_V172_50_MANIFEST.json"), "utf8"));
if (interfaceManifest.source_version !== "v172.50" || interfaceManifest.source_archive_sha256 !== contract.source_archive_sha256) {
  throw new Error("INTERFACE_SOURCE_MANIFEST_INVALID");
}
for (const [relativePath, expectedHash] of Object.entries(interfaceManifest.files)) {
  const bytes = readFileSync(resolve(frontend, relativePath));
  const actualHash = (await import("node:crypto")).createHash("sha256").update(bytes).digest("hex");
  if (actualHash !== expectedHash) throw new Error(`INTERFACE_SOURCE_DRIFT:${relativePath}`);
}

const manifest = readFileSync(resolve(android, "app/src/main/AndroidManifest.xml"), "utf8");
for (const forbidden of [
  "android.permission.INTERNET",
  "android.permission.CAMERA",
  "android.permission.RECORD_AUDIO",
  "android.permission.ACCESS_FINE_LOCATION",
  "android.permission.READ_CONTACTS",
]) {
  if (manifest.includes(forbidden)) throw new Error(`FORBIDDEN_ANDROID_PERMISSION:${forbidden}`);
}

const gradle = readFileSync(resolve(android, "app/build.gradle.kts"), "utf8");
for (const marker of [
  'applicationId = "org.federationofavatars.efhc.simulator"',
  'versionName = "0.2.0"',
  'versionCode = 6',
  'buildConfigField("String", "RUNTIME_MODE", "\\"offline_simulator\\"")',
  "prepareSimulatorAssets",
  "generatedSimulatorAssets",
  'mustRunAfter("clean")',
  "assets.setSrcDirs",
  "verifyDebugApkContainsSimulatorContract",
  "dependsOn(verifyDebugApkContainsSimulatorContract)",
  "dependsOn(\"packageDebug\")",
  'noCompress += listOf("json", "zip")',
  '"assets/web/index.html"',
  '"assets/web/simulator-contract.json"',
  '"assets/web/web-bundle.zip"',
  "Unexpected compact web asset inventory",
  "Canonical CI contract probe failed",
  "set -o pipefail; unzip -l",
  "Source simulator contract differs from the canonical contract",
  "Embedded simulator contract differs from the canonical contract",
  "Bundled simulator contract differs from the canonical contract",
]) {
  if (!gradle.includes(marker)) throw new Error(`ANDROID_BUILD_GUARD_MISSING:${marker}`);
}

const buildScript = readFileSync(resolve(frontend, "scripts/build-demo.mjs"), "utf8");
for (const marker of [
  "validateContract(androidContract)",
  "ANDROID_WEB_ENTRYPOINT_MISSING",
  "ANDROID_WEB_BUNDLE_MISSING",
  "DEMO_EXPORTED_CONTRACT_DRIFT",
  'run("zip", ["-q", "-r", "-X", androidBundle, "."]',
  'run("unzip", ["-tqq", androidBundle]',
  "SIMULATOR_CONTRACT_INVALID",
]) {
  if (!buildScript.includes(marker)) throw new Error(`DEMO_BUILD_GUARD_MISSING:${marker}`);
}

if (existsSync(resolve(project, ".github"))) {
  throw new Error("SIMULATOR_ARCHIVE_MUST_NOT_EMBED_GITHUB_WORKFLOWS");
}

const activity = readFileSync(
  resolve(android, "app/src/main/java/org/federationofavatars/efhc/simulator/MainActivity.kt"),
  "utf8",
);
for (const marker of [
  "WebViewAssetLoader",
  "Offline simulator blocks external network access",
  "connect-src 'self'",
  "OnBackPressedCallback",
  "SimulatorWebBundle.install(this)",
  'BUNDLE_ASSET = "web/web-bundle.zip"',
  "ZipInputStream",
  "MAX_EXPANDED_BYTES",
  "Unsafe simulator web bundle path",
  "contractBytes(context).contentEquals",
  "SimulatorFilesPathHandler",
]) {
  if (!activity.includes(marker)) throw new Error(`ANDROID_OFFLINE_GUARD_MISSING:${marker}`);
}

console.log(
  `[PASS] ${actualPages.length} pages, ${tables.length} IndexedDB tables, ` +
  `${routeMarkers.length} API route markers, migrations, contracts and Android offline guards`,
);
