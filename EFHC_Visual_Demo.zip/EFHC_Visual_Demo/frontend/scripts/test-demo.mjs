import { readFileSync, existsSync } from "node:fs";
import { resolve } from "node:path";

const frontend = process.cwd();
const project = resolve(frontend, "..");
const android = resolve(project, "android");
const contract = JSON.parse(readFileSync(resolve(project, "SIMULATOR_CONTRACT.json"), "utf8"));

const expected = {
  mode: "offline_simulator",
  backend: "local_demo_engine",
  network_access: false,
  production_api_enabled: false,
  real_financial_operations: false,
  demo_marker_required: true,
  data_generation: "deterministic_seeded",
  state_storage: "local_only",
  application_id: "org.federationofavatars.efhc.simulator",
};
for (const [key, value] of Object.entries(expected)) {
  if (contract[key] !== value) throw new Error(`CONTRACT_${key}_INVALID`);
}

const required = [
  "src/demo/runtime.ts",
  "src/demo/seed.ts",
  "src/demo/database.ts",
  "src/demo/api.ts",
  "src/demo/DemoControlCenter.tsx",
  "src/demo/demo.css",
  "scripts/build-demo.mjs",
  "../android/app/src/main/AndroidManifest.xml",
  "../android/app/src/main/java/org/federationofavatars/efhc/simulator/MainActivity.kt",
];
for (const file of required) {
  if (!existsSync(resolve(frontend, file))) throw new Error(`MISSING_${file}`);
}
if (existsSync(resolve(frontend, "src/pages/api"))) throw new Error("NEXT_SERVER_API_ROUTES_MUST_NOT_SHIP_IN_OFFLINE_SIMULATOR");

const api = readFileSync(resolve(frontend, "src/demo/api.ts"), "utf8");
const coreRoutes = [
  "/sync/me",
  "/panels/active",
  "/exchange/convert",
  "/tasks/catalog",
  "/referrals/stats/me",
  "/ranks/my-plus-top/me",
  "/withdraw/request",
  "/wallets/me",
  "/shopfront/catalog",
  "/admin/users/search",
  "/admin/panels",
  "/admin/withdrawals",
  "/admin/bank/balance",
  "/admin/logs/transfers",
  "/admin/shop/items",
  "/admin/reports/",
];
for (const path of coreRoutes) {
  if (!api.includes(path)) throw new Error(`DEMO_ROUTE_MISSING:${path}`);
}

const db = readFileSync(resolve(frontend, "src/demo/database.ts"), "utf8");
const tables = [
  "settings",
  "users",
  "panels",
  "transactions",
  "tasks",
  "user_tasks",
  "referrals",
  "wallets",
  "withdrawals",
  "shop_items",
  "shop_orders",
  "hub_links",
  "admin_events",
  "skins",
  "templates",
];
for (const table of tables) {
  if (!db.includes(`"${table}"`)) throw new Error(`DEMO_TABLE_MISSING:${table}`);
}

const manifest = readFileSync(resolve(android, "app/src/main/AndroidManifest.xml"), "utf8");
for (const forbidden of ["android.permission.INTERNET", "android.permission.CAMERA", "android.permission.RECORD_AUDIO", "android.permission.ACCESS_FINE_LOCATION", "android.permission.READ_CONTACTS"]) {
  if (manifest.includes(forbidden)) throw new Error(`FORBIDDEN_ANDROID_PERMISSION:${forbidden}`);
}
const gradle = readFileSync(resolve(android, "app/build.gradle.kts"), "utf8");
if (!gradle.includes('applicationId = "org.federationofavatars.efhc.simulator"')) throw new Error("SIMULATOR_APPLICATION_ID_MISMATCH");
if (!gradle.includes('buildConfigField("String", "RUNTIME_MODE", "\\"offline_simulator\\"")')) throw new Error("ANDROID_RUNTIME_MODE_MISSING");

const activity = readFileSync(resolve(android, "app/src/main/java/org/federationofavatars/efhc/simulator/MainActivity.kt"), "utf8");
for (const marker of ["WebViewAssetLoader", "Offline simulator blocks external network access", "connect-src 'self'"]) {
  if (!activity.includes(marker)) throw new Error(`ANDROID_OFFLINE_GUARD_MISSING:${marker}`);
}

console.log(`[PASS] contract, ${tables.length} local tables, ${coreRoutes.length} core routes and Android offline guards`);
