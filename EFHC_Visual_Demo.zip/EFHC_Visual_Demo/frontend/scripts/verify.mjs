import { readFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const p=resolve(root,'..');
const m=JSON.parse(readFileSync(resolve(p,'SOURCE_MANIFEST.json'),'utf8'));
const c=JSON.parse(readFileSync(resolve(p,'SIMULATOR_CONTRACT.json'),'utf8'));
const checks=['FRONTEND_v865.html','SHOP_v865.html'];
for(const name of checks){
 const b=readFileSync(resolve(root,'source',name));
 const hash=createHash('sha256').update(b).digest('hex');
 if(hash!==m.original_html_sha256[name])throw new Error('SHA256 mismatch: '+name);
 const s=b.toString('utf8');
 if(!s.includes('</html>') || !s.toLowerCase().includes('<!doctype html>'))throw new Error('Invalid HTML: '+name);
 if(/<script\b[^>]*\bsrc\s*=|<link\b[^>]*\bhref\s*=/.test(s))throw new Error('Unexpected remote script/style link: '+name);
}
if(m.source_archive_sha256!==c.source_archive_sha256)throw new Error('Source archive SHA mismatch');
if(c.mode!=='offline_simulator'||c.backend!=='local_demo_engine'||c.network_access!==false||c.production_api_enabled!==false||c.real_financial_operations!==false)throw new Error('Offline contract mismatch');
console.log('[PASS] Source-integrity and static HTML verification (no TS application in this staging project)');
