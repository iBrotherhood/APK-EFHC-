import { readFileSync, writeFileSync, mkdirSync, copyFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const parent = resolve(root, '..');
const source = resolve(root, 'source');
const out = resolve(root, 'out');
const android = resolve(parent, 'android/app/src/main/assets/web');
const manifest = JSON.parse(readFileSync(resolve(parent, 'SOURCE_MANIFEST.json'), 'utf8'));
const contract = JSON.parse(readFileSync(resolve(parent, 'SIMULATOR_CONTRACT.json'), 'utf8'));
function digest(bytes) { return createHash('sha256').update(bytes).digest('hex'); }
for (const file of ['FRONTEND_v865.html','SHOP_v865.html','efhc_logo_canon.svg']) {
  const b = readFileSync(resolve(source, file));
  const expectedName = file === 'efhc_logo_canon.svg' ? 'logo_canon.svg' : file;
  if (digest(b) !== manifest.original_html_sha256[expectedName]) throw new Error('Source checksum mismatch: '+file);
}
if (contract.mode !== 'offline_simulator' || contract.production_api_enabled !== false || contract.network_access !== false) {
  throw new Error('Offline simulator contract required');
}
mkdirSync(out, { recursive: true });
mkdirSync(android, { recursive: true });
const viewportCss = readFileSync(resolve(root, 'scripts/apk-viewport.css'),'utf8');
function prepare(file) {
  const html = readFileSync(resolve(source, file), 'utf8');
  if (!html.includes('<!doctype html>') && !html.includes('<!DOCTYPE html>')) throw new Error('Expected HTML document: '+file);
  let result = html;
  if (file === 'FRONTEND_v865.html') {
    const needle = '</body>';
    if (html.split(needle).length !== 2) throw new Error('Original body tag is not unique');
    // Preserve all original HTML/JS, append only an APK-specific phone viewport CSS layer.
    result = html.replace(needle, '<style id="efhc-apk-viewport-adapter">\n'+ viewportCss +'\n</style>\n'+needle);
  }
  return result;
}
const assets = {
 'index.html': prepare('FRONTEND_v865.html'),
 'shop.html': prepare('SHOP_v865.html'),
 'simulator-contract.json': JSON.stringify(contract,null,2)+'\n',
 'source-manifest.json': JSON.stringify(manifest,null,2)+'\n'
};
for (const [name,content] of Object.entries(assets)) {
  writeFileSync(resolve(out,name),content);
  writeFileSync(resolve(android,name),content);
}
copyFileSync(resolve(source,'efhc_logo_canon.svg'), resolve(out,'logo_canon.svg'));
copyFileSync(resolve(source,'efhc_logo_canon.svg'), resolve(android,'logo_canon.svg'));
console.log('[PASS] Exact v865 standalone source digest');
console.log('[PASS] Original USER/ADMIN/SHOP HTML unchanged except outer viewport adapter');
console.log('[PASS] Android assets synchronized; no remote frontend build');
