import {
  cpSync,
  copyFileSync,
  existsSync,
  mkdirSync,
  readFileSync,
  rmSync,
  statSync,
} from "node:fs";
import { resolve } from "node:path";
import { spawnSync } from "node:child_process";

const frontend = process.cwd();
const project = resolve(frontend, "..");
const contract = resolve(project, "SIMULATOR_CONTRACT.json");
const publicContract = resolve(frontend, "public", "simulator-contract.json");
const assets = resolve(project, "android", "app", "src", "main", "assets", "web");
const androidContract = resolve(assets, "simulator-contract.json");

function validateContract(file) {
  if (!existsSync(file) || statSync(file).size === 0) {
    throw new Error(`SIMULATOR_CONTRACT_MISSING:${file}`);
  }
  const parsed = JSON.parse(readFileSync(file, "utf8"));
  const expected = {
    mode: "offline_simulator",
    backend: "local_demo_engine",
    network_access: false,
    production_api_enabled: false,
    real_financial_operations: false,
  };
  for (const [key, value] of Object.entries(expected)) {
    if (parsed[key] !== value) throw new Error(`SIMULATOR_CONTRACT_INVALID:${key}`);
  }
  return parsed;
}

validateContract(contract);
mkdirSync(resolve(frontend, "public"), { recursive: true });
copyFileSync(contract, publicContract);

const env = {
  ...process.env,
  EFHC_RUNTIME_MODE: "offline_simulator",
  NEXT_PUBLIC_EFHC_RUNTIME_MODE: "offline_simulator",
  NEXT_TELEMETRY_DISABLED: "1",
  EFHC_NEXT_EXTERNAL_TYPECHECK: "1",
};
const clean = spawnSync(
  process.execPath,
  [resolve(frontend, "scripts", "clean-next-build.mjs")],
  { cwd: frontend, env, stdio: "inherit" },
);
if (clean.status !== 0) process.exit(clean.status ?? 1);
const verify = spawnSync(
  process.execPath,
  [resolve(frontend, "scripts", "verify-production-assets.mjs")],
  { cwd: frontend, env, stdio: "inherit" },
);
if (verify.status !== 0) process.exit(verify.status ?? 1);
const result = spawnSync(
  process.execPath,
  [resolve(frontend, "node_modules", "next", "dist", "bin", "next"), "build", "--webpack"],
  { cwd: frontend, env, stdio: "inherit" },
);
if (result.status !== 0) process.exit(result.status ?? 1);

const out = resolve(frontend, "out");
if (!existsSync(resolve(out, "index.html"))) {
  throw new Error("DEMO_STATIC_EXPORT_MISSING");
}
rmSync(assets, { recursive: true, force: true });
mkdirSync(assets, { recursive: true });
cpSync(out, assets, { recursive: true });
copyFileSync(contract, androidContract);
validateContract(androidContract);
if (!existsSync(resolve(assets, "index.html"))) {
  throw new Error("ANDROID_WEB_ENTRYPOINT_MISSING");
}
console.log(`[PASS] synchronized and verified offline assets at ${assets}`);
