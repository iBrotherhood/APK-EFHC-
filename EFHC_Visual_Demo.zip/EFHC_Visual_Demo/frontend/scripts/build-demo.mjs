import {
  copyFileSync,
  existsSync,
  mkdirSync,
  readFileSync,
  rmSync,
  statSync,
} from "node:fs";
import { resolve } from "node:path";
import { spawnSync } from "node:child_process";

const frontend = process.cwd();
const project = resolve(frontend, "..");
const contract = resolve(project, "SIMULATOR_CONTRACT.json");
const publicContract = resolve(frontend, "public", "simulator-contract.json");
const assets = resolve(project, "android", "app", "src", "main", "assets", "web");
const androidContract = resolve(assets, "simulator-contract.json");
const androidIndex = resolve(assets, "index.html");
const androidBundle = resolve(assets, "web-bundle.zip");

function validateContract(file) {
  if (!existsSync(file) || statSync(file).size === 0) {
    throw new Error(`SIMULATOR_CONTRACT_MISSING:${file}`);
  }
  const parsed = JSON.parse(readFileSync(file, "utf8"));
  const expected = {
    mode: "offline_simulator",
    backend: "local_demo_engine",
    network_access: false,
    production_api_enabled: false,
    real_financial_operations: false,
  };
  for (const [key, value] of Object.entries(expected)) {
    if (parsed[key] !== value) throw new Error(`SIMULATOR_CONTRACT_INVALID:${key}`);
  }
  return parsed;
}

function run(command, args, options = {}) {
  const result = spawnSync(command, args, {
    ...options,
    stdio: "inherit",
  });
  if (result.error) throw result.error;
  if (result.status !== 0) {
    throw new Error(`${command.toUpperCase()}_FAILED:${result.status ?? "unknown"}`);
  }
}

validateContract(contract);
mkdirSync(resolve(frontend, "public"), { recursive: true });
copyFileSync(contract, publicContract);

const env = {
  ...process.env,
  EFHC_RUNTIME_MODE: "offline_simulator",
  NEXT_PUBLIC_EFHC_RUNTIME_MODE: "offline_simulator",
  NEXT_TELEMETRY_DISABLED: "1",
  EFHC_NEXT_EXTERNAL_TYPECHECK: "1",
};
run(
  process.execPath,
  [resolve(frontend, "scripts", "clean-next-build.mjs")],
  { cwd: frontend, env },
);
run(
  process.execPath,
  [resolve(frontend, "scripts", "verify-production-assets.mjs")],
  { cwd: frontend, env },
);
run(
  process.execPath,
  [resolve(frontend, "node_modules", "next", "dist", "bin", "next"), "build", "--webpack"],
  { cwd: frontend, env },
);

const out = resolve(frontend, "out");
const exportedIndex = resolve(out, "index.html");
const exportedContract = resolve(out, "simulator-contract.json");
if (!existsSync(exportedIndex) || statSync(exportedIndex).size === 0) {
  throw new Error("DEMO_STATIC_EXPORT_MISSING");
}
if (!existsSync(exportedContract) || statSync(exportedContract).size === 0) {
  throw new Error("DEMO_EXPORTED_CONTRACT_MISSING");
}
validateContract(exportedContract);
if (!readFileSync(exportedContract).equals(readFileSync(contract))) {
  throw new Error("DEMO_EXPORTED_CONTRACT_DRIFT");
}

// Keep the Android APK inventory intentionally compact. The canonical CI uses
// `unzip -l | awk | grep -q` under pipefail; a very large per-file web export
// can make that otherwise valid probe fail with SIGPIPE after grep finds the
// contract. The complete static export is therefore stored in one deterministic
// offline bundle and extracted into app-private storage on first launch.
rmSync(assets, { recursive: true, force: true });
mkdirSync(assets, { recursive: true });
copyFileSync(exportedIndex, androidIndex);
copyFileSync(contract, androidContract);

rmSync(androidBundle, { force: true });
run("zip", ["-q", "-r", "-X", androidBundle, "."], { cwd: out, env });
run("unzip", ["-tqq", androidBundle], { cwd: frontend, env });

if (!existsSync(androidBundle) || statSync(androidBundle).size === 0) {
  throw new Error("ANDROID_WEB_BUNDLE_MISSING");
}
validateContract(androidContract);
if (!readFileSync(androidContract).equals(readFileSync(contract))) {
  throw new Error("ANDROID_SOURCE_CONTRACT_DRIFT");
}
if (!existsSync(androidIndex) || statSync(androidIndex).size === 0) {
  throw new Error("ANDROID_WEB_ENTRYPOINT_MISSING");
}
console.log(
  `[PASS] synchronized compact offline assets at ${assets} ` +
  `(index.html, simulator-contract.json, web-bundle.zip)`,
);
