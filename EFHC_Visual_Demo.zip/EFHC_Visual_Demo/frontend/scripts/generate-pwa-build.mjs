import { createHash } from "node:crypto";
import {
  mkdirSync,
  readFileSync,
  readdirSync,
  statSync,
  writeFileSync,
} from "node:fs";
import { join, relative } from "node:path";

const root = process.cwd();
const generatedName = "pwa-build.json";
const hash = createHash("sha256");

function fileChecksum(path) {
  return createHash("sha256")
    .update(readFileSync(path))
    .digest("hex");
}

const ignoredNames = new Set([
  ".next",
  "node_modules",
  "tsconfig.tsbuildinfo",
  generatedName,
  "release-assets-manifest.json",
]);

function collect(path) {
  const stat = statSync(path);
  if (stat.isDirectory()) {
    for (const name of readdirSync(path).sort()) {
      if (ignoredNames.has(name)) continue;
      collect(join(path, name));
    }
    return;
  }
  const rel = relative(root, path).replaceAll("\\", "/");
  hash.update(rel);
  hash.update("\0");
  hash.update(readFileSync(path));
  hash.update("\0");
}

for (const rel of [
  "src",
  "public",
  "package.json",
  "package-lock.json",
  "next.config.js",
]) {
  collect(join(root, rel));
}

const buildId = `efhc-${hash.digest("hex").slice(0, 16)}`;
const langs = [
  "ru",
  "en",
  "uk",
  "de",
  "fr",
  "es",
  "it",
  "tr",
  "pl",
  "da",
  "hi",
  "id",
  "sw",
];
const publicDir = join(root, "public");
const faqDir = join(publicDir, "faq");
mkdirSync(faqDir, { recursive: true });

const localeChecksums = Object.fromEntries(
  langs.map((lang) => [
    lang,
    fileChecksum(join(publicDir, "locale", `${lang}.json`)),
  ]),
);
const faqChecksums = Object.fromEntries(
  langs.map((lang) => [
    lang,
    fileChecksum(join(faqDir, `${lang}.json`)),
  ]),
);
const precache = [
  "/offline.html",
  "/offline-readonly.html",
  "/manifest.webmanifest",
  "/assets/efhc/efhc_coin_192.png",
  "/assets/efhc/efhc_coin_512.png",
  "/assets/efhc/responsive/efhc_coin_128.avif",
  "/assets/efhc/responsive/efhc_coin_128.webp",
  ...langs.map((lang) => `/locale/${lang}.json`),
  ...langs.map((lang) => `/faq/${lang}.json`),
];
const payload = {
  schema: "EFHC_PWA_BUILD_V2",
  build_id: buildId,
  generated_from: "frontend-source-hash",
  locale_checksums: localeChecksums,
  faq_checksums: faqChecksums,
  precache,
  cache_limits: {
    static: {
      max_entries: 360,
      max_age_seconds: 3_888_000,
      max_bytes: 125_829_120,
    },
    content: {
      max_entries: 220,
      max_age_seconds: 1_209_600,
      max_bytes: 62_914_560,
    },
  },
};
writeFileSync(
  join(publicDir, generatedName),
  `${JSON.stringify(payload, null, 2)}\n`,
  "utf8",
);
writeFileSync(join(root, ".efhc-build-id"), `${buildId}\n`, "utf8");
console.log(`EFHC PWA build id: ${buildId}`);

