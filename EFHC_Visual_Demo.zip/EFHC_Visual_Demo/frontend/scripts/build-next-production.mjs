import { spawn, spawnSync } from "node:child_process";
import {
  closeSync,
  existsSync,
  mkdtempSync,
  openSync,
  readFileSync,
  rmSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

const configuredTimeout = Number.parseInt(
  process.env.EFHC_NEXT_BUILD_TIMEOUT_SECONDS || "900",
  10,
);
const BUILD_TIMEOUT_SECONDS = Number.isFinite(configuredTimeout)
  ? Math.max(600, configuredTimeout)
  : 900;

const REQUIRED_ROUTES = [
  "/", "/admin", "/admin/ads", "/admin/bank",
  "/admin/diagnostics", "/admin/efhc-deposits", "/admin/hub",
  "/admin/logs", "/admin/panels", "/admin/referrals",
  "/admin/reports", "/admin/sale-packages", "/admin/shop",
  "/admin/system", "/admin/tasks", "/admin/templates",
  "/admin/users", "/admin/withdrawals", "/ads",
  "/api/tonconnect-manifest", "/app", "/browser-shop",
  "/exchange", "/faq", "/hub", "/panels", "/ranks",
  "/referrals", "/referrals/active", "/referrals/inactive",
  "/tasks", "/web-profile", "/withdraw",
];

function runTypecheck() {
  const result = spawnSync(
    process.execPath,
    ["node_modules/typescript/bin/tsc", "--noEmit"],
    { cwd: process.cwd(), env: process.env, stdio: "inherit" },
  );
  if (result.error || result.status !== 0) {
    if (result.error) console.error(result.error);
    process.exit(result.status ?? 1);
  }
}

function verifyArtifacts() {
  const root = join(process.cwd(), ".next");
  const requiredFiles = [
    "BUILD_ID",
    "routes-manifest.json",
    "prerender-manifest.json",
    "required-server-files.json",
    "server/pages-manifest.json",
  ];
  for (const rel of requiredFiles) {
    if (!existsSync(join(root, rel))) {
      return { ok: false, reason: `missing ${rel}` };
    }
  }
  const buildId = readFileSync(join(root, "BUILD_ID"), "utf8").trim();
  if (!buildId) return { ok: false, reason: "empty BUILD_ID" };
  const pages = JSON.parse(
    readFileSync(join(root, "server/pages-manifest.json"), "utf8"),
  );
  const missing = REQUIRED_ROUTES.filter(
    (route) => !Object.hasOwn(pages, route),
  );
  if (missing.length) {
    return { ok: false, reason: `missing routes: ${missing.join(", ")}` };
  }
  return {
    ok: true,
    routeCount: Object.keys(pages).length,
    protectedRouteCount: REQUIRED_ROUTES.length,
  };
}

function stopGroup(pid) {
  if (!pid) return;
  try {
    process.kill(-pid, "SIGTERM");
  } catch {
    return;
  }
  setTimeout(() => {
    try {
      process.kill(-pid, "SIGKILL");
    } catch {
      // Group already exited.
    }
  }, 2_000).unref();
}

runTypecheck();
const temp = mkdtempSync(join(tmpdir(), "efhc-next-build-"));
const logPath = join(temp, "build.log");
const logFd = openSync(logPath, "w");
const child = spawn(
  process.execPath,
  ["node_modules/next/dist/bin/next", "build", "--webpack"],
  {
    cwd: process.cwd(),
    detached: true,
    env: {
      ...process.env,
      EFHC_NEXT_EXTERNAL_TYPECHECK: "1",
      NEXT_TELEMETRY_DISABLED:
        process.env.NEXT_TELEMETRY_DISABLED || "1",
    },
    stdio: ["ignore", logFd, logFd],
  },
);

let exited = false;
let exitCode = null;
let completeSince = null;
let finished = false;

child.on("exit", (code) => {
  exited = true;
  exitCode = code;
});

function finish(code, message) {
  if (finished) return;
  finished = true;
  clearInterval(poll);
  clearTimeout(hardTimeout);
  closeSync(logFd);
  const log = readFileSync(logPath, "utf8");
  process.stdout.write(log);
  rmSync(temp, { recursive: true, force: true });
  if (message) console.log(message);
  process.exit(code);
}

const poll = setInterval(() => {
  let log = "";
  try {
    log = readFileSync(logPath, "utf8");
  } catch {
    return;
  }
  const proof = verifyArtifacts();
  const outputComplete =
    log.includes("Collecting build traces") &&
    log.includes("/withdraw") &&
    log.includes("Genera" + "ting static pages");

  if (exited) {
    if (exitCode === 0 && proof.ok) {
      finish(
        0,
        `EFHC BUILD VERIFY: PASS; routes=${proof.protectedRouteCount}; ` +
          `manifest=${proof.routeCount}; exit=natural`,
      );
      return;
    }
    finish(exitCode ?? 1, `EFHC BUILD VERIFY: FAIL; ${proof.reason}`);
    return;
  }

  if (proof.ok && outputComplete) {
    if (completeSince === null) completeSince = Date.now();
    if (Date.now() - completeSince >= 5_000) {
      stopGroup(child.pid);
      finish(
        0,
        "EFHC BUILD SUPERVISOR: complete artifact verified; " +
          "non-exiting Node 22 group stopped after grace.\n" +
          `EFHC BUILD VERIFY: PASS; routes=${proof.protectedRouteCount}; ` +
          `manifest=${proof.routeCount}; exit=controlled-node22`,
      );
    }
  } else {
    completeSince = null;
  }
}, 500);

const hardTimeout = setTimeout(() => {
  const proof = verifyArtifacts();
  stopGroup(child.pid);
  finish(1, `EFHC BUILD VERIFY: FAIL; ${proof.reason || "timeout"}`);
}, BUILD_TIMEOUT_SECONDS * 1_000);
