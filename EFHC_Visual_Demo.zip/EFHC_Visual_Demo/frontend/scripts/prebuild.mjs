import { spawnSync } from "node:child_process";

const commands = [
  [process.execPath, ["scripts/clean-next-build.mjs"]],
  [process.execPath, ["scripts/verify-production-assets.mjs"]],
];

for (const [command, args] of commands) {
  const result = spawnSync(command, args, { stdio: "inherit" });
  if (result.error || result.status !== 0) {
    if (result.error) console.error(result.error);
    process.exit(result.status ?? 1);
  }
}
