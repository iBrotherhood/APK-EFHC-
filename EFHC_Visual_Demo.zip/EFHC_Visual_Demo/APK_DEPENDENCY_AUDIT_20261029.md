# EFHC Offline Simulator — dependency and failure audit (2026-10-29)

## Confirmed failure in logs_110906423706.zip

`app:lintDebug FAILED` due to MainActivity.kt:76 `GestureBackNavigation`: overriding legacy onBackPressed() is no longer valid for targetSdk 36 / Android 16 predictive back.

## Exact remediation

- Replaced Activity with AndroidX ComponentActivity, registered OnBackPressedCallback using onBackPressedDispatcher; no Lint suppression.
- Gradle 8.13 → 9.8.2; verified distribution SHA-256 `21bd5da2de49b642904077f38c0efdc7778e92b3ed0889392dca61b97e389607` and wrapper SHA-256 `3b8a25775a69158b5ad2b1d17a80a88dc7b40a352a73eb27d06c612a7ce68e98` (official Gradle checksum reference).
- Android Gradle Plugin 8.13.2 → 9.5.0. Removed incompatible `org.jetbrains.kotlin.android` plugin and deprecated kotlinOptions. AGP 9.5 uses built-in Kotlin.
- AndroidX WebKit 1.14.0 → 1.18.0 stable, AndroidX Activity 1.13.0 stable.
- Kept compileSdk/targetSdk=36 and minSdk=26 to respect the existing workflow contract; these are Android API compatibility targets, not dependency versions. The workflow installs Android SDK 36.
- Existing GitHub Actions workflow still installs Node.js 22 and JDK 17 by design, not newest Node or JDK. Existing workflow actions/SDK/Java remain unchanged because this ZIP cannot replace the repository's YAML file. JDK 17 meets AGP 9.5 minimum.
- npm package.json has zero external npm dependencies; `npm ci` cannot upgrade any library by design.

## Tests and limits

Static gates verify Gradle and SHA pins, Kotlin plugin migration, back dispatcher and AndroidX versions. `npm run test:demo`, `npm run typecheck`, `npm run build:demo` should be run locally prior to push. Full Android Gradle/Lint/APK build needs GitHub Actions; not claimed successful without real run.

Official references:
- https://gradle.org/releases/
- https://gradle.org/release-checksums/
- https://developer.android.com/build/releases/about-agp
- https://developer.android.com/build/migrate-to-built-in-kotlin
- https://developer.android.com/jetpack/androidx/releases/webkit
- https://developer.android.com/jetpack/androidx/releases/activity
- https://developer.android.com/guide/navigation/custom-back/predictive-back-gesture
