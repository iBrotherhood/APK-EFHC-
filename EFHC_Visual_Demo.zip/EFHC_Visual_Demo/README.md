# EFHC Offline Demo Simulator v0.1.4

Источник интерфейса: **EFHC Bot v172.43 RELEASE**  
SHA-256 исходного release-архива: `c505ed88b7f95c698380d581f1b418c7d2b9f7e4f4b6b6cd5670453fc4150bca`

Самостоятельный офлайн APK-симулятор для визуальной, навигационной и сценарной проверки EFHC. Это не production APK и не отдельный финальный Android-фронтенд.

## Состав

- реальный Next.js/React-интерфейс EFHC;
- 32 экранных маршрута, включая 17 административных страниц;
- локальный backend-эмулятор через общий API-клиент;
- постоянная IndexedDB со схемой `efhc-offline-simulator-v2` и 17 таблицами;
- интерактивные панели, обмен, задания, реклама, кошельки, выводы, магазин и административные операции;
- пять детерминированных сценариев и четыре режима ответа локального backend;
- Demo Control Center для перехода на любой экран, смены сценария и сброса данных;
- Android WebView-контейнер без сетевого разрешения.

## Локальные таблицы

`settings`, `users`, `panels`, `transactions`, `tasks`, `user_tasks`, `referrals`, `wallets`, `withdrawals`, `shop_items`, `shop_orders`, `hub_links`, `admin_events`, `skins`, `templates`, `sale_packages`, `ad_events`.

IndexedDB-индексы используют только допустимые строковые, числовые и составные ключи. Булевы значения не применяются как ключи индексов.

## Демо-сценарии

- `active` — активный пользователь;
- `vip` — VIP-пользователь;
- `new_user` — новый пользователь;
- `risk` — проблемные и отклонённые операции;
- `dense` — длинные таблицы для проверки мобильной вёрстки.

Режимы локального backend: `normal`, `slow`, `error`, `empty`.

## Компактная офлайн-упаковка

После статического Next.js export полный web-интерфейс упаковывается в `assets/web/web-bundle.zip`. В APK отдельно остаются только три web-assets:

- `assets/web/index.html` — контрольный entrypoint;
- `assets/web/simulator-contract.json` — канонический контракт;
- `assets/web/web-bundle.zip` — полный статический frontend.

На первом запуске APK bundle безопасно распаковывается в приватное хранилище приложения. Перед загрузкой проверяются `index.html`, контракт и побайтовое совпадение контракта с отдельным APK asset. Защита от path traversal и ограничения количества/размера распакованных данных встроены в Android-код.

Компактная схема также обеспечивает корректную работу неизменяемой канонической проверки `unzip -l | awk | grep -q` при `pipefail`.

## Сборка

В корень GitHub-репозитория помещаются только:

- `EFHC_Visual_Demo.zip`;
- `EFHC_Visual_Demo.zip.sha256`.

Используется существующий канонический GitHub workflow. Workflow не входит в архив симулятора и не изменяется без прямой команды владельца проекта.

Сам архив обеспечивает:

- статический экспорт frontend;
- создание и тестирование `web-bundle.zip`;
- синхронизацию generated Android assets;
- проверку трёх обязательных web-assets внутри фактически собранного APK;
- проверку контракта внутри APK и внутри web-bundle;
- воспроизведение точной pipefail-проверки канонического CI как часть `assembleDebug`.

## Безопасность

- `applicationId`: `org.federationofavatars.efhc.simulator`;
- Android Manifest не запрашивает `android.permission.INTERNET`;
- WebView блокирует обращения к внешним хостам;
- production API и реальные финансовые операции отключены;
- данные вымышлены, детерминированы seed `EFHC-DEMO-SEED-001` и хранятся только на смартфоне.
