# EFHC Offline Demo Simulator v0.1.0

Источник интерфейса: **EFHC Bot v172.43**  
SHA-256 исходного release-архива: `c505ed88b7f95c698380d581f1b418c7d2b9f7e4f4b6b6cd5670453fc4150bca`

Самостоятельный офлайн APK-симулятор для визуальной и сценарной проверки EFHC. Это не production APK и не отдельный финальный Android-фронтенд.

## Что находится внутри

- реальный текущий Next.js/React-интерфейс EFHC;
- 32 рабочих экранных маршрута и 17 административных страниц;
- локальный backend-эмулятор, повторяющий API-контракты интерфейса;
- постоянная IndexedDB `efhc-offline-simulator-v1` с 15 таблицами;
- интерактивные операции: панели, обмен, задачи, реклама, кошельки, выводы, магазин и административные изменения;
- пять наборов демо-данных и четыре режима ответа backend;
- Android WebView-контейнер с локальными assets;
- запрет production API, внешней сети и реальных финансовых операций;
- `Demo Control Center` для перехода на любой экран, смены сценария и сброса данных.

## Локальные таблицы

`settings`, `users`, `panels`, `transactions`, `tasks`, `user_tasks`, `referrals`, `wallets`, `withdrawals`, `shop_items`, `shop_orders`, `hub_links`, `admin_events`, `skins`, `templates`.

## Сценарии

- активный пользователь;
- VIP-пользователь;
- новый пользователь;
- риск и ошибочные операции;
- насыщенные длинные таблицы.

Дополнительно backend можно переключить в режимы `normal`, `slow`, `error`, `empty`.

## Сборка GitHub CI

1. Поместить архив `EFHC_Visual_Demo.zip` в корень GitHub-репозитория.
2. Поместить `android-build-efhc-offline-simulator.yml` как `.github/workflows/android-build-simulator.yml`.
3. Запустить workflow вручную либо выполнить push в `main`/`master`.
4. Скачать APK из GitHub Actions Artifacts.

CI сам проверяет ZIP, контракт симулятора, TypeScript, demo engine, статический экспорт, Android unit tests, lint, Kotlin, подпись APK, applicationId, SDK, встроенный контракт и отсутствие сетевых/опасных разрешений.

## Безопасность

Симулятор имеет отдельный `applicationId`: `org.federationofavatars.efhc.simulator`.
В Android Manifest отсутствует `android.permission.INTERNET`. WebView дополнительно блокирует обращения к любому хосту, кроме локального `appassets.androidplatform.net`.

Все данные вымышлены, детерминированы seed `EFHC-DEMO-SEED-001` и хранятся только на смартфоне.
