# EFHC Offline Demo Simulator v0.1.2

Источник интерфейса: **EFHC Bot v172.43 RELEASE**  
SHA-256 исходного release-архива: `c505ed88b7f95c698380d581f1b418c7d2b9f7e4f4b6b6cd5670453fc4150bca`

Самостоятельный офлайн APK-симулятор для визуальной, навигационной и сценарной проверки EFHC. Это не production APK и не отдельный финальный Android-фронтенд.

## Что находится внутри

- настоящий Next.js/React-интерфейс EFHC;
- 32 рабочих экранных маршрута, включая 17 административных страниц;
- локальный backend-эмулятор, повторяющий контракты общего API-клиента;
- постоянная IndexedDB со схемой `efhc-offline-simulator-v2` и 17 таблицами;
- интерактивные операции: панели, обмен, задания, реклама, кошельки, выводы, магазин и административные изменения;
- пять детерминированных наборов демо-данных и четыре режима ответа backend;
- Android WebView-контейнер с локальными assets;
- запрет production API, внешней сети и реальных финансовых операций;
- `Demo Control Center` для перехода на любой экран, смены сценария и сброса данных.

## Локальные таблицы

`settings`, `users`, `panels`, `transactions`, `tasks`, `user_tasks`, `referrals`, `wallets`, `withdrawals`, `shop_items`, `shop_orders`, `hub_links`, `admin_events`, `skins`, `templates`, `sale_packages`, `ad_events`.

Индексы IndexedDB используют только допустимые строковые, числовые и составные ключи. Булевы поля не применяются как ключи индексов.

## Сценарии

- `active` — активный пользователь;
- `vip` — VIP-пользователь;
- `new_user` — новый пользователь;
- `risk` — проблемные и отклонённые операции;
- `dense` — длинные таблицы для проверки мобильной вёрстки.

Backend можно переключить в режимы `normal`, `slow`, `error`, `empty`.

## Сборка GitHub CI

1. Поместить `EFHC_Visual_Demo.zip` и `EFHC_Visual_Demo.zip.sha256` в корень GitHub-репозитория.
2. Поместить `android-build-efhc-offline-simulator.yml` как `.github/workflows/android-build-simulator.yml`.
3. Запустить workflow вручную либо выполнить push в `main`/`master`.
4. Скачать APK из GitHub Actions Artifacts.

CI проверяет ZIP, SHA-256, контракт, TypeScript, demo engine, статический экспорт, Android unit tests, lint, Kotlin, подпись, package/version/SDK, отсутствие сетевых разрешений и наличие внутри APK двух обязательных assets:

- `assets/web/index.html`;
- `assets/web/simulator-contract.json`.

## Безопасность

- `applicationId`: `org.federationofavatars.efhc.simulator`;
- в Android Manifest отсутствует `android.permission.INTERNET`;
- WebView блокирует обращения к любому хосту, кроме локального `appassets.androidplatform.net`;
- production API и реальные финансовые операции отключены;
- данные вымышлены, детерминированы seed `EFHC-DEMO-SEED-001` и хранятся только на смартфоне.
