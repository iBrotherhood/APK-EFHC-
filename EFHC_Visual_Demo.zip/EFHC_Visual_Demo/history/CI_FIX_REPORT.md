# EFHC APK CI repair — 2026-10-29

## Confirmed failure

`Prepare Gradle Wrapper` failed with HTTP 404 for `https://services.gradle.org/distributions/gradle-8.13-wrapper.jar`.
All earlier frontend extraction, typecheck, demo test, and asset synchronization stages succeeded.

## Changes

- Replaced broken wrapper URL download with verified extraction of the official Gradle 8.13 wrapper JAR nested in the official `gradle-8.13-bin.zip` distribution.
- Release distribution SHA-256: `20f1b1176237254a6fc204d8434196fa11a4cfb387567519c61556e8710aed78`.
- Official wrapper JAR SHA-256: `81a82aaea5abcc8ff68b3dfcb58b3c3c429378efd98e7433460610fecd7ae45f`.
- Added `distributionSha256Sum` to `gradle-wrapper.properties`.
- Explicitly enabled `buildFeatures.buildConfig` so the Android Kotlin code can reference `BuildConfig.DEBUG`.
- Added regression tests for both changes.

## Checks completed locally

- Java downloader compiles with `javac --release 17`: PASS.
- Synthetic distribution ZIP nested extraction + malformed nested archive rejection: PASS.
- `npm ci`, `npm run typecheck`, `npm run test:demo` (6), `npm run build:demo`: PASS.
- Original v865 USER/ADMIN/SHOP HTML, SVG and audio SHA-256 unchanged: PASS.
- ZIP content structure and integrity: PASS.

## Not yet verified

Real Gradle distribution download, Android SDK build, final APK signature and Android runtime behavior require a GitHub Actions run with network access. This report does not certify those steps.

## Deployment

Upload this entire ZIP to the root of `iBrotherhood/APK-EFHC-` as `EFHC_Visual_Demo.zip`, replacing the old copy. The existing repository YAML can be retained.
